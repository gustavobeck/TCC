package com.tcc.daytrackerfinale;

public class Constants {

    private static final String ROOT_URL = "http://192.168.1.104/DayTrackerFinale/";
    // USUARIO
    public static final String URL_USUARIO_CADASTRO = ROOT_URL + "UsuarioCadastro.php";
    public static final String URL_USUARIO_LOGIN = ROOT_URL + "UsuarioLogin.php";
    public static final String URL_USUARIO_TROCAR_SENHA = ROOT_URL + "UsuarioTrocaSenha.php";
    public static final String URL_USUARIO_TROCAR_EMAIL = ROOT_URL + "UsuarioTrocaEmail.php";
    public static final String URL_USUARIO_TROCAR_NOME = ROOT_URL + "UsuarioTrocaNome.php";
    public static final String URL_USUARIO_DELETAR_CONTA = ROOT_URL + "UsuarioDeletarConta.php";

    // COMPROMISSOS
    public static final String URL_COMPROMISSO_CRIAR = ROOT_URL + "CompromissoCriar.php";
    public static final String URL_COMPROMISSO_DELETAR = ROOT_URL + "CompromissoDeletar.php";
    public static final String URL_COMPROMISSO_EDITAR = ROOT_URL + "CompromissoEditar.php";
    public static final String URL_PROXIMOS_COMPROMISSOS = ROOT_URL + "lerProximosCompromissos.php"; // TODO mostrar proximos

    // ANOTACAO
    public static final String URL_ANOTACAO_CRIAR = ROOT_URL + "AnotacaoCriar.php";
    public static final String URL_ANOTACAO_EDITAR = ROOT_URL + "AnotacaoEditar.php";
    public static final String URL_ANOTACAO_DELETAR = ROOT_URL + "AnotacaoDeletar.php";

    // EVENTOS
    public static final String URL_EVENTO_CRIAR = ROOT_URL + "EventoCriar.php";
    public static final String URL_EVENTO_DELETAR = ROOT_URL + "EventoDeletar.php";
    public static final String URL_EVENTO_EDITAR = ROOT_URL + "EventoEditar.php";
    public static final String URL_EVENTO_SAIR = ROOT_URL + "EventoSair.php";

    //MES
    public static final String URL_MES_BOLINHAS = ROOT_URL + "MesBolinhas.php";
    public static final String URL_MES_BOLINHAS_ANOTACOES = ROOT_URL + "MesBolinhasAnotacoes.php";

    //DIA
    public static final String URL_DIA_LER_COMPROMISSOS = ROOT_URL + "DiaLerCompromissos.php";
    public static final String URL_DIA_LER_EVENTOS = ROOT_URL + "DiaLerEventos.php";
    public static final String URL_DIA_LER_EVENTOS_INSCRITOS = ROOT_URL + "DiaLerEventosInscritos.php";
    public static final String URL_DIA_LER_ANOTACOES = ROOT_URL + "DiaLerAnotacoes.php";

    // PARTICIPANTES
    public static final String URL_PARTICIPANTES_LER = ROOT_URL + "ParticipantesLer.php";
    public static final String URL_PARTICIPANTE_CONVITE_RECUSAR = ROOT_URL + "ParticipanteConviteRecusar.php";
    public static final String URL_PARTICIPANTE_CONVITE_ACEITAR = ROOT_URL + "ParticipanteConviteAceitar.php";
    public static final String URL_PARTICIPANTE_CONVITE_LER = ROOT_URL + "ParticipanteConviteLer.php";
    public static final String URL_PARTICIPANTE_CONVIDAR = ROOT_URL + "ParticipanteConvidar.php";
    public static final String URL_PARTICIPANTE_EXCLUIR = ROOT_URL + "ParticipanteExcluir.php";

    // AMIZADE
    public static final String URL_AMIGOS_AMIZADES_LER = ROOT_URL + "AmigosAmizadesLer.php";
    public static final String URL_AMIGOS_PEDIDOS_LER = ROOT_URL + "AmigosPedidosLer.php";
    public static final String URL_AMIGOS_PEDIDO_ENVIAR = ROOT_URL + "AmigosPedidoEnviar.php";
    public static final String URL_AMIGOS_PEDIDO_ACEITAR = ROOT_URL + "AmigosPedidoAceitar.php";
    public static final String URL_AMIGOS_PEDIDO_RECUSAR = ROOT_URL + "AmigosPedidoRecusar.php";
    public static final String URL_AMIGOS_AMIZADE_EXCLUIR = ROOT_URL + "AmigosAmizadeExcluir.php";
}
