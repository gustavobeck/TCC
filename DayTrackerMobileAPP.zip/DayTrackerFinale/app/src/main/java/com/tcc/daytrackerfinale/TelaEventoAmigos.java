package com.tcc.daytrackerfinale;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class TelaEventoAmigos extends AppCompatActivity {
    LinearLayout linear;
    List<_Amigo> listaAmigos = new ArrayList<_Amigo>();
    List<_PedidoAmigo> listaPedidos = new ArrayList<_PedidoAmigo>();
    EditText editNome, editId;
    Intent root;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela_evento_amigos);

        linear = findViewById(R.id.linearAmizades);

        listarAmizades();

        root = getIntent();

        editNome = findViewById(R.id.editAmigoNome);
        editId = findViewById(R.id.editAmigoId);
    }

    private void listarAmizades() {
        StringRequest request = new StringRequest(Request.Method.POST, Constants.URL_AMIGOS_AMIZADES_LER, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    JSONObject object = new JSONObject(response);
                    JSONArray array = object.getJSONArray("amizades");
                    JSONArray array2 = object.getJSONArray("amigos");
                    listaAmigos.clear();

                    for (int i = 0; i < array.length(); i++) {
                        JSONObject jsonObject = array.getJSONObject(i);
                        JSONObject jsonObject2 = array2.getJSONObject(i);

                        //add
                        _Amigo objAmigo = new _Amigo();
                        objAmigo.setNome(jsonObject2.getString("nome"));
                        objAmigo.setIdAmigo(Integer.parseInt(jsonObject2.getString("idUsuario")));
                        objAmigo.setIdAmizade(Integer.parseInt(jsonObject.getString("idAmizade")));
                        listaAmigos.add(objAmigo);

                    }
                    mostrarAmigos();

                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getApplicationContext(), error.toString(), Toast.LENGTH_SHORT).show();

            }
        }) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                SharedPreferences sharedPreferences = getSharedPreferences("Login", MODE_PRIVATE);
                params.put("idUsuario", sharedPreferences.getString("idKey", ""));
                return params;
            }
        };
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(request);
    }

    private void mostrarAmigos() {
        linear.removeAllViews();
        for (int i = 0; i < listaAmigos.size(); i++) {
            View view = getLayoutInflater().inflate(R.layout.item_amigo_convidar, null);
            TextView itemNome = view.findViewById(R.id.itemNome);
            TextView itemIdAmigo = view.findViewById(R.id.itemIdAmigo);
            TextView itemIdAmizade = view.findViewById(R.id.itemIdPedido);
            itemNome.setText(listaAmigos.get(i).getNome());
            itemIdAmigo.setText(String.valueOf(listaAmigos.get(i).getIdAmigo()));
            Toast.makeText(this, String.valueOf(listaAmigos.get(i).getIdAmigo()), Toast.LENGTH_SHORT).show();
            itemIdAmizade.setText(String.valueOf(listaAmigos.get(i).getIdAmizade()));
            linear.addView(view);
        }
    }

    public void convidarAmigo(View v) {
        View cl = (View) v.getParent();
        TextView idTextView = cl.findViewById(R.id.itemIdAmigo);
        String idAmigo = idTextView.getText().toString();
        Toast.makeText(this, idAmigo, Toast.LENGTH_SHORT).show();

        StringRequest request = new StringRequest(Request.Method.POST, Constants.URL_PARTICIPANTE_CONVIDAR, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    Toast.makeText(getApplicationContext(), jsonObject.getString("mensagem"), Toast.LENGTH_SHORT).show();
                    listarAmizades();
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getApplicationContext(), error.toString(), Toast.LENGTH_SHORT).show();

            }
        }) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                params.put("idAmigo", idAmigo);
                params.put("idEvento", root.getStringExtra("idEvento"));
                return params;
            }
        };
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(request);
    }

    public void excluirAmigo(View v) {
        View cl = (View) v.getParent();
        TextView idTextView = cl.findViewById(R.id.itemIdAmizade);
        String idAmizade = idTextView.getText().toString();

        StringRequest stringRequest = new StringRequest(Request.Method.POST, Constants.URL_AMIGOS_AMIZADE_EXCLUIR, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    Toast.makeText(getApplicationContext(), jsonObject.getString("mensagem"), Toast.LENGTH_SHORT).show();
                    listarAmizades();
                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getApplicationContext(), error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        }){
            @Override
            protected Map<String, String> getParams(){
                Map<String,String> params = new HashMap<>();
                params.put("idAmizade", idAmizade);
                return params;
            }
        };
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);

    }
    public void Sair(View v) {
        finish();
    }

}
