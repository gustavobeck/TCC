package com.tcc.daytrackerfinale;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.Map;

public class TelaCompromisso extends AppCompatActivity {
    EditText editTitulo, editDescricao, editHora, editData, editTipo;
    Intent root;
    SimpleDateFormat sdfFront = new SimpleDateFormat("dd/MM/yyyy");
    SimpleDateFormat sdfBack = new SimpleDateFormat("yyyy/MM/dd");
    ConstraintLayout fechaView;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela_compromisso);

        Associar();
        SwipeFecha();

        String dataFormatada = "";
        try {
            dataFormatada = sdfFront.format(sdfBack.parse(root.getStringExtra("dia")));
        } catch (ParseException e) {
            e.printStackTrace();
        }
        editData.setText(dataFormatada);
    }

    private void Associar() {
        root = getIntent();

        editTitulo = findViewById(R.id.editTitulo);
        editDescricao = findViewById(R.id.editDescricao);
        editHora = findViewById(R.id.editHora);
        editData = findViewById(R.id.editDia);
        fechaView = findViewById(R.id.constraintLayout3);
        editTipo = findViewById(R.id.editCompromissoTipo);

        editTitulo.setText(root.getStringExtra("titulo"));
        editDescricao.setText(root.getStringExtra("descricao"));
        editHora.setText(root.getStringExtra("hora"));
        editData.setText(root.getStringExtra("data"));
        editTipo.setText(root.getStringExtra("tipo"));
    }

    public void excluir(View v) {
        StringRequest stringRequest = new StringRequest(Request.Method.POST, Constants.URL_COMPROMISSO_DELETAR, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    Toast.makeText(getApplicationContext(), jsonObject.getString("mensagem"), Toast.LENGTH_SHORT).show();
                    if (jsonObject.getString("erro").equals("false")) {Sair(null);}

                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getApplicationContext(), error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        }){
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String,String> params = new HashMap<>();
                params.put("idCompromisso", root.getStringExtra("idCompromisso"));
                return params;
            }
        };
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);

        finish();
    }
    public void salvarCompromisso(View v) throws ParseException {
        String dataRaw = "";
        dataRaw = String.valueOf(editData.getText());
        final String dataFormatada = sdfBack.format(sdfFront.parse(dataRaw));
        StringRequest stringRequest = new StringRequest(Request.Method.POST, Constants.URL_COMPROMISSO_EDITAR, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    Toast.makeText(getApplicationContext(), jsonObject.getString("mensagem"), Toast.LENGTH_SHORT).show();
                    if (jsonObject.getString("erro").equals("false")) {Sair(null);}

                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getApplicationContext(), error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        }){
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String,String> params = new HashMap<>();
                params.put("idCompromisso", root.getStringExtra("idCompromisso"));
                params.put("titulo", String.valueOf(editTitulo.getText()));
                params.put("data", dataFormatada);
                params.put("descricao", String.valueOf(editDescricao.getText()));
                params.put("hora", String.valueOf(editHora.getText()));
                params.put("tipo", String.valueOf(editTipo.getText()));
                return params;
            }
        };
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);

        finish();
    }
    private void SwipeFecha(){
        fechaView.setOnTouchListener(new OnSwipeTouchListener(TelaCompromisso.this) {
            public void onSwipeBottom() {
                finish();
            }
        });
    }

    public void Sair(View v) {
        Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                finish();
            }
        }, 200);
    }

}
