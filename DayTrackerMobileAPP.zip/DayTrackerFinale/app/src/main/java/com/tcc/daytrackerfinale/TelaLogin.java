package com.tcc.daytrackerfinale;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class TelaLogin extends AppCompatActivity {
    private EditText editTextSenha, editTextEmail;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela_login);
        SharedPreferences sharedPreferences = getSharedPreferences("Login", Context.MODE_PRIVATE);

        if (!sharedPreferences.getString("nomeKey", "").equals("")) {
            irPrincipal();
            finish();
        }

        Associar();
    }

    private void Associar() {
        editTextEmail = findViewById(R.id.inputEmail);
        editTextSenha = findViewById(R.id.inputSenha);
    }

    public void Logar(final View view){
        StringRequest stringRequest = new StringRequest(
                Request.Method.POST,
                Constants.URL_USUARIO_LOGIN,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            JSONObject obj = new JSONObject(response);
                            if (!obj.getBoolean("erro")){
                                SharedPreferences sharedPreferences = getSharedPreferences("Login", Context.MODE_PRIVATE);
                                SharedPreferences.Editor editor = sharedPreferences.edit();
                                editor.putString("emailKey", obj.getString("email"));
                                editor.putString("nomeKey", obj.getString("nome"));
                                editor.putString("idKey", obj.getString("idUsuario"));
                                editor.putString("senhaKey", obj.getString("senha"));
                                editor.apply();
                                irPrincipal();
                                finish();
                            } else {
                                Toast.makeText(getApplicationContext(), obj.getString("mensagem"), Toast.LENGTH_SHORT).show();
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getApplicationContext(), error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        }
        ){
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<>();
                params.put("email", editTextEmail.getText().toString());
                params.put("senha", editTextSenha.getText().toString());
                return params;
            }
        };
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);
    }

    //public void irCadastro(View view) {
    //    Intent it = new Intent(this, TelaCadastro.class);
    //    startActivity(it);
    //}

    private void irPrincipal(){
        Intent it = new Intent(getApplicationContext(), TelaMes.class);
        startActivity(it);
    }
    public void irCadastro(View v){
        Intent it = new Intent(getApplicationContext(), TelaCadastro.class);
        startActivity(it);
    }
}
