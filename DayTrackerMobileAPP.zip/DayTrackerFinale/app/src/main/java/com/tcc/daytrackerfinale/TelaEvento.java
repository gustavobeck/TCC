package com.tcc.daytrackerfinale;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class TelaEvento extends AppCompatActivity {
    EditText editTitulo, editDescricao, editHora, editData;
    Intent root;
    SimpleDateFormat sdfFront = new SimpleDateFormat("dd/MM/yyyy");
    SimpleDateFormat sdfBack = new SimpleDateFormat("yyyy/MM/dd");
    ConstraintLayout fechaView;
    List<_Amigo> listaAmigos = new ArrayList<_Amigo>();
    List<_Amigo> listaParticipantes = new ArrayList<>();
    LinearLayout linear;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela_evento);

        Associar();
        SwipeFecha();

        listarParticipantes();

        String dataFormatada = "";
        try {
            dataFormatada = sdfFront.format(sdfBack.parse(root.getStringExtra("dia")));
        } catch (ParseException e) {
            e.printStackTrace();
        }
        editData.setText(dataFormatada);
    }

    private void Associar() {
        root = getIntent();

        editTitulo = findViewById(R.id.editTitulo);
        editDescricao = findViewById(R.id.editDescricao);
        editHora = findViewById(R.id.editHora);
        editData = findViewById(R.id.editDia);
        fechaView = findViewById(R.id.constraintLayout3);

        editTitulo.setText(root.getStringExtra("titulo"));
        editDescricao.setText(root.getStringExtra("descricao"));
        editHora.setText(root.getStringExtra("hora"));
        editData.setText(root.getStringExtra("data"));

        linear = findViewById(R.id.linearAmizades);
    }

    private void listarParticipantes() {
        StringRequest request = new StringRequest(Request.Method.POST, Constants.URL_PARTICIPANTES_LER, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    JSONObject object = new JSONObject(response);
                    JSONArray array = object.getJSONArray("participantes");
                    JSONArray array2 = object.getJSONArray("nomes");
                    listaParticipantes.clear();

                    for (int i = 0; i < array.length(); i++) {
                        JSONObject jsonObject = array.getJSONObject(i);
                        JSONObject jsonObject2 = array2.getJSONObject(i);

                        //add
                        _Amigo objAmigo = new _Amigo();
                        objAmigo.setNome(jsonObject2.getString("nome"));
                        objAmigo.setIdAmigo(Integer.parseInt(jsonObject2.getString("idUsuario")));
                        objAmigo.setIdAmizade(Integer.parseInt(jsonObject.getString("idParticipacao")));
                        listaParticipantes.add(objAmigo);

                    }
                    //listarPedidos();
                    mostrarParticipantes();

                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getApplicationContext(), error.toString(), Toast.LENGTH_SHORT).show();

            }
        }) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                SharedPreferences sharedPreferences = getSharedPreferences("Login", MODE_PRIVATE);
                params.put("idEvento", root.getStringExtra("idEvento"));
                return params;
            }
        };
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(request);
    }
    private void mostrarParticipantes() {
        linear.removeAllViews();

        for (int i = 0; i < listaParticipantes.size(); i++) {
            View view = getLayoutInflater().inflate(R.layout.item_amigo_participante, null);
            TextView itemNome = view.findViewById(R.id.itemNome);
            TextView itemIdAmigo = view.findViewById(R.id.itemIdAmigo);
            TextView itemIdPedido = view.findViewById(R.id.itemIdParticipacao);
            itemNome.setText(listaParticipantes.get(i).getNome());
            itemIdAmigo.setText(String.valueOf(listaParticipantes.get(i).getIdAmigo()));
            itemIdPedido.setText(String.valueOf(listaParticipantes.get(i).getIdAmizade()));
            linear.addView(view);
        }
    }

    public void excluir(View v) {
        StringRequest stringRequest = new StringRequest(Request.Method.POST, Constants.URL_EVENTO_DELETAR, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    Toast.makeText(getApplicationContext(), jsonObject.getString("mensagem"), Toast.LENGTH_SHORT).show();
                    if (jsonObject.getString("erro").equals("false")) {Sair(null);}

                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getApplicationContext(), error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        }){
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String,String> params = new HashMap<>();
                params.put("idEvento", root.getStringExtra("idEvento"));
                return params;
            }
        };
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);

        finish();
    }

    public void excluirParticipante (View v) {
        View cl = v.getRootView();
        TextView idTextView = cl.findViewById(R.id.itemIdParticipacao);
        final String idParticipante = idTextView.getText().toString();
        StringRequest stringRequest = new StringRequest(Request.Method.POST, Constants.URL_PARTICIPANTE_EXCLUIR, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    Toast.makeText(getApplicationContext(), jsonObject.getString("mensagem"), Toast.LENGTH_SHORT).show();
                    listarParticipantes();

                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getApplicationContext(), error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        }){
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String,String> params = new HashMap<>();
                params.put("idParticipacao", idParticipante);
                return params;
            }
        };
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);

    }

    public void salvarEvento(View v) throws ParseException {
        String dataRaw = "";
        dataRaw = String.valueOf(editData.getText());
        final String dataFormatada = sdfBack.format(sdfFront.parse(dataRaw));
        StringRequest stringRequest = new StringRequest(Request.Method.POST, Constants.URL_EVENTO_EDITAR, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    Toast.makeText(getApplicationContext(), jsonObject.getString("mensagem"), Toast.LENGTH_SHORT).show();
                    if (jsonObject.getString("erro").equals("false")) {Sair(null);}

                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getApplicationContext(), error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        }){
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String,String> params = new HashMap<>();
                params.put("idEvento", root.getStringExtra("idEvento"));
                params.put("titulo", String.valueOf(editTitulo.getText()));
                params.put("data", dataFormatada);
                params.put("descricao", String.valueOf(editDescricao.getText()));
                params.put("hora", String.valueOf(editHora.getText()));
                return params;
            }
        };
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);

        finish();
    }
    private void SwipeFecha(){
        fechaView.setOnTouchListener(new OnSwipeTouchListener(TelaEvento.this) {
            public void onSwipeBottom() {
                finish();
            }
        });
    }

    public void irAmigos(View v){
        Intent it = new Intent(this,TelaEventoAmigos.class);
        it.putExtra("idEvento", root.getStringExtra("idEvento"));
        startActivity(it);
    }

    public void Sair(View v) {
        Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                finish();
            }
        }, 200);
    }

}
