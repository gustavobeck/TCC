package com.tcc.daytrackerfinale;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.ColorSpace;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Handler;
import android.view.MenuItem;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.material.navigation.NavigationView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class TelaMes extends AppCompatActivity {
    int oMes, oAno;
    Calendar hoje;
    LinearLayout linearDias;
    NavigationView navigationView;
    DrawerLayout drawer;
    TextView nomeSh, emailSh, idSh;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela_mes);
        //Inicio
        Associar();
        MostraDrawer();
        MostrarMes(oMes, oAno);
        Bolinhas(oMes, oAno);
    }

    public void onResume(){
        SharedPreferences sharedPreferences = getSharedPreferences("Login", MODE_PRIVATE);
        nomeSh.setText(sharedPreferences.getString("nomeKey", ""));
        emailSh.setText(sharedPreferences.getString("emailKey", ""));
        idSh.setText(sharedPreferences.getString("idKey", ""));
        if (sharedPreferences.getString("emailKey", "").equals("")) {
            Intent it = new Intent(getApplicationContext(), TelaLogin.class);
            startActivity(it);
            finish();
        } else {
            Bolinhas(oMes, oAno);
        }
        super.onResume();
    }

    private void Associar() {
        hoje = Calendar.getInstance();
        oMes = hoje.get(Calendar.MONTH);
        oAno = hoje.get(Calendar.YEAR);
        linearDias = findViewById(R.id.CalendarioLayout);
        drawer = findViewById(R.id.drawer);
        navigationView = findViewById(R.id.navigationView);
        View navView = navigationView.inflateHeaderView(R.layout.header_01);
        nomeSh = navView.findViewById(R.id.textViewNomeGlobal);
        emailSh = navView.findViewById(R.id.textViewEmailGlobal);
        idSh = navView.findViewById(R.id.textViewId);
    }

    private void MostraDrawer() {
        SharedPreferences sh = getSharedPreferences("Login", Context.MODE_PRIVATE);
        nomeSh.setText(sh.getString("nomeKey", ""));
        emailSh.setText(sh.getString("emailKey", ""));
        idSh.setText(sh.getString("idKey", ""));
    }

    List<_Bolinha> listaBolinhas = new ArrayList<>();
    List<_Bolinha> listaBolinhasAzul = new ArrayList<>();
    private void Bolinhas(final int mes1, final int ano1){
        final SimpleDateFormat sdfBack = new SimpleDateFormat("yyyy/MM/dd");

        Calendar comeco = Calendar.getInstance();
        comeco.set(Calendar.MONTH, mes1);
        comeco.set(Calendar.YEAR, ano1);
        comeco.set(Calendar.DAY_OF_MONTH, 1);
        Calendar fim = Calendar.getInstance();
        fim.set(Calendar.MONTH, mes1+1);
        fim.set(Calendar.YEAR, ano1);
        fim.set(Calendar.DAY_OF_MONTH, 1);
        fim.add(Calendar.DAY_OF_MONTH, 14);

        comeco.add(Calendar.DATE, -6);

        final Date cDate = comeco.getTime();
        final Date fDate = fim.getTime();

        StringRequest request = new StringRequest(Request.Method.POST, Constants.URL_MES_BOLINHAS, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    JSONObject object = new JSONObject(response);
                    JSONArray array = object.getJSONArray("Bolinhas");
                    listaBolinhas.clear();
                    for (int i = 0; i < array.length(); i++) {
                        JSONObject jsonObject = array.getJSONObject(i);
                        _Bolinha objContador = new _Bolinha();
                        objContador.setData(jsonObject.getString("data"));
                        listaBolinhas.add(objContador);
                    }
                    JSONArray array2 = object.getJSONArray("BolinhasAzul");
                    listaBolinhasAzul.clear();
                    for (int i = 0; i < array2.length(); i++) {
                        JSONObject jsonObject = array2.getJSONObject(i);
                        _Bolinha objContador = new _Bolinha();
                        objContador.setData(jsonObject.getString("data"));
                        listaBolinhasAzul.add(objContador);
                    }
                    MostrarMes(oMes, oAno);
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getApplicationContext(), error.toString(), Toast.LENGTH_SHORT).show();

            }
        }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<>();
                SharedPreferences sharedPreferences = getSharedPreferences("Login", MODE_PRIVATE);
                params.put("idCriador", sharedPreferences.getString("idKey", ""));
                params.put("dataComeco", sdfBack.format(cDate));
                params.put("dataFim", sdfBack.format(fDate));
                return params;
            }
        };
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(request);
    }

    private void MostrarMes(int numMes, int numAno){
        SimpleDateFormat sdpMes = new SimpleDateFormat("MMMM");
        SimpleDateFormat sdpAno = new SimpleDateFormat("yyyy");
        SimpleDateFormat sdfData = new SimpleDateFormat("yyyy/MM/dd");
        LinearLayout[] linear = {findViewById(R.id.linear1), findViewById(R.id.linear2), findViewById(R.id.linear3), findViewById(R.id.linear4), findViewById(R.id.linear5), findViewById(R.id.linear6)};

        Calendar comeco = Calendar.getInstance();
        TextView mesTV = findViewById(R.id.mesTV);

        comeco.set(Calendar.YEAR, numAno);
        comeco.set(Calendar.MONTH, numMes);
        comeco.set(Calendar.DAY_OF_MONTH, 1);

        Date mesDate = comeco.getTime();

        int DiaSemana = 0;
        if (comeco.get(Calendar.DAY_OF_WEEK) == Calendar.SUNDAY) {DiaSemana = 0;}
        else if (comeco.get(Calendar.DAY_OF_WEEK) == Calendar.MONDAY) {DiaSemana = 1;}
        else if (comeco.get(Calendar.DAY_OF_WEEK) == Calendar.TUESDAY) {DiaSemana = 2;}
        else if (comeco.get(Calendar.DAY_OF_WEEK) == Calendar.WEDNESDAY) {DiaSemana = 3;}
        else if (comeco.get(Calendar.DAY_OF_WEEK) == Calendar.THURSDAY) {DiaSemana = 4;}
        else if (comeco.get(Calendar.DAY_OF_WEEK) == Calendar.FRIDAY) {DiaSemana = 5;}
        else if (comeco.get(Calendar.DAY_OF_WEEK) == Calendar.SATURDAY) {DiaSemana = 6;}
        comeco.add(Calendar.DATE, -DiaSemana);

        for (int i = 0; i < 6; i++){ linear[i].removeAllViews();}

        mesTV.setText(sdpMes.format(mesDate) + " de " + sdpAno.format(mesDate));
        for (int i = 0; i < 6; i++) {
            for (int j = 0; j < 7; j++) {
                View view = getLayoutInflater().inflate(R.layout.item_dia_do_mes, null);
                TextView diaTV = view.findViewById(R.id.itemDia);
                TextView itemData = view.findViewById(R.id.itemData);

                diaTV.setText(String.valueOf(comeco.get(Calendar.DAY_OF_MONTH)));
                itemData.setText(sdfData.format(comeco.getTime()));
                view.setLayoutParams(new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        1
                ));

                ConstraintLayout cl = view.findViewById(R.id.itemBackground);
                boolean branca = false;
                if (comeco.get(Calendar.DAY_OF_YEAR) == hoje.get(Calendar.DAY_OF_YEAR) && comeco.get(Calendar.YEAR) == hoje.get(Calendar.YEAR) && comeco.get(Calendar.MONTH) == numMes) {
                    //cl.setBackgroundColor(Color.rgb(230,57,70));
                    cl.setBackground(getDrawable(R.drawable.diahoje));
                    branca = true;
                }
                else if (comeco.get(Calendar.DAY_OF_YEAR) == hoje.get(Calendar.DAY_OF_YEAR) && comeco.get(Calendar.YEAR) == hoje.get(Calendar.YEAR) && comeco.get(Calendar.MONTH) != numMes) {
                    //cl.setBackgroundColor(Color.rgb(190,130,130));
                    cl.setBackground(getDrawable(R.drawable.diafora));
                }
                else if (comeco.get(Calendar.MONTH) == numMes) {
                    //cl.setBackgroundColor(Color.rgb(241,250,238));
                    cl.setBackground(getDrawable(R.drawable.dia));
                } else {
                    //cl.setBackgroundColor(Color.rgb(168,218,220));
                    cl.setBackground(getDrawable(R.drawable.diafora));
                }

                // Adiciona os compromissos do contador
                LinearLayout linearBolinhas = view.findViewById(R.id.itemLinear);
                for (int k = 0; k < listaBolinhas.size(); k++) {
                    if (listaBolinhas.get(k).getData().equals(itemData.getText().toString())) {
                        View v;
                        if (branca) {v = getLayoutInflater().inflate(R.layout.item_bolinha_branca, null);}
                        else {v = getLayoutInflater().inflate(R.layout.item_bolinha, null);}
                        linearBolinhas.addView(v);
                    }
                }
                for (int k = 0; k < listaBolinhasAzul.size(); k++) {
                    if (listaBolinhasAzul.get(k).getData().equals(itemData.getText().toString())) {
                        View v = getLayoutInflater().inflate(R.layout.item_bolinha_azul, null);
                        linearBolinhas.addView(v);
                    }
                }

                linear[i].addView(view);
                comeco.add(Calendar.DATE, 1);
            }
        }
    }

    public void somaMes(View v){
        Pulsar(v);
        oMes++;
        if (oMes > 11) {oMes = 0;oAno++;}
        Bolinhas(oMes, oAno);
    }
    public void subMes(View v){
        Pulsar(v);
        oMes--;
        if (oMes < 0) {oMes = 11;oAno--;}
        Bolinhas(oMes, oAno);
    }
    public void abrirDrawer(View v) {
        Pulsar(v);
        drawer.openDrawer(GravityCompat.START);
    }
    private void Pulsar(final View v) {
        v.animate().scaleX(2F).scaleY(2F).start();
        Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                v.animate().scaleX(1.0F).scaleY(1.0F).start();
            }
        }, 100);
    }

    public void irCompromissosDoDia(View v) {
        Intent it = new Intent(this, TelaDia.class);
        TextView dataTV = v.findViewById(R.id.itemData);
        it.putExtra("dia", dataTV.getText());
        startActivity(it);
    }
    public void irAmigos(MenuItem item) {
        Intent it = new Intent(this, TelaAmigos.class);
        startActivity(it);
    }
    public void irConvites(MenuItem item) {
        Intent it = new Intent(this, TelaConvites.class);
        startActivity(it);
    }
    public void irConfigConta(MenuItem item) {
        Intent it = new Intent(this, TelaConfiguracaoConta.class);
        startActivity(it);
        drawer.closeDrawers();
    }
}