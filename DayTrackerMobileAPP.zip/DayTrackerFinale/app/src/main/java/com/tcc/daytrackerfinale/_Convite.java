package com.tcc.daytrackerfinale;

public class _Convite {
    int idConvite,idEvento;
    String nome;

    public int getIdConvite() {
        return idConvite;
    }

    public void setIdConvite(int idConvite) {
        this.idConvite = idConvite;
    }

    public int getIdEvento() {
        return idEvento;
    }

    public void setIdEvento(int idEvento) {
        this.idEvento = idEvento;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }
}
