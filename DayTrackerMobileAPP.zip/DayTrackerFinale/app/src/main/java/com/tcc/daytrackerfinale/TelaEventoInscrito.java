package com.tcc.daytrackerfinale;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class TelaEventoInscrito extends AppCompatActivity {
    TextView editTitulo, editDescricao, editHora, editData;
    Intent root;
    SimpleDateFormat sdfFront = new SimpleDateFormat("dd/MM/yyyy");
    SimpleDateFormat sdfBack = new SimpleDateFormat("yyyy/MM/dd");
    ConstraintLayout fechaView;
    LinearLayout linear;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela_evento_inscrito);

        Associar();
        SwipeFecha();

        String dataFormatada = "";
        try {
            dataFormatada = sdfFront.format(sdfBack.parse(root.getStringExtra("dia")));
        } catch (ParseException e) {
            e.printStackTrace();
        }
        editData.setText(dataFormatada);
    }

    private void Associar() {
        root = getIntent();

        editTitulo = findViewById(R.id.editTitulo);
        editDescricao = findViewById(R.id.editDescricao);
        editHora = findViewById(R.id.editHora);
        editData = findViewById(R.id.editDia);
        fechaView = findViewById(R.id.constraintLayout3);

        editTitulo.setText(root.getStringExtra("titulo"));
        editDescricao.setText(root.getStringExtra("descricao"));
        editHora.setText(root.getStringExtra("hora"));
        editData.setText(root.getStringExtra("data"));

        linear = findViewById(R.id.linearAmizades);
    }

    private void SwipeFecha(){
        fechaView.setOnTouchListener(new OnSwipeTouchListener(TelaEventoInscrito.this) {
            public void onSwipeBottom() {
                finish();
            }
        });
    }

    public void sairDoEvento(View v) {
        StringRequest stringRequest = new StringRequest(Request.Method.POST, Constants.URL_EVENTO_SAIR, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    Toast.makeText(getApplicationContext(), jsonObject.getString("mensagem"), Toast.LENGTH_SHORT).show();

                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getApplicationContext(), error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        }){
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String,String> params = new HashMap<>();
                params.put("idEvento", root.getStringExtra("idEvento"));
                SharedPreferences sharedPreferences = getSharedPreferences("Login", MODE_PRIVATE);
                params.put("idUsuario", sharedPreferences.getString("idKey", ""));
                return params;
            }
        };
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);

        finish();
    }
    public void Sair(View v) {
        Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                finish();
            }
        }, 200);
    }
}