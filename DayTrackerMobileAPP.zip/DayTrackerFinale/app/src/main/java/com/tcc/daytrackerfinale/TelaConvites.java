package com.tcc.daytrackerfinale;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class TelaConvites extends AppCompatActivity {
    LinearLayout linear;
    List<_Convite> listaConvites = new ArrayList<>();
    EditText editNome, editId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela_convites);

        linear = findViewById(R.id.linearAmizades);

        listarConvites();

        editNome = findViewById(R.id.editAmigoNome);
        editId = findViewById(R.id.editAmigoId);
    }

    private void listarConvites() {
        StringRequest request = new StringRequest(Request.Method.POST, Constants.URL_PARTICIPANTE_CONVITE_LER, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    JSONObject object = new JSONObject(response);
                    JSONArray array = object.getJSONArray("convites");
                    JSONArray array2 = object.getJSONArray("eventos");
                    listaConvites.clear();

                    for (int i = 0; i < array.length(); i++) {
                        JSONObject jsonObject = array.getJSONObject(i);
                        JSONObject jsonObject2 = array2.getJSONObject(i);

                        //add
                        _Convite objAmigo = new _Convite();
                        objAmigo.setNome(jsonObject2.getString("titulo"));
                        objAmigo.setIdConvite(Integer.parseInt(jsonObject2.getString("idEvento")));
                        objAmigo.setIdConvite(Integer.parseInt(jsonObject.getString("idConvite")));
                        listaConvites.add(objAmigo);

                    }
                    mostrarParticipantes();

                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getApplicationContext(), error.toString(), Toast.LENGTH_SHORT).show();

            }
        }) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                SharedPreferences sharedPreferences = getSharedPreferences("Login", MODE_PRIVATE);
                params.put("idUsuario", sharedPreferences.getString("idKey", ""));
                return params;
            }
        };
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(request);
    }
    private void mostrarParticipantes() {
        linear.removeAllViews();
        for (int i = 0; i < listaConvites.size(); i++) {
            View view = getLayoutInflater().inflate(R.layout.item_convite, null);
            TextView itemNome = view.findViewById(R.id.itemNome);
            TextView itemIdAmigo = view.findViewById(R.id.itemIdEvento);
            TextView itemIdPedido = view.findViewById(R.id.itemIdConvite);
            itemNome.setText(listaConvites.get(i).getNome());
            itemIdAmigo.setText(String.valueOf(listaConvites.get(i).getIdEvento()));
            itemIdPedido.setText(String.valueOf(listaConvites.get(i).getIdConvite()));
            linear.addView(view);
        }
    }

    public void aceitarConvite(View v) {
        View cl = v.getRootView();
        TextView idTextView = cl.findViewById(R.id.itemIdConvite);
        final String idConvite = idTextView.getText().toString();

        StringRequest stringRequest = new StringRequest(Request.Method.POST, Constants.URL_PARTICIPANTE_CONVITE_ACEITAR, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    Toast.makeText(getApplicationContext(), jsonObject.getString("mensagem"), Toast.LENGTH_SHORT).show();
                    listarConvites();
                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getApplicationContext(), error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        }){
            @Override
            protected Map<String, String> getParams(){
                Map<String,String> params = new HashMap<>();
                params.put("idConvite", idConvite);
                return params;
            }
        };
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);

    }
    public void negarConvite(View v) {
        View cl = v.getRootView();
        TextView idTextView = cl.findViewById(R.id.itemIdConvite);
        final String idConvite = idTextView.getText().toString();

        StringRequest stringRequest = new StringRequest(Request.Method.POST, Constants.URL_PARTICIPANTE_CONVITE_RECUSAR, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    Toast.makeText(getApplicationContext(), jsonObject.getString("mensagem"), Toast.LENGTH_SHORT).show();
                    listarConvites();
                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getApplicationContext(), error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        }){
            @Override
            protected Map<String, String> getParams(){
                Map<String,String> params = new HashMap<>();
                params.put("idConvite", idConvite);
                return params;
            }
        };
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);
    }
    public void Sair(View v) {
        finish();
    }

}
