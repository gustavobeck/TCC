package com.tcc.daytrackerfinale;

import android.content.Intent;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class InicioActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inicio);

        irLogin(); //TODO check login antes de logar

    }
    private void irLogin(){
        Intent it = new Intent(this,TelaLogin.class);
        startActivity(it);
        finish();
    }
}
