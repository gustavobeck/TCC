package com.tcc.daytrackerfinale;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class TelaAmigos extends AppCompatActivity {
    LinearLayout linear;
    List<_Amigo> listaAmigos = new ArrayList<_Amigo>();
    List<_PedidoAmigo> listaPedidos = new ArrayList<_PedidoAmigo>();
    EditText editNome, editId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela_amigos);

        linear = findViewById(R.id.linearAmizades);

        listarAmizades();

        editNome = findViewById(R.id.editAmigoNome);
        editId = findViewById(R.id.editAmigoId);
    }

    private void listarAmizades() {
        StringRequest request = new StringRequest(Request.Method.POST, Constants.URL_AMIGOS_AMIZADES_LER, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    JSONObject object = new JSONObject(response);
                    JSONArray array = object.getJSONArray("amizades");
                    JSONArray array2 = object.getJSONArray("amigos");
                    listaAmigos.clear();

                    for (int i = 0; i < array.length(); i++) {
                        JSONObject jsonObject = array.getJSONObject(i);
                        JSONObject jsonObject2 = array2.getJSONObject(i);

                        //add
                        _Amigo objAmigo = new _Amigo();
                        objAmigo.setNome(jsonObject2.getString("nome"));
                        objAmigo.setIdAmigo(Integer.parseInt(jsonObject2.getString("idUsuario")));
                        objAmigo.setIdAmizade(Integer.parseInt(jsonObject.getString("idAmizade")));
                        listaAmigos.add(objAmigo);

                    }
                    listarPedidos();

                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getApplicationContext(), error.toString(), Toast.LENGTH_SHORT).show();

            }
        }) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                SharedPreferences sharedPreferences = getSharedPreferences("Login", MODE_PRIVATE);
                params.put("idUsuario", sharedPreferences.getString("idKey", ""));
                return params;
            }
        };
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(request);
    }
    private void listarPedidos() {
        StringRequest request = new StringRequest(Request.Method.POST, Constants.URL_AMIGOS_PEDIDOS_LER, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    JSONObject object = new JSONObject(response);
                    JSONArray array = object.getJSONArray("pedidos");
                    JSONArray array2 = object.getJSONArray("amigos");
                    listaPedidos.clear();

                    for (int i = 0; i < array.length(); i++) {
                        JSONObject jsonObject = array.getJSONObject(i);
                        JSONObject jsonObject2 = array2.getJSONObject(i);

                        //add
                        _PedidoAmigo objPedido = new _PedidoAmigo();
                        objPedido.setNome(jsonObject2.getString("nome"));
                        objPedido.setIdAmigo(Integer.parseInt(jsonObject2.getString("idUsuario")));
                        objPedido.setIdPedido(Integer.parseInt(jsonObject.getString("idPedido")));
                        listaPedidos.add(objPedido);

                    }
                    mostrarAmigosPedidos();

                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getApplicationContext(), error.toString(), Toast.LENGTH_SHORT).show();

            }
        }) {
            @Override
            protected Map<String, String> getParams(){
                Map<String, String> params = new HashMap<>();
                SharedPreferences sharedPreferences = getSharedPreferences("Login", MODE_PRIVATE);
                params.put("idUsuario", sharedPreferences.getString("idKey", ""));
                return params;
            }
        };
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(request);
    }
    private void mostrarAmigosPedidos() {
        linear.removeAllViews();
        for (int i = 0; i < listaAmigos.size(); i++) {
            View view = getLayoutInflater().inflate(R.layout.item_amigo, null);
            TextView itemNome = view.findViewById(R.id.itemNome);
            TextView itemIdAmigo = view.findViewById(R.id.itemIdAmigo);
            TextView itemIdAmizade = view.findViewById(R.id.itemIdAmizade);
            itemNome.setText(listaAmigos.get(i).getNome());
            itemIdAmigo.setText(String.valueOf(listaAmigos.get(i).getIdAmigo()));
            itemIdAmizade.setText(String.valueOf(listaAmigos.get(i).getIdAmizade()));
            linear.addView(view);
        }
        if (listaPedidos.size() > 0) {separador("Pedidos recebidos");}
        for (int i = 0; i < listaPedidos.size(); i++) {
            View view = getLayoutInflater().inflate(R.layout.item_pedido_amizade, null);
            TextView itemNome = view.findViewById(R.id.itemNome);
            TextView itemIdAmigo = view.findViewById(R.id.itemIdAmigo);
            TextView itemIdPedido = view.findViewById(R.id.itemIdPedido);
            itemNome.setText(listaPedidos.get(i).getNome());
            itemIdAmigo.setText(String.valueOf(listaPedidos.get(i).getIdAmigo()));
            itemIdPedido.setText(String.valueOf(listaPedidos.get(i).getIdPedido()));
            linear.addView(view);
        }
    }
    private void separador(String stg){
        View view = getLayoutInflater().inflate(R.layout.separador_horizontal, null);
        TextView textDia = view.findViewById(R.id.separadorDia);
        textDia.setText(stg);
        linear.addView(view);
    }

    public void mandarPedido(View v){
        StringRequest stringRequest = new StringRequest(Request.Method.POST, Constants.URL_AMIGOS_PEDIDO_ENVIAR, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    Toast.makeText(getApplicationContext(), jsonObject.getString("mensagem"), Toast.LENGTH_SHORT).show();

                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getApplicationContext(), error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        }){
            @Override
            protected Map<String, String> getParams(){
                Map<String,String> params = new HashMap<>();
                SharedPreferences sharedPreferences = getSharedPreferences("Login", MODE_PRIVATE);
                params.put("idUsuario", sharedPreferences.getString("idKey", ""));
                params.put("idAmigo", editId.getText().toString().trim());
                params.put("nomeAmigo", editNome.getText().toString().trim());
                return params;
            }
        };
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);
    }

    public void aceitarPedido(View v) {
        View cl = (View) v.getParent();
        TextView idTextView = cl.findViewById(R.id.itemIdPedido);
        final String idPedido = idTextView.getText().toString();

        StringRequest stringRequest = new StringRequest(Request.Method.POST, Constants.URL_AMIGOS_PEDIDO_ACEITAR, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    Toast.makeText(getApplicationContext(), jsonObject.getString("mensagem"), Toast.LENGTH_SHORT).show();
                    listarAmizades();
                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getApplicationContext(), error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        }){
            @Override
            protected Map<String, String> getParams(){
                Map<String,String> params = new HashMap<>();
                params.put("idPedido", idPedido);
                return params;
            }
        };
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);

    }
    public void negarPedido(View v) {
        View cl = (View) v.getParent();
        TextView idTextView = cl.findViewById(R.id.itemIdPedido);
        final String idPedido = idTextView.getText().toString();

        StringRequest stringRequest = new StringRequest(Request.Method.POST, Constants.URL_AMIGOS_PEDIDO_RECUSAR, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    Toast.makeText(getApplicationContext(), jsonObject.getString("mensagem"), Toast.LENGTH_SHORT).show();
                    listarAmizades();
                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getApplicationContext(), error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        }){
            @Override
            protected Map<String, String> getParams(){
                Map<String,String> params = new HashMap<>();
                params.put("idPedido", idPedido);
                return params;
            }
        };
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);
    }

    public void excluirAmigo(View v) {
        View cl = (View) v.getParent();
        TextView idTextView = cl.findViewById(R.id.itemIdAmizade);
        final String idAmizade = idTextView.getText().toString();

        StringRequest stringRequest = new StringRequest(Request.Method.POST, Constants.URL_AMIGOS_AMIZADE_EXCLUIR, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    Toast.makeText(getApplicationContext(), jsonObject.getString("mensagem"), Toast.LENGTH_SHORT).show();
                    listarAmizades();
                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getApplicationContext(), error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        }){
            @Override
            protected Map<String, String> getParams(){
                Map<String,String> params = new HashMap<>();
                params.put("idAmizade", idAmizade);
                return params;
            }
        };
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);

    }
    public void Sair(View v) {
        finish();
    }

}
