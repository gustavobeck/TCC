package com.tcc.daytrackerfinale;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class TelaDia extends AppCompatActivity {
    TextView diaTV, nadaTV;
    LinearLayout linear;
    List<_Compromisso> lista = new ArrayList<_Compromisso>();
    List<_Evento> lista2 = new ArrayList<_Evento>();
    List<_Evento> lista3 = new ArrayList<_Evento>();
    List<_Anotacao> lista4 = new ArrayList<_Anotacao>();
    Intent root;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela_dia);

        Associar();
        SwipeFecha();
        MostrarData();
        try {
            listaCompromisso();
        } catch (ParseException e) {
            e.printStackTrace();
        }
    }

    protected void onResume() {
        Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                try {
                    listaCompromisso();
                } catch (ParseException e) {
                    e.printStackTrace();
                }
            }
        }, 200);
        super.onResume();
    }

    private void Associar() {
        diaTV = findViewById(R.id.diaCompromissosTV);
        linear = findViewById(R.id.linearCompromissos);
        root = getIntent();
        nadaTV = findViewById(R.id.nadaTV);

        FloatingActionButton fab = findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent it = new Intent(getApplicationContext(), TelaCompromissoCria.class);
                it.putExtra("dia", root.getStringExtra("dia"));
                startActivity(it);
            }
        });

        FloatingActionButton fab2 = findViewById(R.id.fab2);
        fab2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent it = new Intent(getApplicationContext(), TelaEventoCria.class);
                it.putExtra("dia", root.getStringExtra("dia"));
                startActivity(it);
            }
        });

        FloatingActionButton fab3 = findViewById(R.id.fab3);
        fab3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent it = new Intent(getApplicationContext(), TelaAnotacaoCria.class);
                it.putExtra("dia", root.getStringExtra("dia"));
                startActivity(it);
            }
        });
    }
    private void SwipeFecha(){
        linear.setOnTouchListener(new OnSwipeTouchListener(TelaDia.this) {
            public void onSwipeBottom() {
                finish();
            }
        });
    }
    private void MostrarData() {
        SimpleDateFormat sdfFront = new SimpleDateFormat("dd/MM/yyyy");
        SimpleDateFormat sdfBack = new SimpleDateFormat("yyyy/MM/dd");

        String diaFormatado = null;
        try {
            diaFormatado = sdfFront.format(sdfBack.parse(root.getStringExtra("dia")));
        } catch (ParseException e) {
            e.printStackTrace();
        }
        diaTV.setText(diaFormatado);
    }

    private void listaCompromisso() throws ParseException {
        SimpleDateFormat sdfFront = new SimpleDateFormat("dd/MM/yyyy");
        SimpleDateFormat sdfBack = new SimpleDateFormat("yyyy/MM/dd");

        final String data = sdfBack.format(sdfBack.parse(root.getStringExtra("dia")));

        StringRequest request = new StringRequest(Request.Method.POST, Constants.URL_DIA_LER_COMPROMISSOS, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    JSONObject object = new JSONObject(response);
                    JSONArray array = object.getJSONArray("compromissos");
                    lista.clear();
                    for (int i = 0; i < array.length(); i++) {
                        JSONObject jsonObject = array.getJSONObject(i);
                        _Compromisso objCompromisso = new _Compromisso();
                        objCompromisso.setCriador(jsonObject.getString("criador"));
                        objCompromisso.setTitulo(jsonObject.getString("titulo"));
                        objCompromisso.setIdCompromisso(Integer.parseInt(jsonObject.getString("idCompromisso")));
                        objCompromisso.setHora(jsonObject.getString("hora"));
                        objCompromisso.setData(jsonObject.getString("data"));
                        objCompromisso.setDescricao(jsonObject.getString("descricao"));
                        objCompromisso.setTipo(jsonObject.getString("tipo"));
                        lista.add(objCompromisso);
                    }
                    listaEventos();
                } catch (JSONException | ParseException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getApplicationContext(), error.toString(), Toast.LENGTH_SHORT).show();

            }
        }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<>();
                SharedPreferences sharedPreferences = getSharedPreferences("Login", MODE_PRIVATE);
                params.put("criador", sharedPreferences.getString("idKey", ""));
                params.put("data", data);
                return params;
            }
        };
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(request);
    }
    private void listaEventos() throws ParseException { //TODO LER EVENTOS QUE PARTICIPA
        SimpleDateFormat sdfFront = new SimpleDateFormat("dd/MM/yyyy");
        SimpleDateFormat sdfBack = new SimpleDateFormat("yyyy/MM/dd");

        final String data = sdfBack.format(sdfBack.parse(root.getStringExtra("dia")));

        StringRequest request = new StringRequest(Request.Method.POST, Constants.URL_DIA_LER_EVENTOS, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    JSONObject object = new JSONObject(response);
                    JSONArray array = object.getJSONArray("eventos");
                    lista2.clear();
                    for (int i = 0; i < array.length(); i++) {
                        JSONObject jsonObject = array.getJSONObject(i);
                        _Evento objEvento = new _Evento();
                        objEvento.setCriador(jsonObject.getString("criador"));
                        objEvento.setTitulo(jsonObject.getString("titulo"));
                        objEvento.setIdEvento(Integer.parseInt(jsonObject.getString("idEvento")));
                        objEvento.setHora(jsonObject.getString("hora"));
                        objEvento.setData(jsonObject.getString("data"));
                        objEvento.setDescricao(jsonObject.getString("descricao"));
                        lista2.add(objEvento);
                    }
                    listaEventosInscritos();

                } catch (JSONException | ParseException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getApplicationContext(), error.toString(), Toast.LENGTH_SHORT).show();

            }
        }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<>();
                SharedPreferences sharedPreferences = getSharedPreferences("Login", MODE_PRIVATE);
                params.put("criador", sharedPreferences.getString("idKey", ""));
                params.put("data", data);
                return params;
            }
        };
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(request);
    }
    private void listaEventosInscritos() throws ParseException { //TODO LER EVENTOS QUE PARTICIPA
        SimpleDateFormat sdfFront = new SimpleDateFormat("dd/MM/yyyy");
        SimpleDateFormat sdfBack = new SimpleDateFormat("yyyy/MM/dd");

        final String data = sdfBack.format(sdfBack.parse(root.getStringExtra("dia")));

        StringRequest request = new StringRequest(Request.Method.POST, Constants.URL_DIA_LER_EVENTOS_INSCRITOS, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    JSONObject object = new JSONObject(response);
                    JSONArray array = object.getJSONArray("eventosinscritos");
                    lista3.clear();
                    for (int i = 0; i < array.length(); i++) {
                        JSONObject jsonObject = array.getJSONObject(i);
                        _Evento objEvento = new _Evento();
                        objEvento.setCriador(jsonObject.getString("criador"));
                        objEvento.setTitulo(jsonObject.getString("titulo"));
                        objEvento.setIdEvento(Integer.parseInt(jsonObject.getString("idEvento")));
                        objEvento.setHora(jsonObject.getString("hora"));
                        objEvento.setData(jsonObject.getString("data"));
                        objEvento.setDescricao(jsonObject.getString("descricao"));
                        lista3.add(objEvento);
                    }
                    listaAnotacoes();

                } catch (JSONException | ParseException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getApplicationContext(), error.toString(), Toast.LENGTH_SHORT).show();

            }
        }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<>();
                SharedPreferences sharedPreferences = getSharedPreferences("Login", MODE_PRIVATE);
                params.put("idUsuario", sharedPreferences.getString("idKey", ""));
                params.put("data", data);
                return params;
            }
        };
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(request);
    }
    private void listaAnotacoes() throws ParseException { //TODO LER EVENTOS QUE PARTICIPA
        SimpleDateFormat sdfFront = new SimpleDateFormat("dd/MM/yyyy");
        SimpleDateFormat sdfBack = new SimpleDateFormat("yyyy/MM/dd");

        final String data = sdfBack.format(sdfBack.parse(root.getStringExtra("dia")));

        StringRequest request = new StringRequest(Request.Method.POST, Constants.URL_DIA_LER_ANOTACOES, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    JSONObject object = new JSONObject(response);
                    JSONArray array = object.getJSONArray("anotacoes");
                    lista4.clear();
                    for (int i = 0; i < array.length(); i++) {
                        JSONObject jsonObject = array.getJSONObject(i);
                        _Anotacao objAnotacao = new _Anotacao();
                        objAnotacao.setCriador(jsonObject.getString("criador"));
                        objAnotacao.setConteudo(jsonObject.getString("conteudo"));
                        objAnotacao.setTitulo(jsonObject.getString("titulo"));
                        objAnotacao.setIdAnotacao(Integer.parseInt(jsonObject.getString("idAnotacao")));
                        objAnotacao.setData(jsonObject.getString("data"));
                        lista4.add(objAnotacao);
                    }
                    mostrarCompromissosEventosAnotacoes();
                    if (linear.getChildCount()>0) {
                        nadaTV.setVisibility(View.INVISIBLE);
                    } else {
                        nadaTV.setVisibility(View.VISIBLE);
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getApplicationContext(), error.toString(), Toast.LENGTH_SHORT).show();

            }
        }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<>();
                SharedPreferences sharedPreferences = getSharedPreferences("Login", MODE_PRIVATE);
                params.put("criador", sharedPreferences.getString("idKey", ""));
                params.put("data", data);
                return params;
            }
        };
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(request);
    }
    private void mostrarCompromissosEventosAnotacoes(){
        linear.removeAllViews();
        if (lista.size() > 0) {
            separador("Meus Compromissos:");
        }
        for (int i = 0; i < lista.size(); i++) {
            View view = getLayoutInflater().inflate(R.layout.item_compromisso, null);
            TextView itemTitulo = view.findViewById(R.id.itemTitulo);
            TextView itemCriador = view.findViewById(R.id.itemCriador);
            TextView itemData = view.findViewById(R.id.itemData);
            TextView itemHora = view.findViewById(R.id.itemHora);
            TextView itemDescricao = view.findViewById(R.id.itemDescricao);
            TextView itemIdCompromisso = view.findViewById(R.id.itemIdCompromisso);
            TextView itemTipo = view.findViewById(R.id.itemTipo);
            itemTitulo.setText(lista.get(i).getTitulo());
            itemCriador.setText(lista.get(i).getCriador());
            itemData.setText(lista.get(i).getData());
            itemHora.setText(lista.get(i).getHora());
            itemDescricao.setText(lista.get(i).getDescricao());
            itemTipo.setText(lista.get(i).getTipo());
            itemIdCompromisso.setText(String.valueOf(lista.get(i).getIdCompromisso()));
            linear.addView(view);
        }
        if (lista2.size() > 0) {
            separador("Meus Eventos:");
        }
        for (int i = 0; i < lista2.size(); i++) {
            View view = getLayoutInflater().inflate(R.layout.item_evento, null);
            TextView itemTitulo = view.findViewById(R.id.itemTitulo);
            TextView itemCriador = view.findViewById(R.id.itemCriador);
            TextView itemData = view.findViewById(R.id.itemData);
            TextView itemHora = view.findViewById(R.id.itemHora);
            TextView itemDescricao = view.findViewById(R.id.itemDescricao);
            TextView itemIdCompromisso = view.findViewById(R.id.itemIdEvento);
            itemTitulo.setText(lista2.get(i).getTitulo());
            itemCriador.setText(lista2.get(i).getCriador());
            itemData.setText(lista2.get(i).getData());
            itemHora.setText(lista2.get(i).getHora());
            itemDescricao.setText(lista2.get(i).getDescricao());
            itemIdCompromisso.setText(String.valueOf(lista2.get(i).getIdEvento()));
            linear.addView(view);
        }
        if (lista3.size() > 0) {
            separador("Eventos Inscritos:");
        }
        for (int i = 0; i < lista3.size(); i++) {
            View view = getLayoutInflater().inflate(R.layout.item_evento_inscrito, null);
            TextView itemTitulo = view.findViewById(R.id.itemTitulo);
            TextView itemCriador = view.findViewById(R.id.itemCriador);
            TextView itemData = view.findViewById(R.id.itemData);
            TextView itemHora = view.findViewById(R.id.itemHora);
            TextView itemDescricao = view.findViewById(R.id.itemDescricao);
            TextView itemIdCompromisso = view.findViewById(R.id.itemIdEvento);
            itemTitulo.setText(lista3.get(i).getTitulo());
            itemCriador.setText(lista3.get(i).getCriador());
            itemData.setText(lista3.get(i).getData());
            itemHora.setText(lista3.get(i).getHora());
            itemDescricao.setText(lista3.get(i).getDescricao());
            itemIdCompromisso.setText(String.valueOf(lista3.get(i).getIdEvento()));
            linear.addView(view);
        }
        if (lista4.size() > 0) {
            separador("Anotações:");
        }
        for (int i = 0; i < lista4.size(); i++) {
            View view = getLayoutInflater().inflate(R.layout.item_anotacao, null);
            TextView itemTitulo = view.findViewById(R.id.itemTitulo);
            TextView itemCriador = view.findViewById(R.id.itemCriador);
            TextView itemData = view.findViewById(R.id.itemData);
            TextView itemConteudo = view.findViewById(R.id.itemConteudo);
            TextView itemIdAnotacao = view.findViewById(R.id.itemIdAnotacao);
            itemTitulo.setText(lista4.get(i).getTitulo());
            itemCriador.setText(lista4.get(i).getCriador());
            itemData.setText(lista4.get(i).getData());
            itemConteudo.setText(lista4.get(i).getConteudo());
            itemIdAnotacao.setText(String.valueOf(lista4.get(i).getIdAnotacao()));
            linear.addView(view);
        }
    }

    private void separador(String stg){
        View view = getLayoutInflater().inflate(R.layout.separador_horizontal, null);
        TextView textDia = view.findViewById(R.id.separadorDia);
        textDia.setText(stg);
        linear.addView(view);
    }

    public void clicaCompromisso(View v) {
        TextView itemTitulo = v.findViewById(R.id.itemTitulo);
        TextView itemTipo = v.findViewById(R.id.itemTipo);
        TextView itemData = v.findViewById(R.id.itemData);
        TextView itemHora = v.findViewById(R.id.itemHora);
        TextView itemDescricao = v.findViewById(R.id.itemDescricao);
        TextView itemCriador = v.findViewById(R.id.itemCriador);
        TextView itemIdCompromisso = v.findViewById(R.id.itemIdCompromisso);

        Intent it = new Intent(getApplicationContext(), TelaCompromisso.class);
        it.putExtra("dia", String.valueOf(root.getStringExtra("dia")));
        it.putExtra("titulo", String.valueOf(itemTitulo.getText()));
        it.putExtra("data", String.valueOf(itemData.getText()));
        it.putExtra("hora", String.valueOf(itemHora.getText()));
        it.putExtra("criador", String.valueOf(itemCriador.getText()));
        it.putExtra("descricao", String.valueOf(itemDescricao.getText()));
        it.putExtra("idCompromisso", String.valueOf(itemIdCompromisso.getText()));
        it.putExtra("tipo", String.valueOf(itemTipo.getText()));
        startActivity(it);
    }
    public void clicaEvento(View v) {
        TextView itemTitulo = v.findViewById(R.id.itemTitulo);
        TextView itemData = v.findViewById(R.id.itemData);
        TextView itemHora = v.findViewById(R.id.itemHora);
        TextView itemDescricao = v.findViewById(R.id.itemDescricao);
        TextView itemCriador = v.findViewById(R.id.itemCriador);
        TextView itemIdEvento = v.findViewById(R.id.itemIdEvento);

        Intent it = new Intent(getApplicationContext(), TelaEvento.class);
        it.putExtra("dia", String.valueOf(root.getStringExtra("dia")));
        it.putExtra("titulo", String.valueOf(itemTitulo.getText()));
        it.putExtra("data", String.valueOf(itemData.getText()));
        it.putExtra("hora", String.valueOf(itemHora.getText()));
        it.putExtra("criador", String.valueOf(itemCriador.getText()));
        it.putExtra("descricao", String.valueOf(itemDescricao.getText()));
        it.putExtra("idEvento", String.valueOf(itemIdEvento.getText()));
        startActivity(it);
    }
    public void clicaEventoInscrito(View v) {
        TextView itemTitulo = v.findViewById(R.id.itemTitulo);
        TextView itemData = v.findViewById(R.id.itemData);
        TextView itemHora = v.findViewById(R.id.itemHora);
        TextView itemDescricao = v.findViewById(R.id.itemDescricao);
        TextView itemCriador = v.findViewById(R.id.itemCriador);
        TextView itemIdEvento = v.findViewById(R.id.itemIdEvento);

        Intent it = new Intent(getApplicationContext(), TelaEventoInscrito.class);
        it.putExtra("dia", String.valueOf(root.getStringExtra("dia")));
        it.putExtra("titulo", String.valueOf(itemTitulo.getText()));
        it.putExtra("data", String.valueOf(itemData.getText()));
        it.putExtra("hora", String.valueOf(itemHora.getText()));
        it.putExtra("criador", String.valueOf(itemCriador.getText()));
        it.putExtra("descricao", String.valueOf(itemDescricao.getText()));
        it.putExtra("idEvento", String.valueOf(itemIdEvento.getText()));
        startActivity(it);
    }
    public void clicaAnotacao(View view) {
        TextView itemTitulo = view.findViewById(R.id.itemTitulo);
        TextView itemCriador = view.findViewById(R.id.itemCriador);
        TextView itemData = view.findViewById(R.id.itemData);
        TextView itemConteudo = view.findViewById(R.id.itemConteudo);
        TextView itemIdAnotacao = view.findViewById(R.id.itemIdAnotacao);

        Intent it = new Intent(getApplicationContext(), TelaAnotacao.class);
        it.putExtra("dia", String.valueOf(root.getStringExtra("dia")));
        it.putExtra("titulo", String.valueOf(itemTitulo.getText()));
        it.putExtra("data", String.valueOf(itemData.getText()));
        it.putExtra("conteudo", String.valueOf(itemConteudo.getText()));
        it.putExtra("criador", String.valueOf(itemCriador.getText()));
        it.putExtra("idAnotacao", String.valueOf(itemIdAnotacao.getText()));
        startActivity(it);
    }

    public void Fechar(View v) {
        finish();
    }

}
