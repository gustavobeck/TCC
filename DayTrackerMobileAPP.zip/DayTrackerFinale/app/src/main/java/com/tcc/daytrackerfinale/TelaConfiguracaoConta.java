package com.tcc.daytrackerfinale;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;

public class TelaConfiguracaoConta extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela_configuracao_conta);


    }

    public void irTrocaNome(View v) {
        Intent it = new Intent(this, TelaTrocaNome.class);
        startActivity(it);
    }
    public void irTrocaEmail(View v) {
        Intent it = new Intent(this, TelaTrocaEmail.class);
        startActivity(it);
    }
    public void irTrocaSenha(View v) {
        Intent it = new Intent(this, TelaTrocaSenha.class);
        startActivity(it);
    }
    public void irDeletarConta(View v) {
        Intent it = new Intent(this, TelaDeletarConta.class);
        startActivity(it);
    }

    public void Fechar(View v) {
        finish();
    }
    public void Sair(View v) {
        SharedPreferences sharedPreferences = getSharedPreferences("Login", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString("emailKey", "");
        editor.putString("nomeKey", "");
        editor.putString("idKey", "");
        editor.putString("senhaKey", "");
        editor.apply();
        finish();
    }
}
