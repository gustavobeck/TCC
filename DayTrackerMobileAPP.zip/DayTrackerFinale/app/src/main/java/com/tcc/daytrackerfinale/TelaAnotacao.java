package com.tcc.daytrackerfinale;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.Map;

public class TelaAnotacao extends AppCompatActivity {
    EditText editData, editConteudo, editTitulo;
    Intent root;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela_anotacao);
        root = getIntent();

        editData = findViewById(R.id.editDia);
        editConteudo = findViewById(R.id.editConteudo);
        editTitulo = findViewById(R.id.editTitulo);
        editConteudo.setText(root.getStringExtra("conteudo"));
        editTitulo.setText(root.getStringExtra("titulo"));

        SimpleDateFormat sdfFront = new SimpleDateFormat("dd/MM/yyyy");
        SimpleDateFormat sdfBack = new SimpleDateFormat("yyyy/MM/dd");
        String dataFormatada = "";

        try {
            dataFormatada = sdfFront.format(sdfBack.parse(root.getStringExtra("data")));
        } catch (ParseException e) {
            e.printStackTrace();
        }
        editData.setText(dataFormatada);
    }

    public void salvarAnotacao(View view) throws ParseException {
        SimpleDateFormat sdfFront = new SimpleDateFormat("dd/MM/yyyy");
        SimpleDateFormat sdfBack = new SimpleDateFormat("yyyy/MM/dd");
        String dataRaw = editData.getText().toString().trim();
        final String dataFormatada = sdfBack.format(sdfFront.parse(dataRaw));
        StringRequest stringRequest = new StringRequest(Request.Method.POST, Constants.URL_ANOTACAO_EDITAR, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    Toast.makeText(getApplicationContext(), jsonObject.getString("mensagem"), Toast.LENGTH_SHORT).show();
                    if (jsonObject.getString("erro").equals("false")) {finish();}

                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getApplicationContext(), error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        }){
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String,String> params = new HashMap<>();
                SharedPreferences sh = getSharedPreferences("Login", Context.MODE_PRIVATE);
                params.put("conteudo", editConteudo.getText().toString().trim());
                params.put("titulo", editTitulo.getText().toString().trim());
                params.put("idAnotacao", root.getStringExtra("idAnotacao"));
                params.put("data", dataFormatada);
                return params;
            }
        };
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);
    }
    public void excluirAnotacao(View view) throws ParseException {
        SimpleDateFormat sdfFront = new SimpleDateFormat("dd/MM/yyyy");
        SimpleDateFormat sdfBack = new SimpleDateFormat("yyyy/MM/dd");
        String dataRaw = editData.getText().toString().trim();
        final String dataFormatada = sdfBack.format(sdfFront.parse(dataRaw));
        StringRequest stringRequest = new StringRequest(Request.Method.POST, Constants.URL_ANOTACAO_DELETAR, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    Toast.makeText(getApplicationContext(), jsonObject.getString("mensagem"), Toast.LENGTH_SHORT).show();
                    if (jsonObject.getString("erro").equals("false")) {finish();}

                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getApplicationContext(), error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        }){
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String,String> params = new HashMap<>();
                params.put("idAnotacao", root.getStringExtra("idAnotacao"));
                return params;
            }
        };
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);
    }

    public void Sair(View v) {
        finish();
    }
}