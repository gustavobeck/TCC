<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>Cadastro</title>

   <style>
        #sucess {
            color: green;
            font-weight: bold;
        }

        #error {
            color: red;
            font-weight: bold;
        }

        #warning {
            color: orange;
            font-weight: bold;
        }

    </style>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
</head>
<body style="background-color:#f9fbe7">
  <div class="row">
    <form class="col s12" method="post">
      <div class="row">
        <div class="input-field col s6">
          <input  id="first_name" type="text" class="validate" name="nome">
          <label for="first_name">Nome de Usuário</label>
        </div>
              </div>
      <div class="row">
        <div class="input-field col s12">
          <input id="email" type="email" class="validate" name="email">
          <label for="email">Email</label>
        </div>
      </div>
      <div class="row">
        <div class="input-field col s12">
          <input id="password" type="password" class="validate" name="senha1">
          <label for="password">Senha</label>
        </div>
      </div>
      <div class="row">
        <div class="input-field col s12">
          <input id="password2" type="password" class="validate" name="senha2">
          <label for="password2">Confirmar senha</label>
        </div>
      </div>
      <!---->
      <input type="submit" value="cadastrar" class="waves-effect waves-light btn center">
      <a class="waves-effect waves-light btn center" href="index.html"> Voltar </a>

    </form>
  </div>
        
  <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
</body>
</html>

<?php

if($_SERVER["REQUEST_METHOD"] === 'POST'){
  include("conexaoBD.php");

  try{
     $nome = $_POST["nome"];
     $email = $_POST["email"];
     $senha1 = $_POST["senha1"];
     $senha2 = $_POST["senha2"];

     if((trim($nome) == "") || (trim($email) == "") || (trim($senha1) == "") || (trim($senha2) == "")){
      echo "<span id='warning'>Preencha todos os campos!</span>"; 
     }
     else{
      if($senha1 == $senha2){
        $stmt = $pdo->prepare("select *from Usuarios where email = :email");
        $stmt->bindParam(':email', $Email);
        $stmt->execute();

        $rows = $stmt->rowCount();

        if ($rows <= 0) {
             $stmt = $pdo->prepare("insert into Usuarios(nome, senha,email) values(:nome, :senha, :email)");
             $stmt->bindParam(':nome', $nome);
             $stmt->bindParam(':senha', $senha1);
             $stmt->bindParam(':email', $email);
             $stmt->execute();

             echo "<span id='sucess'>Usuário cadastrado!</span>";
        } else {
              echo "<span id='error'>Email já cadastrado!</span>";
                }
            }
            else{
              echo "<span id='error'>Senhas não estão iguais!</span>";
            }
          }

        } catch(PDOException $e) {
            echo 'Error: ' . $e->getMessage();
        }

        $pdo = null;
     }
?>
