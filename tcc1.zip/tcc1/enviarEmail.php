<!DOCTYPE html>
<html>
<meta charset="utf-8">
<head>
	<title>Esqueci minha Senha</title>
	<meta charset="utf-8">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
</head>
<body style="background-color: #a7ffeb">
	<div style="width: 100%; text-align: center; margin-top: 100px;">
		<h1><i class="material-icons medium">calendar_today</i> Esqueci a Senha</h1>

	<form class="col s12" method="post">
	 <div class="row">
        <div class="input-field col s12">
          <input id="email" type="email" class="validate" name="email2" placeholder="Email">
         
        </div>
      </div>
      <div class="row">
       </div>

      <input type="submit" value="Enviar Email" class="waves-effect waves-light btn center" >
      <a class="waves-effect waves-light btn center" href="index.html"> Voltar </a>
  </div>	

</form>
</body>
</html>
<?php

if ($_SERVER["REQUEST_METHOD"] === 'POST') {

    $emailAnt = $_POST["email2"];
    
        if (trim($emailAnt) == "")
        {
           echo "<b>Campo email não pode estar vazio!</b>";
        }
        else
        {
          
    /*$destinatario = $emailAnt;
    $remetente = "gubeck@yahoo.com.br";
        include 'conexaoBD.php';
        try{
          $stmt = $pdo->prepare("select * from Usuarios 
        where email= :email");
        $stmt->bindParam(':email', $emailAnt);
        $stmt->execute();
        $row = $stmt->fetch(); 
            $nome  = $row['nome'];
            $emailE = $row['email'];
            $senha = $row['senha'];
        
             
                $corpo_email  = "Ola, o procedimento de recuperar dados, foi efetuado com sucesso !\n..";
                $corpo_email .= "Seu nome = ".$nome."\n..";
                $corpo_email .= "Senha de acesso = ".$senha."\n..";
                $corpo_email .= "Seu email = ".$emailE."\n.. ";
                $corpo_email .= "Nao responda esse email, e-Mail automatizado";    

                $headers =  'MIME-Version: 1.0' . "\r\n"; 
                $headers .= 'From: Your name <gubeck@yahoo.com.br>' . "\r\n";
                $headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";  
                mail($destinatario,"Recuperacao de Senha",$corpo_email,$headers);
                 
                echo "<div align=center><font size=2 face=Verdana, Arial, Helvetica, sans-serif>Sua senha foi enviada com sucesso                      para o email: $emailE.</font></div>";
        }
        catch (PDOException $e) {
             echo 'Error: ' . $e->getMessage();
         }


         $pdo = null;
*/
        } 
        
        

        }
      
      
    



    
    
    
    
    

?>
