<?php
session_start();
include("conexaoBD.php");
$email = $_SESSION['email'];
$codigo = $_SESSION['codigo'];

$stmt = $pdo->prepare("select * from Usuarios 
        where email= :email");
        $stmt->bindParam(':email', $_SESSION['email']);
        $stmt->execute();
        $row = $stmt->fetch(); 




echo "<div class='row'>
    <form class='col s12'' method='post'>
         <div class='row'>
        <div class='input-field col s6'>
          <label for='first_name' style='color: black;'>Nome Completo:</label>
          <br>
          <input  id='nome' type='text' class='validate' name='nome1' value='$row[nome]' style='color: black; font-weight: bold;'>
          
        </div>
        
      </div>
      <div class='row'>
        <div class='input-field col s6'>
           <label for='email' style='color: black;'>Email:</label>
           <br>
          <input id='email' type='email' class='validate' name='email' readonly='readonly' value='$row[email]' style='color: black; font-weight: bold;'>
         
        </div>

        <div class='input-field col s6'>
          <label for='password' style='color: black;'>Senha:</label>
          <br>
          <input id='senha' type='text' class='validate' name='senha1' value='$row[senha]' style='color: black; font-weight: bold;'>
          
        </div>
      </div>
"


?>

<!DOCTYPE html>
<html lang="en">
<meta charset="utf-8">
<head>
	<title>Seu Perfil</title>
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">	
	<style type="text/css">
		img
		{
		margin-left: 10px;
		margin-top: 10px;
		width: 25%;
		height: 25%;
		border: 5px;
		border-style: double;
		border-color: #00BFFF;
		border-radius: 10%;
		}
	</style>
</head>
<body style="background-color: #e1bee7 ">

	
      <input type="submit" value="Concluir" class="waves-effect waves-light btn center">
      <a class="waves-effect waves-light btn center" href="logado.php"> Voltar </a>


</body>
</html>

</body>
</html>

<?php
   if ($_SERVER["REQUEST_METHOD"] === 'POST')
   {
    $novoNome = $_POST['nome1'];
    $novaSenha = $_POST['senha1'];
    $email = $_SESSION['email'];
      if ((trim(($novoNome == ""))) || (trim(($novaSenha == ""))))
      {
        echo "<b>Campo(s) Vazios!</b>";
      }
      else
      {
        try{
        $stmt = $pdo->prepare("UPDATE Usuarios 
        SET nome= :nome, senha= :senha where email= :email");
        $stmt->bindParam(':nome', $novoNome);
        $stmt->bindParam(':senha', $novaSenha);
        $stmt->bindParam(':email', $_SESSION['email']);
        $stmt->execute();
        
        echo "Dados alterados com sucesso!";
        header("location:logado.php");
      }
       catch (PDOException $e) {
        echo 'Error: ' . $e->getMessage();
    }

    $pdo = null;
        
      }
    }
  ?> 

 

