

<!DOCTYPE html>
<html lang="en">
<meta charset="utf-8">
<head>
  <title>Login</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
</head>
<body style="background-color: #e3f2fd">
  <div class="row">
    <form class="col s12" method="post">
      <div class="row">
        <div class="input-field col s12">
          <input id="email" type="email" class="validate" name="email">
          <label for="email">Email</label>
        </div>
      </div>
      <div class="row">
        <div class="input-field col s12">
          <input id="password" type="password" class="validate" name="senha">
          <label for="password">Senha</label>
        </div>
      </div>
      <input type="submit" value="Login" class="waves-effect waves-light btn center">
      <a class="waves-effect waves-light btn center" href="index.html"> Voltar </a>
    </form>
  </div>

        
  <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>

</body>
</html>

 <?php

   session_start();
   include("conexaoBD.php");

   if ($_SERVER["REQUEST_METHOD"] === 'POST')
    {
      $emailLog = $_POST["email"];
      $senhaLog = $_POST["senha"];

      if ((trim(($senhaLog == ""))) || (trim(($emailLog == ""))))
      {
        echo "<b>Campo(s) Vazios!</b>";
      }
      else
      {
        $stmt = $pdo->prepare("select * from Usuarios 
        where email= :email && senha= :senha");
        $stmt->bindParam(':email', $emailLog);
        $stmt->bindParam(':senha', $senhaLog);
        $_SESSION['email'] = $emailLog;

        try {
             $stmt->execute();
             $row = $stmt->fetch();
             $_SESSION['codigo'] = $row['idUsuarios'];

             if($row['email'] == $emailLog && $row['senha']== $senhaLog)
             {
              header("location:logado.php");
             }
             else
             {
              echo "Usuário ou senha inválidos";
             }
         } catch (PDOException $e) {
             echo 'Error: ' . $e->getMessage();
         }


         $pdo = null;
      }
      }   
    ?>



