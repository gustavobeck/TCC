<?php

    //conectando ao BD
    try {        
        $pdo = new PDO('mysql:host=143.106.241.3;dbname=cl18133;charset=utf8', 'cl18133', 'cl*01082003');
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $output = 'Conexão estabelecida. <br>';
    } catch (PDOException $e) {
        $output = 'Impossível conectar BD : ' . $e . '<br>';
    }
    echo $output;
?>