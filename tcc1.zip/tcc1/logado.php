<?php
session_start();
include("conexaoBD.php");
$email = $_SESSION['email'];
$codigo = $_SESSION['codigo'];

$texto = "";
$amigos = "";

try{
$stmt = $pdo->prepare("select * from Usuarios 
        where email= :email");
        $stmt->bindParam(':email', $_SESSION['email']);
        $stmt->execute();
        $row = $stmt->fetch(); 
      }
      catch(PDOException $e){}

try{
$stmt2 = $pdo->prepare("select * from UsuarioEventos 
        where idUsuario= :idUsuario");
        $stmt2->bindParam(':idUsuario', $codigo);
        $stmt2->execute();
        $row2 = $stmt2->fetch();

        do {
$stmt3 = $pdo->prepare("select * from Eventos 
        where idEventos= :idEventos");
        $stmt3->bindParam(':idEventos', $row2['idEvento']);
        $stmt3->execute();
        $row3 = $stmt3->fetch();
        $texto = $texto . $row3['nome'] . " | ";
} while($row2 = $stmt2->fetch());
      }
      catch(PDOException $e){}


try{
$stmt4 = $pdo->prepare("select * from Amizade 
        where id1= :id1 OR id2= :id2");
        $stmt4->bindParam(':id1', $codigo);
        $stmt4->bindParam(':id2', $codigo);
        $stmt4->execute();
        $row4 = $stmt4->fetch();

do {
  if($row4['id1'] == $codigo){
    $id = $row4['id2'];
  }
  else if($row4['id2'] == $codigo)
  {
    $id = $row4['id1'];
  }

$stmt5 = $pdo->prepare("select * from Usuarios 
        where idUsuarios= :id");
        $stmt5->bindParam(':id', $id);
        $stmt5->execute();
        $row5 = $stmt5->fetch();
        $amigos = $amigos . $row5['nome'] . " | ";
} while($row4 = $stmt4->fetch());
}
catch(PDOException $e){}


?>

<!DOCTYPE html>
<html lang="en">
<meta charset="utf-8">
<head>
	<title>Seu Perfil</title>
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">	
	<style type="text/css">
		img
		{
		margin-left: 10px;
		margin-top: 10px;
		width: 25%;
		height: 25%;
		border: 5px;
		border-style: double;
		border-color: #00BFFF;
		border-radius: 10%;
		}
	</style>
</head>
<body style="background-color: #fbe9e7">

	<div class="row">
    <form class="col s12" method="post">
      <div class="row">
        <div class="input-field col s6">
          <label for="first_name" style="color: black;">Nome Completo:</label>
          <br>
          <input  id="noem" type="text" class="validate" name="nome1" readonly="readonly" value="<?php echo $row['nome']; ?>" style="color: black; font-weight: bold;">
          
        </div>
        
      </div>
      <div class="row">
        <div class="input-field col s6">
           <label for="email" style="color: black;">Email:</label>
           <br>
          <input id="email" type="email" class="validate" name="email" readonly="readonly" value="<?php echo $row['email']; ?>" style="color: black; font-weight: bold;">
         
        </div>

        <div class="input-field col s6">
          <label for="password" style="color: black;">Senha:</label>
          <br>
          <input id="senha" type="text" class="validate" name="senha1" readonly="readonly" value="<?php echo $row['senha']; ?>" style="color: black; font-weight: bold;">
          
        </div>
      </div>
       <div class="row">
        <div class="input-field col s12">
          <label for="ev" style="color: black;">Eventos: </label>
          <br>
          <input id="ev" type="text" class="validate" readonly="readonly" value="<?php echo $texto;?>" style="color: black; font-weight: bold;">
          
        </div>
      </div>
      <div class="row">
        <div class="input-field col s12">
          <label for="amg" style="color: black;">Amigos: </label>
          <br>
          <input id="amg" type="text" class="validate" readonly="readonly" value="<?php echo $amigos;?>" style="color: black; font-weight: bold;">
          
        </div>
      </div>
       <a class="waves-effect waves-light btn center" href="alterarDados.php"> Alterar Dados </a>
      <a class="waves-effect waves-light btn center" href="index.html"> Voltar </a>


</body>
</html>

</body>
</html>
