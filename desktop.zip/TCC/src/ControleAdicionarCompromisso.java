
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.swing.JOptionPane;
import modelo.Compromisso;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author gubec
 */
public class ControleAdicionarCompromisso {

    MyConnection conex = new MyConnection();
    Compromisso comp = new Compromisso();

    public void Salvar(Compromisso compromisso) throws ParseException {
         SimpleDateFormat formato = new SimpleDateFormat("dd/MM/yyyy"); 
         System.out.println(compromisso.getDia());
        Date a = formato.parse(compromisso.getDia());
        long d = a.getTime();
        String d2 = String.valueOf(d);
        d2 = d2.substring(0,10);
        conex.conexao();
        try {
            PreparedStatement pst = conex.connection.prepareStatement("insert into compromisso(tipo,data,hora,descricao,titulo,criador) values(?,?,?,?,?,?)");
            pst.setString(1, compromisso.getTipo());
            pst.setString(2, d2);
            pst.setString(3, compromisso.getHorario());
            pst.setString(4, compromisso.getDesc());
            pst.setString(5, compromisso.getTitulo());
            pst.setInt(6, compromisso.getId());
            
            pst.execute();
            System.out.println("Compromisso inserido com sucesso");
        } catch (SQLException ex) {
            System.out.println("Erro ao inserir o compromisso" + ex);
        }

        conex.desconecta();
    }

    public void SalvarInfos(String tipo, String dia, String hora, String desc, String titulo, int id, String tituloant) throws ParseException {
         SimpleDateFormat formato = new SimpleDateFormat("dd/MM/yyyy"); 
        Date a = formato.parse(dia);
        long d = a.getTime();
        String d2 = String.valueOf(d);
        d2 = d2.substring(0,10);
        conex.conexao();
        try {
            PreparedStatement pst = conex.connection.prepareStatement("UPDATE compromisso SET tipo=?,data=?,hora=?,descricao=?,titulo=? where criador='" + id + "' AND titulo='" + tituloant + "'");
            pst.setString(1, tipo);
            pst.setString(2, d2);
            pst.setString(3, hora);
            pst.setString(4, desc);
            pst.setString(5, titulo);
          

            pst.execute();
            System.out.println("Compromisso atualizado com sucesso");
        } catch (SQLException ex) {
            System.out.println("Erro ao atualizar o compromisso" + ex);
        }

        conex.desconecta();
    }

    public void RecusarCompromisso(String escolha) {
        conex.conexao();
        try {

            PreparedStatement pst2 = conex.connection.prepareStatement("delete from compromisso where criador='" + Login.ID + "' AND binary titulo='" + escolha + "'");
            pst2.execute();
            System.out.println("Compromisso excluido");
        } catch (SQLException ex) {
            System.out.println("Erro ao excluir compromisso" + ex);
        }

        conex.desconecta();
    }
}
