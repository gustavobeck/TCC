
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import modelo.Usuario;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author gubec
 */
public class ControleUsuario {

    MyConnection conex = new MyConnection();
    Usuario user = new Usuario();
    String nome1;
    String senha1;
    String email1;
    int id ;

    public void Salvar(Usuario user) {
        conex.conexao();
        try {
            PreparedStatement pst = conex.connection.prepareStatement("insert into usuario(nome,senha,email) values(?,?,?)");
            pst.setString(1, user.getNome());
            pst.setString(2, user.getSenha());
            pst.setString(3, user.getEmail());
            pst.execute();
            System.out.println("Usuario cadastrado com sucesso");
        } catch (SQLException ex) {
            System.out.println("Erro no cadastro do usuario");
        }

        conex.desconecta();
    }

    public void SalvarInfos(String nome, String senha, String email) {
        conex.conexao();
        nome1 = nome;
        senha1 = senha;
        email1 = email;
        
        id = Login.ID;
        
        atualizar1(id);


        conex.desconecta();
    }

    public void atualizar1(int id) {
        try {
            PreparedStatement pst = conex.connection.prepareStatement("UPDATE usuario SET nome=?,senha=?,email=? where idUsuario='" + id + "'");
            pst.setString(1, nome1);
            pst.setString(2, senha1);
            pst.setString(3, email1);
            pst.execute();
            System.out.println("Usuario atualizado com sucesso");
        } catch (SQLException ex) {
            System.out.println("Erro ao atualizar o usuario" + ex);
        }
    }







}
