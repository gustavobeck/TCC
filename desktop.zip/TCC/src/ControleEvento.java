
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import modelo.Data;
import modelo.Eventos;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author gubec
 */
public class ControleEvento {

    MyConnection conex = new MyConnection();
    Eventos evento = new Eventos();


    public void Salvar(Eventos evento) throws ParseException {
        SimpleDateFormat formato = new SimpleDateFormat("dd/MM/yyyy"); 
         
        Date a = formato.parse(evento.getData());
        long d = a.getTime();
        String d2 = String.valueOf(d);
        d2 = d2.substring(0,10);
        conex.conexao();
       
        try {
            PreparedStatement pst = conex.connection.prepareStatement("insert into evento(titulo,descricao,data,hora,criador) values(?,?,?,?,?)");
           
            pst.setString(1, evento.getNome());
            pst.setString(2, evento.getDescricao());
            pst.setString(3, d2);
            pst.setString(4, evento.getHorario());
            pst.setInt(5, Login.ID);
            pst.execute();
            System.out.println("Evento cadastrado com sucesso");
        } catch (SQLException ex) {
            System.out.println("Erro ao cadastrar o evento"+ex);
        }

        conex.desconecta();
    }

    public void SalvarInfos(String nome, String descricao, String data, String horario) throws ParseException {
        
        SimpleDateFormat formato = new SimpleDateFormat("dd/MM/yyyy"); 
         
        Date a = formato.parse(data);
        long d = a.getTime();
        String d2 = String.valueOf(d);
        d2 = d2.substring(0,10);
        conex.conexao();
        try {
            PreparedStatement pst = conex.connection.prepareStatement("UPDATE evento SET titulo=?,anocatacao=?,data=?,horario=? where criador='" + Login.ID + "'");
            pst.setString(1, nome);
            pst.setString(2, descricao);
            pst.setString(3, d2);
            pst.setString(4, horario);
            pst.execute();
            System.out.println("Evento atualizado com sucesso");

        } catch (SQLException ex) {
            System.out.println("Erro ao atualizar o evento" + ex);
        }

        conex.desconecta();
    }
    
    public void Excluir(String idEvento, int idCriador) {
        conex.conexao();
        try {
            PreparedStatement pst2 = conex.connection.prepareStatement("delete from evento where idEvento='" + idEvento + "' && criador='" + idCriador + "'");
            pst2.execute();
            System.out.println("Evento excluido");
        } catch (SQLException ex) {
            System.out.println("Erro ao excluir evento"+ex);
        }

        conex.desconecta();
    }
     public void Excluir2(String idEvento) {
        conex.conexao();
        try {
            PreparedStatement pst3 = conex.connection.prepareStatement("delete from convite_evento where idEvento='" + idEvento + "'");
            pst3.execute();
            System.out.println("Evento excluido");
        } catch (SQLException ex) {
            System.out.println("Erro ao excluir evento"+ex);
        }

        conex.desconecta();
    }
      public void Excluir3(String idEvento) {
        conex.conexao();
        try {
            PreparedStatement pst4 = conex.connection.prepareStatement("delete from participacao where binary idEvento='" + idEvento + "'");
            pst4.execute();
            System.out.println("Evento excluido");
        } catch (SQLException ex) {
            System.out.println("Erro ao excluir evento"+ex);
        }

        conex.desconecta();
    }
}
