
import java.sql.PreparedStatement;
import java.sql.SQLException;
import modelo.Data;
import modelo.Eventos;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author gubec
 */
public class ControleEvento {

    MyConnection conex = new MyConnection();
    Eventos evento = new Eventos();


    public void Salvar(Eventos evento) {
        conex.conexao();
       
        try {
            PreparedStatement pst = conex.connection.prepareStatement("insert into Eventos(idEventos,nome,descricao,data,hora,idCriador) values(?,?,?,?,?,?)");
            pst.setString(1, evento.getCodigo());
            pst.setString(2, evento.getNome());
            pst.setString(3, evento.getDescricao());
            pst.setString(4, evento.getData());
            pst.setString(5, evento.getHorario());
            pst.setInt(6, Login.ID);
            pst.execute();
            System.out.println("Evento cadastrado com sucesso");
        } catch (SQLException ex) {
            System.out.println("Erro ao cadastrar o evento"+ex);
        }

        conex.desconecta();
    }

    public void SalvarInfos(String nome, String descricao, String data, String horario) {
        conex.conexao();

        try {
            PreparedStatement pst = conex.connection.prepareStatement("UPDATE Eventos SET nome=?,anocatacao=?,data=?,horario=? where idCriador='" + Login.ID + "'");
            pst.setString(1, nome);
            pst.setString(2, descricao);
            pst.setString(3, data);
            pst.setString(4, horario);
            pst.execute();
            System.out.println("Evento atualizado com sucesso");

        } catch (SQLException ex) {
            System.out.println("Erro ao atualizar o evento" + ex);
        }

        conex.desconecta();
    }
    
    public void Excluir(String idEvento, int idCriador) {
        conex.conexao();
        try {
            PreparedStatement pst2 = conex.connection.prepareStatement("delete from Eventos where binary idEventos='" + idEvento + "' && idCriador='" + idCriador + "'");
            pst2.execute();
            System.out.println("Evento excluido");
        } catch (SQLException ex) {
            System.out.println("Erro ao excluir evento"+ex);
        }

        conex.desconecta();
    }
     public void Excluir2(String idEvento) {
        conex.conexao();
        try {
            PreparedStatement pst3 = conex.connection.prepareStatement("delete from SolicitacaoEvento where binary idEvento='" + idEvento + "'");
            pst3.execute();
            System.out.println("Evento excluido");
        } catch (SQLException ex) {
            System.out.println("Erro ao excluir evento"+ex);
        }

        conex.desconecta();
    }
      public void Excluir3(String idEvento) {
        conex.conexao();
        try {
            PreparedStatement pst4 = conex.connection.prepareStatement("delete from UsuarioEventos where binary idEvento='" + idEvento + "'");
            pst4.execute();
            System.out.println("Evento excluido");
        } catch (SQLException ex) {
            System.out.println("Erro ao excluir evento"+ex);
        }

        conex.desconecta();
    }
}
