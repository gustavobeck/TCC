
import java.awt.Color;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Random;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import modelo.Data;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author gubec
 */
public class Inicial extends javax.swing.JFrame {

    Random random = new Random();
    String nome;
    String evento;
    String login;
    String data;
    String escolha;
    String mes;
    String mes2;
    int id;
    String dataCompromisso;
    String tipoCompromisso;

    String d0;
    String d1;
    String d2;
    String d3;
    public static String mesSelecionado;
    public static String nomeEvento;
    public static int idEventoSelecionado;
    public static String fsSelecionado;
    public static String fsEscolha;
    Data dia = new Data();
    ControleData control = new ControleData();
    ControleFS control2 = new ControleFS();
    MyConnection conex = new MyConnection();
    MyConnection conex2 = new MyConnection();
    public static final Color purple = new Color(204, 0, 204);

    private void atualizarMes2() {
        switch (mes) {
            case "Janeiro":
                mes2 = "01";
                break;
            case "Fevereiro":
                mes2 = "02";
                break;
            case "Março":
                mes2 = "03";
                break;
            case "Abril":
                mes2 = "04";
                break;
            case "Maio":
                mes2 = "05";
                break;
            case "Junho":
                mes2 = "06";
                break;
            case "Julho":
                mes2 = "07";
                break;
            case "Agosto":
                mes2 = "08";
                break;
            case "Setembro":
                mes2 = "09";
                break;
            case "Outubro":
                mes2 = "10";
                break;
            case "Novembro":
                mes2 = "11";
                break;
            case "Dezembro":
                mes2 = "12";
                break;

        }
    }

    public Inicial() throws ParseException, SQLException {

        conex.conexao();
        login = Login.nome;
        this.nome = Login.nome.toUpperCase();
        id = Login.ID;
        initComponents();
        jLabel1.setText(nome);
        jLabel15.setText(String.valueOf(Login.ID));
        data = getDateTime();

        d0 = criarDias(data, 1);
        d1 = criarDias(data, 2);
        d2 = criarDias(data, -1);
        d3 = criarDias(data, -2);

        dia.setData(data);
        dia.setId(id);
        list1.removeAll();
        mes = (String) jComboBox2.getSelectedItem();
        carregarMes(mes);
        atualizarMes2();
        

        jTextArea2.setLineWrap(true);
        jTextArea2.setWrapStyleWord(true);
        jTextArea3.setLineWrap(true);
        jTextArea3.setWrapStyleWord(true);

        try {
            conex.executaSql("select *from Dia where idUsuario='" + id + "' AND data='" + data + "'");
            conex.rs.first();
            if ("".equals(conex.rs.getString("data")));
        } catch (SQLException ex) {
            control.Salvar(dia);
        }
        try {
            conex.executaSql("select *from Dia where idUsuario='" + id + "' AND data='" + d0 + "'");
            conex.rs.first();
            if ("".equals(conex.rs.getString("data")));
        } catch (SQLException ex2) {
            dia.setData(d0);
            control.Salvar(dia);

        }
        try {
            conex.executaSql("select *from Dia where idUsuario='" + id + "' AND data='" + d1 + "'");
            conex.rs.first();
            if ("".equals(conex.rs.getString("data")));
        } catch (SQLException ex3) {
            dia.setData(d1);
            control.Salvar(dia);

        }
        try {
            conex.executaSql("select *from Dia where idUsuario='" + id + "' AND data='" + d2 + "'");
            conex.rs.first();
            if ("".equals(conex.rs.getString("data")));
        } catch (SQLException ex4) {
            dia.setData(d2);
            control.Salvar(dia);

        }
        try {
            conex.executaSql("select *from Dia where idUsuario='" + id + "' AND data='" + d3 + "'");
            conex.rs.first();
            if ("".equals(conex.rs.getString("data")));
        } catch (SQLException ex5) {
            dia.setData(d3);
            control.Salvar(dia);
        }

        try {
            conex.executaSql("select *from Dia where idUsuario='" + id + "'order by data");
            conex.rs.first();
            jComboBox1.removeAllItems();
            do {
                jComboBox1.addItem(conex.rs.getString("data"));
            } while (conex.rs.next());
        } catch (SQLException a) {
            JOptionPane.showMessageDialog(rootPane, "Não há dias anteriores!");
        }

        jComboBox1.setSelectedItem(data);
        escolha = (String) jComboBox1.getSelectedItem();
        try {
            conex.conexao();
            conex.executaSql("select *from Dia where data='" + escolha + "' AND idUsuario='" + id + "'");
            conex.rs.first();
            jTextArea2.setText(conex.rs.getString("anotacao"));
            jTextArea3.setText(conex.rs.getString("nota"));

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(rootPane, "Erro ao carregar o dia!");

        }

        try {
            conex.executaSql("select count(*) from Motivacional");
            conex.rs.first();
            int total = Integer.parseInt(conex.rs.getString("count(*)"));
            total++;
            System.out.println("total = " + total);
            int motivacional = random.nextInt(total);
            if (motivacional == 0) {
                motivacional++;
            }

            try {
                conex.executaSql("select *from Motivacional where idMotivacional='" + motivacional + "'");
                conex.rs.first();
                jTextArea1.setLineWrap(true);
                jTextArea1.setWrapStyleWord(true);
                jTextArea1.setText(conex.rs.getString("mensagem"));

            } catch (SQLException t) {
                JOptionPane.showMessageDialog(rootPane, "Erro mensagem m" + t);
            }

        } catch (SQLException m) {
            JOptionPane.showMessageDialog(rootPane, "Erro" + m);
        }
        atualizarLista();
        atualizarCompromissos();
        AtualizaFS();
        conex.desconecta();

    }

    private void atualizarCompromissos() throws ParseException, SQLException {
        label1701.setForeground(Color.white);
        label1702.setForeground(Color.white);
        label1703.setForeground(Color.white);
        label1704.setForeground(Color.white);
        label101.setForeground(Color.white);
        label201.setForeground(Color.white);
        label301.setForeground(Color.white);
        label401.setForeground(Color.white);
        label501.setForeground(Color.white);
        label601.setForeground(Color.white);
        label701.setForeground(Color.white);
        label801.setForeground(Color.white);
        label901.setForeground(Color.white);
        label1001.setForeground(Color.white);
        label1101.setForeground(Color.white);
        label1201.setForeground(Color.white);
        label1301.setForeground(Color.white);
        label1401.setForeground(Color.white);
        label1501.setForeground(Color.white);
        label1601.setForeground(Color.white);
        label1201.setForeground(Color.white);
        label1801.setForeground(Color.white);
        label1901.setForeground(Color.white);
        label2001.setForeground(Color.white);
        label2101.setForeground(Color.white);
        label2201.setForeground(Color.white);
        label2301.setForeground(Color.white);
        label2401.setForeground(Color.white);
        label2501.setForeground(Color.white);
        label2601.setForeground(Color.white);
        label2701.setForeground(Color.white);
        label2801.setForeground(Color.white);
        label2901.setForeground(Color.white);
        label3001.setForeground(Color.white);
        label3101.setForeground(Color.white);
        label102.setForeground(Color.white);
        label202.setForeground(Color.white);
        label302.setForeground(Color.white);
        label402.setForeground(Color.white);
        label502.setForeground(Color.white);
        label602.setForeground(Color.white);
        label702.setForeground(Color.white);
        label802.setForeground(Color.white);
        label902.setForeground(Color.white);
        label1002.setForeground(Color.white);
        label1102.setForeground(Color.white);
        label1202.setForeground(Color.white);
        label1302.setForeground(Color.white);
        label1402.setForeground(Color.white);
        label1502.setForeground(Color.white);
        label1602.setForeground(Color.white);
        label1202.setForeground(Color.white);
        label1802.setForeground(Color.white);
        label1902.setForeground(Color.white);
        label2002.setForeground(Color.white);
        label2102.setForeground(Color.white);
        label2202.setForeground(Color.white);
        label2302.setForeground(Color.white);
        label2402.setForeground(Color.white);
        label2502.setForeground(Color.white);
        label2602.setForeground(Color.white);
        label2702.setForeground(Color.white);
        label2802.setForeground(Color.white);
        label2902.setForeground(Color.white);
        label3002.setForeground(Color.white);
        label3102.setForeground(Color.white);
        label103.setForeground(Color.white);
        label203.setForeground(Color.white);
        label303.setForeground(Color.white);
        label403.setForeground(Color.white);
        label503.setForeground(Color.white);
        label603.setForeground(Color.white);
        label703.setForeground(Color.white);
        label803.setForeground(Color.white);
        label903.setForeground(Color.white);
        label1003.setForeground(Color.white);
        label1103.setForeground(Color.white);
        label1203.setForeground(Color.white);
        label1303.setForeground(Color.white);
        label1403.setForeground(Color.white);
        label1503.setForeground(Color.white);
        label1603.setForeground(Color.white);
        label1203.setForeground(Color.white);
        label1803.setForeground(Color.white);
        label1903.setForeground(Color.white);
        label2003.setForeground(Color.white);
        label2103.setForeground(Color.white);
        label2203.setForeground(Color.white);
        label2303.setForeground(Color.white);
        label2403.setForeground(Color.white);
        label2503.setForeground(Color.white);
        label2603.setForeground(Color.white);
        label2703.setForeground(Color.white);
        label2803.setForeground(Color.white);
        label2903.setForeground(Color.white);
        label3003.setForeground(Color.white);
        label3103.setForeground(Color.white);
        label104.setForeground(Color.white);
        label204.setForeground(Color.white);
        label304.setForeground(Color.white);
        label404.setForeground(Color.white);
        label504.setForeground(Color.white);
        label604.setForeground(Color.white);
        label704.setForeground(Color.white);
        label804.setForeground(Color.white);
        label904.setForeground(Color.white);
        label1004.setForeground(Color.white);
        label1104.setForeground(Color.white);
        label1204.setForeground(Color.white);
        label1304.setForeground(Color.white);
        label1404.setForeground(Color.white);
        label1504.setForeground(Color.white);
        label1604.setForeground(Color.white);
        label1204.setForeground(Color.white);
        label1804.setForeground(Color.white);
        label1904.setForeground(Color.white);
        label2004.setForeground(Color.white);
        label2104.setForeground(Color.white);
        label2204.setForeground(Color.white);
        label2304.setForeground(Color.white);
        label2404.setForeground(Color.white);
        label2504.setForeground(Color.white);
        label2604.setForeground(Color.white);
        label2704.setForeground(Color.white);
        label2804.setForeground(Color.white);
        label2904.setForeground(Color.white);
        label3004.setForeground(Color.white);
        label3104.setForeground(Color.white);

        SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd");
        SimpleDateFormat sdf2 = new SimpleDateFormat("dd");
        SimpleDateFormat sdf3 = new SimpleDateFormat("MM");
        try {
            conex.conexao();
            conex.executaSql("select *from Compromisso where binary idUsuario='" + id + "' order by data");
            conex.rs.first();
            do {
                dataCompromisso = conex.rs.getString("data");
                String mesS = sdf3.format(sdf.parse(dataCompromisso));
                String diaS = sdf2.format(sdf.parse(dataCompromisso));
                tipoCompromisso = conex.rs.getString("tipo");

                if (mesS.equals(mes2)) {
                    if (tipoCompromisso.equals("Trabalho")) {
                        switch (Integer.parseInt(diaS)) {
                            case 1:
                                label101.setForeground(Color.red);
                                break;
                            case 2:
                                label201.setForeground(Color.red);
                                break;
                            case 3:
                                label301.setForeground(Color.red);
                                break;
                            case 4:
                                label401.setForeground(Color.red);
                                break;
                            case 5:
                                label501.setForeground(Color.red);
                                break;
                            case 6:
                                label601.setForeground(Color.red);
                                break;
                            case 7:
                                label701.setForeground(Color.red);
                                break;
                            case 8:
                                label801.setForeground(Color.red);
                                break;
                            case 9:
                                label901.setForeground(Color.red);
                                break;
                            case 10:
                                label1001.setForeground(Color.red);
                                break;
                            case 11:
                                label1101.setForeground(Color.red);
                                break;
                            case 12:
                                label1201.setForeground(Color.red);
                                break;
                            case 13:
                                label1301.setForeground(Color.red);
                                break;
                            case 14:
                                label1401.setForeground(Color.red);
                                break;
                            case 15:
                                label1501.setForeground(Color.red);
                                break;
                            case 16:
                                label1601.setForeground(Color.red);
                                break;
                            case 17:
                                label1201.setForeground(Color.red);
                                break;
                            case 18:
                                label1801.setForeground(Color.red);
                                break;
                            case 19:
                                label1901.setForeground(Color.red);
                                break;
                            case 20:
                                label2001.setForeground(Color.red);
                                break;
                            case 21:
                                label2101.setForeground(Color.red);
                                break;
                            case 22:
                                label2201.setForeground(Color.red);
                                break;
                            case 23:
                                label2301.setForeground(Color.red);
                                break;
                            case 24:
                                label2401.setForeground(Color.red);
                                break;
                            case 25:
                                label2501.setForeground(Color.red);
                                break;
                            case 26:
                                label2601.setForeground(Color.red);
                                break;
                            case 27:
                                label2701.setForeground(Color.red);
                                break;
                            case 28:
                                label2801.setForeground(Color.red);
                                break;
                            case 29:
                                label2901.setForeground(Color.red);
                                break;
                            case 30:
                                label3001.setForeground(Color.red);
                                break;
                            case 31:
                                label3101.setForeground(Color.red);
                                break;

                        }
                    } else if (tipoCompromisso.equals("Lazer")) {

                        switch (Integer.parseInt(diaS)) {
                            case 1:
                                label102.setForeground(Color.blue);
                                break;
                            case 2:
                                label202.setForeground(Color.blue);
                                break;
                            case 3:
                                label302.setForeground(Color.blue);
                                break;
                            case 4:
                                label402.setForeground(Color.blue);
                                break;
                            case 5:
                                label502.setForeground(Color.blue);
                                break;
                            case 6:
                                label602.setForeground(Color.blue);
                                break;
                            case 7:
                                label702.setForeground(Color.blue);
                                break;
                            case 8:
                                label802.setForeground(Color.blue);
                                break;
                            case 9:
                                label902.setForeground(Color.blue);
                                break;
                            case 10:
                                label1002.setForeground(Color.blue);
                                break;
                            case 11:
                                label1102.setForeground(Color.blue);
                                break;
                            case 12:
                                label1202.setForeground(Color.blue);
                                break;
                            case 13:
                                label1302.setForeground(Color.blue);
                                break;
                            case 14:
                                label1402.setForeground(Color.blue);
                                break;
                            case 15:
                                label1502.setForeground(Color.blue);
                                break;
                            case 16:
                                label1602.setForeground(Color.blue);
                                break;
                            case 17:
                                label1202.setForeground(Color.blue);
                                break;
                            case 18:
                                label1802.setForeground(Color.blue);
                                break;
                            case 19:
                                label1902.setForeground(Color.blue);
                                break;
                            case 20:
                                label2002.setForeground(Color.blue);
                                break;
                            case 21:
                                label2102.setForeground(Color.blue);
                                break;
                            case 22:
                                label2202.setForeground(Color.blue);
                                break;
                            case 23:
                                label2302.setForeground(Color.blue);
                                break;
                            case 24:
                                label2402.setForeground(Color.blue);
                                break;
                            case 25:
                                label2502.setForeground(Color.blue);
                                break;
                            case 26:
                                label2602.setForeground(Color.blue);
                                break;
                            case 27:
                                label2702.setForeground(Color.blue);
                                break;
                            case 28:
                                label2802.setForeground(Color.blue);
                                break;
                            case 29:
                                label2902.setForeground(Color.blue);
                                break;
                            case 30:
                                label3002.setForeground(Color.blue);
                                break;
                            case 31:
                                label3102.setForeground(Color.blue);
                                break;

                        }
                    } else if (tipoCompromisso.equals("Médico")) {
                        switch (Integer.parseInt(diaS)) {
                            case 1:
                                label103.setForeground(Color.green);
                                break;
                            case 2:
                                label203.setForeground(Color.green);
                                break;
                            case 3:
                                label303.setForeground(Color.green);
                                break;
                            case 4:
                                label403.setForeground(Color.green);
                                break;
                            case 5:
                                label503.setForeground(Color.green);
                                break;
                            case 6:
                                label603.setForeground(Color.green);
                                break;
                            case 7:
                                label703.setForeground(Color.green);
                                break;
                            case 8:
                                label803.setForeground(Color.green);
                                break;
                            case 9:
                                label903.setForeground(Color.green);
                                break;
                            case 10:
                                label1003.setForeground(Color.green);
                                break;
                            case 11:
                                label1103.setForeground(Color.green);
                                break;
                            case 12:
                                label1203.setForeground(Color.green);
                                break;
                            case 13:
                                label1303.setForeground(Color.green);
                                break;
                            case 14:
                                label1403.setForeground(Color.green);
                                break;
                            case 15:
                                label1503.setForeground(Color.green);
                                break;
                            case 16:
                                label1603.setForeground(Color.green);
                                break;
                            case 17:
                                label1203.setForeground(Color.green);
                                break;
                            case 18:
                                label1803.setForeground(Color.green);
                                break;
                            case 19:
                                label1903.setForeground(Color.green);
                                break;
                            case 20:
                                label2003.setForeground(Color.green);
                                break;
                            case 21:
                                label2103.setForeground(Color.green);
                                break;
                            case 22:
                                label2203.setForeground(Color.green);

                                break;
                            case 23:
                                label2303.setForeground(Color.green);
                                break;
                            case 24:
                                label2403.setForeground(Color.green);
                                break;
                            case 25:
                                label2503.setForeground(Color.green);
                                break;
                            case 26:
                                label2603.setForeground(Color.green);
                                break;
                            case 27:
                                label2703.setForeground(Color.green);
                                break;
                            case 28:
                                label2803.setForeground(Color.green);
                                break;
                            case 29:
                                label2903.setForeground(Color.green);
                                break;
                            case 30:
                                label3003.setForeground(Color.green);
                                break;
                            case 31:
                                label3103.setForeground(Color.green);
                                break;

                        }
                    } else if (tipoCompromisso.equals("Outros")) {
                        switch (Integer.parseInt(diaS)) {
                            case 1:
                                label104.setForeground(purple);
                                break;
                            case 2:
                                label204.setForeground(purple);
                                break;
                            case 3:
                                label304.setForeground(purple);
                                break;
                            case 4:
                                label404.setForeground(purple);
                                break;
                            case 5:
                                label504.setForeground(purple);
                                break;
                            case 6:
                                label604.setForeground(purple);
                                break;
                            case 7:
                                label704.setForeground(purple);
                                break;
                            case 8:
                                label804.setForeground(purple);
                                break;
                            case 9:
                                label904.setForeground(purple);
                                break;
                            case 10:
                                label1004.setForeground(purple);
                                break;
                            case 11:
                                label1104.setForeground(purple);
                                break;
                            case 12:
                                label1204.setForeground(purple);
                                break;
                            case 13:
                                label1304.setForeground(purple);
                                break;
                            case 14:
                                label1404.setForeground(purple);
                                break;
                            case 15:
                                label1504.setForeground(purple);
                                break;
                            case 16:
                                label1604.setForeground(purple);
                                break;
                            case 17:
                                label1204.setForeground(purple);
                                break;
                            case 18:
                                label1804.setForeground(purple);
                                break;
                            case 19:
                                label1904.setForeground(purple);
                                break;
                            case 20:
                                label2004.setForeground(purple);
                                break;
                            case 21:
                                label2104.setForeground(purple);
                                break;
                            case 22:
                                label2204.setForeground(purple);
                                break;
                            case 23:
                                label2304.setForeground(purple);
                                break;
                            case 24:
                                label2404.setForeground(purple);
                                break;
                            case 25:
                                label2504.setForeground(purple);
                                break;
                            case 26:
                                label2604.setForeground(purple);
                                break;
                            case 27:
                                label2704.setForeground(purple);
                                break;
                            case 28:
                                label2804.setForeground(purple);
                                break;
                            case 29:
                                label2904.setForeground(purple);
                                break;
                            case 30:
                                label3004.setForeground(purple);
                                break;
                            case 31:
                                label3104.setForeground(purple);
                                break;

                        }
                    }
                } else {
                }

            } while (conex.rs.next());

            conex.desconecta();

        } catch (SQLException ex) {

            conex.desconecta();
        }
    }

    private void atualizarLista() {
        int cont = 0;

        try {
            conex.executaSql("select *from UsuarioEventos where idUsuario='" + id + "'");
            conex.rs.first();
            list1.removeAll();
            jButton3.setEnabled(true);
            jButton4.setEnabled(true);
            conex2.conexao();
            do {
                try {

                    conex2.executaSql("select *from Eventos where idEventos = '" + conex.rs.getString("idEvento") + "' order by data");
                    conex2.rs.first();
                    list1.add(conex2.rs.getString("nome"));
                    cont = 10;
                } catch (Exception r) {

                }

            } while (conex.rs.next());
            if (cont == 0) {
                list1.add("Você não possui eventos");
                jButton3.setEnabled(false);
                jButton4.setEnabled(false);
            }
        } catch (SQLException ev) {
            list1.add("Você não possui eventos");
            jButton3.setEnabled(false);
            jButton4.setEnabled(false);
        }
        conex2.desconecta();
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jTabbedPane1 = new javax.swing.JTabbedPane();
        jPanel1 = new javax.swing.JPanel();
        jComboBox1 = new javax.swing.JComboBox<>();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jButton2 = new javax.swing.JButton();
        jPanel5 = new javax.swing.JPanel();
        jScrollPane4 = new javax.swing.JScrollPane();
        jTextArea1 = new javax.swing.JTextArea();
        jLabel5 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTextArea2 = new javax.swing.JTextArea();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTextArea3 = new javax.swing.JTextArea();
        jPanel6 = new javax.swing.JPanel();
        jComboBox2 = new javax.swing.JComboBox<>();
        jButton1 = new javax.swing.JButton();
        jLabel7 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        jButton6 = new javax.swing.JButton();
        jPanel7 = new javax.swing.JPanel();
        label103 = new javax.swing.JLabel();
        jLabel171 = new javax.swing.JLabel();
        label101 = new javax.swing.JLabel();
        label104 = new javax.swing.JLabel();
        label102 = new javax.swing.JLabel();
        jPanel8 = new javax.swing.JPanel();
        jLabel158 = new javax.swing.JLabel();
        label201 = new javax.swing.JLabel();
        label202 = new javax.swing.JLabel();
        label203 = new javax.swing.JLabel();
        label204 = new javax.swing.JLabel();
        jPanel9 = new javax.swing.JPanel();
        jLabel173 = new javax.swing.JLabel();
        label301 = new javax.swing.JLabel();
        label304 = new javax.swing.JLabel();
        label303 = new javax.swing.JLabel();
        label302 = new javax.swing.JLabel();
        jPanel10 = new javax.swing.JPanel();
        label402 = new javax.swing.JLabel();
        label404 = new javax.swing.JLabel();
        label403 = new javax.swing.JLabel();
        jLabel218 = new javax.swing.JLabel();
        label401 = new javax.swing.JLabel();
        jPanel11 = new javax.swing.JPanel();
        jLabel156 = new javax.swing.JLabel();
        label504 = new javax.swing.JLabel();
        label501 = new javax.swing.JLabel();
        label503 = new javax.swing.JLabel();
        label502 = new javax.swing.JLabel();
        jPanel12 = new javax.swing.JPanel();
        jLabel162 = new javax.swing.JLabel();
        label604 = new javax.swing.JLabel();
        label602 = new javax.swing.JLabel();
        label601 = new javax.swing.JLabel();
        label603 = new javax.swing.JLabel();
        jPanel13 = new javax.swing.JPanel();
        label703 = new javax.swing.JLabel();
        label704 = new javax.swing.JLabel();
        jLabel224 = new javax.swing.JLabel();
        label702 = new javax.swing.JLabel();
        label701 = new javax.swing.JLabel();
        jPanel14 = new javax.swing.JPanel();
        label903 = new javax.swing.JLabel();
        label904 = new javax.swing.JLabel();
        jLabel248 = new javax.swing.JLabel();
        label901 = new javax.swing.JLabel();
        label902 = new javax.swing.JLabel();
        jPanel15 = new javax.swing.JPanel();
        label1001 = new javax.swing.JLabel();
        label1004 = new javax.swing.JLabel();
        label1003 = new javax.swing.JLabel();
        label1002 = new javax.swing.JLabel();
        jLabel258 = new javax.swing.JLabel();
        jPanel16 = new javax.swing.JPanel();
        label1103 = new javax.swing.JLabel();
        jLabel234 = new javax.swing.JLabel();
        label1101 = new javax.swing.JLabel();
        label1102 = new javax.swing.JLabel();
        label1104 = new javax.swing.JLabel();
        jPanel17 = new javax.swing.JPanel();
        label1203 = new javax.swing.JLabel();
        label1202 = new javax.swing.JLabel();
        jLabel247 = new javax.swing.JLabel();
        label1204 = new javax.swing.JLabel();
        label1201 = new javax.swing.JLabel();
        jPanel18 = new javax.swing.JPanel();
        label1301 = new javax.swing.JLabel();
        label1303 = new javax.swing.JLabel();
        jLabel250 = new javax.swing.JLabel();
        label1304 = new javax.swing.JLabel();
        label1302 = new javax.swing.JLabel();
        jPanel19 = new javax.swing.JPanel();
        label1404 = new javax.swing.JLabel();
        jLabel240 = new javax.swing.JLabel();
        label1402 = new javax.swing.JLabel();
        label1401 = new javax.swing.JLabel();
        label1403 = new javax.swing.JLabel();
        jPanel20 = new javax.swing.JPanel();
        label802 = new javax.swing.JLabel();
        label803 = new javax.swing.JLabel();
        jLabel256 = new javax.swing.JLabel();
        label801 = new javax.swing.JLabel();
        label804 = new javax.swing.JLabel();
        jPanel21 = new javax.swing.JPanel();
        label1803 = new javax.swing.JLabel();
        jLabel82 = new javax.swing.JLabel();
        label1801 = new javax.swing.JLabel();
        label1802 = new javax.swing.JLabel();
        label1804 = new javax.swing.JLabel();
        jPanel22 = new javax.swing.JPanel();
        label1903 = new javax.swing.JLabel();
        label1902 = new javax.swing.JLabel();
        jLabel95 = new javax.swing.JLabel();
        label1904 = new javax.swing.JLabel();
        label1901 = new javax.swing.JLabel();
        jPanel23 = new javax.swing.JPanel();
        label2001 = new javax.swing.JLabel();
        label2003 = new javax.swing.JLabel();
        jLabel98 = new javax.swing.JLabel();
        label2004 = new javax.swing.JLabel();
        label2002 = new javax.swing.JLabel();
        jPanel24 = new javax.swing.JPanel();
        label2104 = new javax.swing.JLabel();
        jLabel88 = new javax.swing.JLabel();
        label2102 = new javax.swing.JLabel();
        label2101 = new javax.swing.JLabel();
        label2103 = new javax.swing.JLabel();
        jPanel25 = new javax.swing.JPanel();
        label1603 = new javax.swing.JLabel();
        label1604 = new javax.swing.JLabel();
        jLabel96 = new javax.swing.JLabel();
        label1601 = new javax.swing.JLabel();
        label1602 = new javax.swing.JLabel();
        jPanel26 = new javax.swing.JPanel();
        label1502 = new javax.swing.JLabel();
        label1503 = new javax.swing.JLabel();
        jLabel104 = new javax.swing.JLabel();
        label1501 = new javax.swing.JLabel();
        label1504 = new javax.swing.JLabel();
        jPanel27 = new javax.swing.JPanel();
        label1701 = new javax.swing.JLabel();
        label1704 = new javax.swing.JLabel();
        label1703 = new javax.swing.JLabel();
        label1702 = new javax.swing.JLabel();
        jLabel106 = new javax.swing.JLabel();
        jPanel28 = new javax.swing.JPanel();
        label2804 = new javax.swing.JLabel();
        jLabel123 = new javax.swing.JLabel();
        label2802 = new javax.swing.JLabel();
        label2801 = new javax.swing.JLabel();
        label2803 = new javax.swing.JLabel();
        jPanel29 = new javax.swing.JPanel();
        label2603 = new javax.swing.JLabel();
        label2602 = new javax.swing.JLabel();
        jLabel130 = new javax.swing.JLabel();
        label2604 = new javax.swing.JLabel();
        label2601 = new javax.swing.JLabel();
        jPanel30 = new javax.swing.JPanel();
        label2702 = new javax.swing.JLabel();
        label2701 = new javax.swing.JLabel();
        label2703 = new javax.swing.JLabel();
        jLabel133 = new javax.swing.JLabel();
        label2704 = new javax.swing.JLabel();
        jPanel31 = new javax.swing.JPanel();
        label2503 = new javax.swing.JLabel();
        jLabel117 = new javax.swing.JLabel();
        label2501 = new javax.swing.JLabel();
        label2502 = new javax.swing.JLabel();
        label2504 = new javax.swing.JLabel();
        jPanel32 = new javax.swing.JPanel();
        label2203 = new javax.swing.JLabel();
        label2201 = new javax.swing.JLabel();
        label2204 = new javax.swing.JLabel();
        label2202 = new javax.swing.JLabel();
        jLabel139 = new javax.swing.JLabel();
        jPanel33 = new javax.swing.JPanel();
        label2401 = new javax.swing.JLabel();
        label2404 = new javax.swing.JLabel();
        label2403 = new javax.swing.JLabel();
        label2402 = new javax.swing.JLabel();
        jLabel141 = new javax.swing.JLabel();
        jPanel34 = new javax.swing.JPanel();
        label2303 = new javax.swing.JLabel();
        label2304 = new javax.swing.JLabel();
        jLabel131 = new javax.swing.JLabel();
        label2301 = new javax.swing.JLabel();
        label2302 = new javax.swing.JLabel();
        jPanel35 = new javax.swing.JPanel();
        label3102 = new javax.swing.JLabel();
        label3103 = new javax.swing.JLabel();
        jLabel176 = new javax.swing.JLabel();
        label3101 = new javax.swing.JLabel();
        label3104 = new javax.swing.JLabel();
        jPanel37 = new javax.swing.JPanel();
        label2902 = new javax.swing.JLabel();
        label2903 = new javax.swing.JLabel();
        jLabel174 = new javax.swing.JLabel();
        label2901 = new javax.swing.JLabel();
        label2904 = new javax.swing.JLabel();
        jPanel36 = new javax.swing.JPanel();
        label3002 = new javax.swing.JLabel();
        label3003 = new javax.swing.JLabel();
        jLabel166 = new javax.swing.JLabel();
        label3001 = new javax.swing.JLabel();
        label3004 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jPanel38 = new javax.swing.JPanel();
        list2 = new java.awt.List();
        jButton5 = new javax.swing.JButton();
        jButton7 = new javax.swing.JButton();
        jButton8 = new javax.swing.JButton();
        list3 = new java.awt.List();
        jButton10 = new javax.swing.JButton();
        jButton11 = new javax.swing.JButton();
        jLabel16 = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        jButton12 = new javax.swing.JButton();
        jPanel4 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jButton3 = new javax.swing.JButton();
        list1 = new java.awt.List();
        jButton4 = new javax.swing.JButton();
        jMenuBar1 = new javax.swing.JMenuBar();
        jMenu1 = new javax.swing.JMenu();
        jMenuItem1 = new javax.swing.JMenuItem();
        jMenuItem2 = new javax.swing.JMenuItem();
        jMenuItem3 = new javax.swing.JMenuItem();
        jMenuItem4 = new javax.swing.JMenuItem();
        jMenuItem5 = new javax.swing.JMenuItem();
        jMenuItem6 = new javax.swing.JMenuItem();
        jMenu2 = new javax.swing.JMenu();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setBackground(new java.awt.Color(0, 0, 0));
        setSize(new java.awt.Dimension(1066, 639));
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosed(java.awt.event.WindowEvent evt) {
                formWindowClosed(evt);
            }
            public void windowClosing(java.awt.event.WindowEvent evt) {
                formWindowClosing(evt);
            }
        });

        jTabbedPane1.setBackground(new java.awt.Color(255, 255, 255));

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                jPanel1FocusGained(evt);
            }
        });

        jComboBox1.addPopupMenuListener(new javax.swing.event.PopupMenuListener() {
            public void popupMenuCanceled(javax.swing.event.PopupMenuEvent evt) {
            }
            public void popupMenuWillBecomeInvisible(javax.swing.event.PopupMenuEvent evt) {
                jComboBox1PopupMenuWillBecomeInvisible(evt);
            }
            public void popupMenuWillBecomeVisible(javax.swing.event.PopupMenuEvent evt) {
                jComboBox1PopupMenuWillBecomeVisible(evt);
            }
        });

        jLabel3.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        jLabel3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel3.setText("Avaliação do Dia");

        jLabel4.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        jLabel4.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel4.setText("Anotação do Dia");

        jButton2.setFont(new java.awt.Font("Arial", 1, 12)); // NOI18N
        jButton2.setText("SALVAR O DIA");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jPanel5.setBackground(new java.awt.Color(204, 204, 204));

        jTextArea1.setEditable(false);
        jTextArea1.setColumns(20);
        jTextArea1.setFont(new java.awt.Font("Verdana", 0, 14)); // NOI18N
        jTextArea1.setRows(5);
        jScrollPane4.setViewportView(jTextArea1);

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane4, javax.swing.GroupLayout.DEFAULT_SIZE, 356, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane4, javax.swing.GroupLayout.DEFAULT_SIZE, 226, Short.MAX_VALUE)
                .addContainerGap())
        );

        jLabel5.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        jLabel5.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel5.setText("Mensagem Motivacional");

        jTextArea2.setColumns(20);
        jTextArea2.setFont(new java.awt.Font("Calibri", 0, 14)); // NOI18N
        jTextArea2.setRows(5);
        jScrollPane1.setViewportView(jTextArea2);

        jTextArea3.setColumns(20);
        jTextArea3.setFont(new java.awt.Font("Calibri", 0, 14)); // NOI18N
        jTextArea3.setRows(3);
        jScrollPane2.setViewportView(jTextArea3);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(39, 39, 39)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jComboBox1, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel4, javax.swing.GroupLayout.DEFAULT_SIZE, 324, Short.MAX_VALUE)
                    .addComponent(jScrollPane1))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 308, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 239, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton2, javax.swing.GroupLayout.DEFAULT_SIZE, 382, Short.MAX_VALUE)
                    .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel5, javax.swing.GroupLayout.DEFAULT_SIZE, 382, Short.MAX_VALUE)
                    .addComponent(jScrollPane2))
                .addGap(47, 47, 47))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(40, 40, 40)
                .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 56, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 73, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jScrollPane1))
                .addContainerGap(72, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("Dia da Semana", jPanel1);

        jPanel6.setBackground(new java.awt.Color(255, 255, 255));

        jComboBox2.setFont(new java.awt.Font("Calibri", 1, 18)); // NOI18N
        jComboBox2.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Janeiro", "Fevereiro", "Março", "Abril", "Maio", "Junho", "Julho", "Agosto", "Setembro", "Outubro", "Novembro", "Dezembro" }));
        jComboBox2.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                jComboBox2ItemStateChanged(evt);
            }
        });
        jComboBox2.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                jComboBox2FocusLost(evt);
            }
        });
        jComboBox2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox2ActionPerformed(evt);
            }
        });

        jButton1.setFont(new java.awt.Font("Calibri", 1, 18)); // NOI18N
        jButton1.setText("ADICIONAR COMPROMISSOS");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jLabel7.setFont(new java.awt.Font("Calibri", 1, 18)); // NOI18N
        jLabel7.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel7.setText("LEGENDAS");

        jLabel6.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(255, 0, 0));
        jLabel6.setText("••");

        jLabel8.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        jLabel8.setForeground(java.awt.Color.blue);
        jLabel8.setText("••");

        jLabel9.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(51, 255, 51));
        jLabel9.setText("••");

        jLabel10.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(204, 0, 204));
        jLabel10.setText("••");

        jLabel11.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(255, 0, 0));
        jLabel11.setText("Trabalho");

        jLabel12.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        jLabel12.setForeground(java.awt.Color.blue);
        jLabel12.setText("Lazer");

        jLabel13.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        jLabel13.setForeground(java.awt.Color.green);
        jLabel13.setText("Médico");

        jLabel14.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        jLabel14.setForeground(new java.awt.Color(204, 0, 204));
        jLabel14.setText("Outros");

        jButton6.setFont(new java.awt.Font("Calibri", 1, 18)); // NOI18N
        jButton6.setText("VER COMPROMISSOS DO MÊS");
        jButton6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton6ActionPerformed(evt);
            }
        });

        jPanel7.setBackground(new java.awt.Color(255, 255, 255));
        jPanel7.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        label103.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        label103.setText("••");

        jLabel171.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        jLabel171.setText("01");

        label101.setBackground(new java.awt.Color(0, 0, 0));
        label101.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        label101.setText("••");

        label104.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        label104.setText("••");

        label102.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        label102.setText("••");

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(label104)
                    .addGroup(jPanel7Layout.createSequentialGroup()
                        .addComponent(label101)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel171))
                    .addComponent(label102)
                    .addComponent(label103))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addGap(12, 12, 12)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(label101)
                    .addComponent(jLabel171))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(label102)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(label103)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(label104))
        );

        jPanel8.setBackground(new java.awt.Color(255, 255, 255));
        jPanel8.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jLabel158.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        jLabel158.setText("02");

        label201.setBackground(new java.awt.Color(0, 0, 0));
        label201.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        label201.setText("••");

        label202.setBackground(new java.awt.Color(0, 0, 0));
        label202.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        label202.setText("••");

        label203.setBackground(new java.awt.Color(0, 0, 0));
        label203.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        label203.setText("••");

        label204.setBackground(new java.awt.Color(0, 0, 0));
        label204.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        label204.setText("••");

        javax.swing.GroupLayout jPanel8Layout = new javax.swing.GroupLayout(jPanel8);
        jPanel8.setLayout(jPanel8Layout);
        jPanel8Layout.setHorizontalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel8Layout.createSequentialGroup()
                        .addComponent(label201)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel158))
                    .addComponent(label202)
                    .addComponent(label203)
                    .addComponent(label204))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel8Layout.setVerticalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addGap(12, 12, 12)
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(label201)
                    .addComponent(jLabel158))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(label202)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(label203)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(label204))
        );

        jPanel9.setBackground(new java.awt.Color(255, 255, 255));
        jPanel9.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jLabel173.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        jLabel173.setText("03");

        label301.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        label301.setText("••");

        label304.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        label304.setText("••");

        label303.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        label303.setText("••");

        label302.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        label302.setText("••");

        javax.swing.GroupLayout jPanel9Layout = new javax.swing.GroupLayout(jPanel9);
        jPanel9.setLayout(jPanel9Layout);
        jPanel9Layout.setHorizontalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel9Layout.createSequentialGroup()
                        .addComponent(label301)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel173))
                    .addComponent(label302)
                    .addComponent(label303)
                    .addComponent(label304))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel9Layout.setVerticalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addGap(12, 12, 12)
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(label301)
                    .addComponent(jLabel173))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(label302)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(label303)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(label304))
        );

        jPanel10.setBackground(new java.awt.Color(255, 255, 255));
        jPanel10.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        label402.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        label402.setText("••");

        label404.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        label404.setText("••");

        label403.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        label403.setText("••");

        jLabel218.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        jLabel218.setText("04");

        label401.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        label401.setText("••");

        javax.swing.GroupLayout jPanel10Layout = new javax.swing.GroupLayout(jPanel10);
        jPanel10.setLayout(jPanel10Layout);
        jPanel10Layout.setHorizontalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel10Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel10Layout.createSequentialGroup()
                        .addComponent(label401)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel218))
                    .addComponent(label402)
                    .addComponent(label403)
                    .addComponent(label404))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel10Layout.setVerticalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel10Layout.createSequentialGroup()
                .addGap(12, 12, 12)
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(label401)
                    .addComponent(jLabel218))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(label402)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(label403)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(label404))
        );

        jPanel11.setBackground(new java.awt.Color(255, 255, 255));
        jPanel11.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jLabel156.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        jLabel156.setText("05");

        label504.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        label504.setText("••");

        label501.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        label501.setText("••");

        label503.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        label503.setText("••");

        label502.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        label502.setText("••");

        javax.swing.GroupLayout jPanel11Layout = new javax.swing.GroupLayout(jPanel11);
        jPanel11.setLayout(jPanel11Layout);
        jPanel11Layout.setHorizontalGroup(
            jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel11Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel11Layout.createSequentialGroup()
                        .addComponent(label501)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel156))
                    .addComponent(label502)
                    .addComponent(label503)
                    .addComponent(label504))
                .addContainerGap())
        );
        jPanel11Layout.setVerticalGroup(
            jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel11Layout.createSequentialGroup()
                .addGap(12, 12, 12)
                .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(label501)
                    .addComponent(jLabel156))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(label502)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(label503)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(label504))
        );

        jPanel12.setBackground(new java.awt.Color(255, 255, 255));
        jPanel12.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jLabel162.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        jLabel162.setText("06");

        label604.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        label604.setText("••");

        label602.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        label602.setText("••");

        label601.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        label601.setText("••");

        label603.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        label603.setText("••");

        javax.swing.GroupLayout jPanel12Layout = new javax.swing.GroupLayout(jPanel12);
        jPanel12.setLayout(jPanel12Layout);
        jPanel12Layout.setHorizontalGroup(
            jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel12Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel12Layout.createSequentialGroup()
                        .addComponent(label601)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel162))
                    .addComponent(label602)
                    .addComponent(label603)
                    .addComponent(label604))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel12Layout.setVerticalGroup(
            jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel12Layout.createSequentialGroup()
                .addGap(12, 12, 12)
                .addGroup(jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(label601)
                    .addComponent(jLabel162))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(label602)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(label603)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(label604))
        );

        jPanel13.setBackground(new java.awt.Color(255, 255, 255));
        jPanel13.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        label703.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        label703.setText("••");

        label704.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        label704.setText("••");

        jLabel224.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        jLabel224.setText("07");

        label702.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        label702.setText("••");

        label701.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        label701.setText("••");

        javax.swing.GroupLayout jPanel13Layout = new javax.swing.GroupLayout(jPanel13);
        jPanel13.setLayout(jPanel13Layout);
        jPanel13Layout.setHorizontalGroup(
            jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel13Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel13Layout.createSequentialGroup()
                        .addComponent(label701)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel224))
                    .addComponent(label702)
                    .addComponent(label703)
                    .addComponent(label704))
                .addContainerGap())
        );
        jPanel13Layout.setVerticalGroup(
            jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel13Layout.createSequentialGroup()
                .addGap(12, 12, 12)
                .addGroup(jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(label701)
                    .addComponent(jLabel224))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(label702)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(label703)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(label704))
        );

        jPanel14.setBackground(new java.awt.Color(255, 255, 255));
        jPanel14.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        label903.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        label903.setText("••");

        label904.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        label904.setText("••");

        jLabel248.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        jLabel248.setText("09");

        label901.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        label901.setText("••");

        label902.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        label902.setText("••");

        javax.swing.GroupLayout jPanel14Layout = new javax.swing.GroupLayout(jPanel14);
        jPanel14.setLayout(jPanel14Layout);
        jPanel14Layout.setHorizontalGroup(
            jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel14Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel14Layout.createSequentialGroup()
                        .addComponent(label901)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel248))
                    .addComponent(label902)
                    .addComponent(label903)
                    .addComponent(label904))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel14Layout.setVerticalGroup(
            jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel14Layout.createSequentialGroup()
                .addGap(12, 12, 12)
                .addGroup(jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(label901)
                    .addComponent(jLabel248))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(label902)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(label903)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(label904))
        );

        jPanel15.setBackground(new java.awt.Color(255, 255, 255));
        jPanel15.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        label1001.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        label1001.setText("••");

        label1004.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        label1004.setText("••");

        label1003.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        label1003.setText("••");

        label1002.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        label1002.setText("••");

        jLabel258.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        jLabel258.setText("10");

        javax.swing.GroupLayout jPanel15Layout = new javax.swing.GroupLayout(jPanel15);
        jPanel15.setLayout(jPanel15Layout);
        jPanel15Layout.setHorizontalGroup(
            jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel15Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel15Layout.createSequentialGroup()
                        .addComponent(label1001)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel258))
                    .addComponent(label1002)
                    .addComponent(label1003)
                    .addComponent(label1004))
                .addContainerGap())
        );
        jPanel15Layout.setVerticalGroup(
            jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel15Layout.createSequentialGroup()
                .addGap(12, 12, 12)
                .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(label1001)
                    .addComponent(jLabel258))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(label1002)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(label1003)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(label1004))
        );

        jPanel16.setBackground(new java.awt.Color(255, 255, 255));
        jPanel16.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        label1103.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        label1103.setText("••");

        jLabel234.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        jLabel234.setText("11");

        label1101.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        label1101.setText("••");

        label1102.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        label1102.setText("••");

        label1104.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        label1104.setText("••");

        javax.swing.GroupLayout jPanel16Layout = new javax.swing.GroupLayout(jPanel16);
        jPanel16.setLayout(jPanel16Layout);
        jPanel16Layout.setHorizontalGroup(
            jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel16Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel16Layout.createSequentialGroup()
                        .addComponent(label1101)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel234))
                    .addComponent(label1102)
                    .addComponent(label1103)
                    .addComponent(label1104))
                .addContainerGap())
        );
        jPanel16Layout.setVerticalGroup(
            jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel16Layout.createSequentialGroup()
                .addGap(12, 12, 12)
                .addGroup(jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(label1101)
                    .addComponent(jLabel234))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(label1102)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(label1103)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(label1104))
        );

        jPanel17.setBackground(new java.awt.Color(255, 255, 255));
        jPanel17.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        label1203.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        label1203.setText("••");

        label1202.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        label1202.setText("••");

        jLabel247.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        jLabel247.setText("12");

        label1204.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        label1204.setText("••");

        label1201.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        label1201.setText("••");

        javax.swing.GroupLayout jPanel17Layout = new javax.swing.GroupLayout(jPanel17);
        jPanel17.setLayout(jPanel17Layout);
        jPanel17Layout.setHorizontalGroup(
            jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel17Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel17Layout.createSequentialGroup()
                        .addComponent(label1201)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel247))
                    .addComponent(label1202)
                    .addComponent(label1203)
                    .addComponent(label1204))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel17Layout.setVerticalGroup(
            jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel17Layout.createSequentialGroup()
                .addGap(12, 12, 12)
                .addGroup(jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(label1201)
                    .addComponent(jLabel247))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(label1202)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(label1203)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(label1204))
        );

        jPanel18.setBackground(new java.awt.Color(255, 255, 255));
        jPanel18.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        label1301.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        label1301.setText("••");

        label1303.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        label1303.setText("••");

        jLabel250.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        jLabel250.setText("13");

        label1304.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        label1304.setText("••");

        label1302.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        label1302.setText("••");

        javax.swing.GroupLayout jPanel18Layout = new javax.swing.GroupLayout(jPanel18);
        jPanel18.setLayout(jPanel18Layout);
        jPanel18Layout.setHorizontalGroup(
            jPanel18Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel18Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel18Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel18Layout.createSequentialGroup()
                        .addComponent(label1301)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel250))
                    .addComponent(label1302)
                    .addComponent(label1303)
                    .addComponent(label1304))
                .addContainerGap())
        );
        jPanel18Layout.setVerticalGroup(
            jPanel18Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel18Layout.createSequentialGroup()
                .addGap(12, 12, 12)
                .addGroup(jPanel18Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(label1301)
                    .addComponent(jLabel250))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(label1302)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(label1303)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(label1304))
        );

        jPanel19.setBackground(new java.awt.Color(255, 255, 255));
        jPanel19.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        label1404.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        label1404.setText("••");

        jLabel240.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        jLabel240.setText("14");

        label1402.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        label1402.setText("••");

        label1401.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        label1401.setText("••");

        label1403.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        label1403.setText("••");

        javax.swing.GroupLayout jPanel19Layout = new javax.swing.GroupLayout(jPanel19);
        jPanel19.setLayout(jPanel19Layout);
        jPanel19Layout.setHorizontalGroup(
            jPanel19Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel19Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel19Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel19Layout.createSequentialGroup()
                        .addComponent(label1401)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel240))
                    .addComponent(label1402)
                    .addComponent(label1403)
                    .addComponent(label1404))
                .addContainerGap())
        );
        jPanel19Layout.setVerticalGroup(
            jPanel19Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel19Layout.createSequentialGroup()
                .addGap(12, 12, 12)
                .addGroup(jPanel19Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(label1401)
                    .addComponent(jLabel240))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(label1402)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(label1403)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(label1404))
        );

        jPanel20.setBackground(new java.awt.Color(255, 255, 255));
        jPanel20.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        label802.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        label802.setText("••");

        label803.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        label803.setText("••");

        jLabel256.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        jLabel256.setText("08");

        label801.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        label801.setText("••");

        label804.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        label804.setText("••");

        javax.swing.GroupLayout jPanel20Layout = new javax.swing.GroupLayout(jPanel20);
        jPanel20.setLayout(jPanel20Layout);
        jPanel20Layout.setHorizontalGroup(
            jPanel20Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel20Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel20Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel20Layout.createSequentialGroup()
                        .addComponent(label801)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel256))
                    .addComponent(label802)
                    .addComponent(label803)
                    .addComponent(label804))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel20Layout.setVerticalGroup(
            jPanel20Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel20Layout.createSequentialGroup()
                .addGap(12, 12, 12)
                .addGroup(jPanel20Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(label801)
                    .addComponent(jLabel256))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(label802)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(label803)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(label804))
        );

        jPanel21.setBackground(new java.awt.Color(255, 255, 255));
        jPanel21.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        label1803.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        label1803.setText("••");

        jLabel82.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        jLabel82.setText("18");

        label1801.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        label1801.setText("••");

        label1802.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        label1802.setText("••");

        label1804.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        label1804.setText("••");

        javax.swing.GroupLayout jPanel21Layout = new javax.swing.GroupLayout(jPanel21);
        jPanel21.setLayout(jPanel21Layout);
        jPanel21Layout.setHorizontalGroup(
            jPanel21Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel21Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel21Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel21Layout.createSequentialGroup()
                        .addComponent(label1801)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel82))
                    .addComponent(label1802)
                    .addComponent(label1803)
                    .addComponent(label1804))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel21Layout.setVerticalGroup(
            jPanel21Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel21Layout.createSequentialGroup()
                .addGap(12, 12, 12)
                .addGroup(jPanel21Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(label1801)
                    .addComponent(jLabel82))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(label1802)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(label1803)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(label1804))
        );

        jPanel22.setBackground(new java.awt.Color(255, 255, 255));
        jPanel22.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        label1903.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        label1903.setText("••");

        label1902.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        label1902.setText("••");

        jLabel95.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        jLabel95.setText("19");

        label1904.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        label1904.setText("••");

        label1901.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        label1901.setText("••");

        javax.swing.GroupLayout jPanel22Layout = new javax.swing.GroupLayout(jPanel22);
        jPanel22.setLayout(jPanel22Layout);
        jPanel22Layout.setHorizontalGroup(
            jPanel22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel22Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel22Layout.createSequentialGroup()
                        .addComponent(label1901)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel95))
                    .addComponent(label1902)
                    .addComponent(label1903)
                    .addComponent(label1904))
                .addContainerGap())
        );
        jPanel22Layout.setVerticalGroup(
            jPanel22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel22Layout.createSequentialGroup()
                .addGap(12, 12, 12)
                .addGroup(jPanel22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(label1901)
                    .addComponent(jLabel95))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(label1902)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(label1903)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(label1904))
        );

        jPanel23.setBackground(new java.awt.Color(255, 255, 255));
        jPanel23.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        label2001.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        label2001.setText("••");

        label2003.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        label2003.setText("••");

        jLabel98.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        jLabel98.setText("20");

        label2004.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        label2004.setText("••");

        label2002.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        label2002.setText("••");

        javax.swing.GroupLayout jPanel23Layout = new javax.swing.GroupLayout(jPanel23);
        jPanel23.setLayout(jPanel23Layout);
        jPanel23Layout.setHorizontalGroup(
            jPanel23Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel23Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel23Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel23Layout.createSequentialGroup()
                        .addComponent(label2001)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel98))
                    .addComponent(label2002)
                    .addComponent(label2003)
                    .addComponent(label2004))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel23Layout.setVerticalGroup(
            jPanel23Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel23Layout.createSequentialGroup()
                .addGap(12, 12, 12)
                .addGroup(jPanel23Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(label2001)
                    .addComponent(jLabel98))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(label2002)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(label2003)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(label2004))
        );

        jPanel24.setBackground(new java.awt.Color(255, 255, 255));
        jPanel24.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        label2104.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        label2104.setText("••");

        jLabel88.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        jLabel88.setText("21");

        label2102.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        label2102.setText("••");

        label2101.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        label2101.setText("••");

        label2103.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        label2103.setText("••");

        javax.swing.GroupLayout jPanel24Layout = new javax.swing.GroupLayout(jPanel24);
        jPanel24.setLayout(jPanel24Layout);
        jPanel24Layout.setHorizontalGroup(
            jPanel24Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel24Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel24Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel24Layout.createSequentialGroup()
                        .addComponent(label2101)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel88))
                    .addComponent(label2102)
                    .addComponent(label2103)
                    .addComponent(label2104))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel24Layout.setVerticalGroup(
            jPanel24Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel24Layout.createSequentialGroup()
                .addGap(11, 11, 11)
                .addGroup(jPanel24Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(label2101)
                    .addComponent(jLabel88))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(label2102)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(label2103)
                .addGap(7, 7, 7)
                .addComponent(label2104))
        );

        jPanel25.setBackground(new java.awt.Color(255, 255, 255));
        jPanel25.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        label1603.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        label1603.setText("••");

        label1604.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        label1604.setText("••");

        jLabel96.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        jLabel96.setText("16");

        label1601.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        label1601.setText("••");

        label1602.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        label1602.setText("••");

        javax.swing.GroupLayout jPanel25Layout = new javax.swing.GroupLayout(jPanel25);
        jPanel25.setLayout(jPanel25Layout);
        jPanel25Layout.setHorizontalGroup(
            jPanel25Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel25Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel25Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel25Layout.createSequentialGroup()
                        .addComponent(label1601)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel96))
                    .addComponent(label1602)
                    .addComponent(label1603)
                    .addComponent(label1604))
                .addContainerGap())
        );
        jPanel25Layout.setVerticalGroup(
            jPanel25Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel25Layout.createSequentialGroup()
                .addGap(12, 12, 12)
                .addGroup(jPanel25Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(label1601)
                    .addComponent(jLabel96))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(label1602)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(label1603)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(label1604))
        );

        jPanel26.setBackground(new java.awt.Color(255, 255, 255));
        jPanel26.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        label1502.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        label1502.setText("••");

        label1503.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        label1503.setText("••");

        jLabel104.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        jLabel104.setText("15");

        label1501.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        label1501.setText("••");

        label1504.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        label1504.setText("••");

        javax.swing.GroupLayout jPanel26Layout = new javax.swing.GroupLayout(jPanel26);
        jPanel26.setLayout(jPanel26Layout);
        jPanel26Layout.setHorizontalGroup(
            jPanel26Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel26Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel26Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel26Layout.createSequentialGroup()
                        .addComponent(label1501)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel104))
                    .addComponent(label1502)
                    .addComponent(label1503)
                    .addComponent(label1504))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel26Layout.setVerticalGroup(
            jPanel26Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel26Layout.createSequentialGroup()
                .addGap(12, 12, 12)
                .addGroup(jPanel26Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(label1501)
                    .addComponent(jLabel104))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(label1502)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(label1503)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(label1504))
        );

        jPanel27.setBackground(new java.awt.Color(255, 255, 255));
        jPanel27.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        label1701.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        label1701.setText("••");

        label1704.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        label1704.setText("••");

        label1703.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        label1703.setText("••");

        label1702.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        label1702.setText("••");

        jLabel106.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        jLabel106.setText("17");

        javax.swing.GroupLayout jPanel27Layout = new javax.swing.GroupLayout(jPanel27);
        jPanel27.setLayout(jPanel27Layout);
        jPanel27Layout.setHorizontalGroup(
            jPanel27Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel27Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel27Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel27Layout.createSequentialGroup()
                        .addComponent(label1701)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel106))
                    .addComponent(label1702)
                    .addComponent(label1703)
                    .addComponent(label1704))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel27Layout.setVerticalGroup(
            jPanel27Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel27Layout.createSequentialGroup()
                .addGap(12, 12, 12)
                .addGroup(jPanel27Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(label1701)
                    .addComponent(jLabel106))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(label1702)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(label1703)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(label1704))
        );

        jPanel28.setBackground(new java.awt.Color(255, 255, 255));
        jPanel28.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        label2804.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        label2804.setText("••");

        jLabel123.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        jLabel123.setText("28");

        label2802.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        label2802.setText("••");

        label2801.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        label2801.setText("••");

        label2803.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        label2803.setText("••");

        javax.swing.GroupLayout jPanel28Layout = new javax.swing.GroupLayout(jPanel28);
        jPanel28.setLayout(jPanel28Layout);
        jPanel28Layout.setHorizontalGroup(
            jPanel28Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel28Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel28Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel28Layout.createSequentialGroup()
                        .addComponent(label2801)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel123))
                    .addComponent(label2802)
                    .addComponent(label2803)
                    .addComponent(label2804))
                .addContainerGap())
        );
        jPanel28Layout.setVerticalGroup(
            jPanel28Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel28Layout.createSequentialGroup()
                .addGap(12, 12, 12)
                .addGroup(jPanel28Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(label2801)
                    .addComponent(jLabel123))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(label2802)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(label2803)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(label2804))
        );

        jPanel29.setBackground(new java.awt.Color(255, 255, 255));
        jPanel29.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        label2603.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        label2603.setText("••");

        label2602.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        label2602.setText("••");

        jLabel130.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        jLabel130.setText("26");

        label2604.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        label2604.setText("••");

        label2601.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        label2601.setText("••");

        javax.swing.GroupLayout jPanel29Layout = new javax.swing.GroupLayout(jPanel29);
        jPanel29.setLayout(jPanel29Layout);
        jPanel29Layout.setHorizontalGroup(
            jPanel29Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel29Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel29Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(label2602)
                    .addComponent(label2603)
                    .addComponent(label2604)
                    .addGroup(jPanel29Layout.createSequentialGroup()
                        .addComponent(label2601)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel130)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel29Layout.setVerticalGroup(
            jPanel29Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel29Layout.createSequentialGroup()
                .addGap(12, 12, 12)
                .addGroup(jPanel29Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(label2601)
                    .addComponent(jLabel130))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(label2602)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(label2603)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(label2604))
        );

        jPanel30.setBackground(new java.awt.Color(255, 255, 255));
        jPanel30.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        label2702.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        label2702.setText("••");

        label2701.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        label2701.setText("••");

        label2703.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        label2703.setText("••");

        jLabel133.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        jLabel133.setText("27");

        label2704.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        label2704.setText("••");

        javax.swing.GroupLayout jPanel30Layout = new javax.swing.GroupLayout(jPanel30);
        jPanel30.setLayout(jPanel30Layout);
        jPanel30Layout.setHorizontalGroup(
            jPanel30Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel30Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel30Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel30Layout.createSequentialGroup()
                        .addComponent(label2701)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel133))
                    .addComponent(label2702)
                    .addComponent(label2703)
                    .addComponent(label2704))
                .addContainerGap())
        );
        jPanel30Layout.setVerticalGroup(
            jPanel30Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel30Layout.createSequentialGroup()
                .addGap(12, 12, 12)
                .addGroup(jPanel30Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(label2701)
                    .addComponent(jLabel133))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(label2702)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(label2703)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(label2704))
        );

        jPanel31.setBackground(new java.awt.Color(255, 255, 255));
        jPanel31.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        label2503.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        label2503.setText("••");

        jLabel117.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        jLabel117.setText("25");

        label2501.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        label2501.setText("••");

        label2502.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        label2502.setText("••");

        label2504.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        label2504.setText("••");

        javax.swing.GroupLayout jPanel31Layout = new javax.swing.GroupLayout(jPanel31);
        jPanel31.setLayout(jPanel31Layout);
        jPanel31Layout.setHorizontalGroup(
            jPanel31Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel31Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel31Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel31Layout.createSequentialGroup()
                        .addComponent(label2501)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel117))
                    .addComponent(label2502)
                    .addComponent(label2503)
                    .addComponent(label2504))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel31Layout.setVerticalGroup(
            jPanel31Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel31Layout.createSequentialGroup()
                .addGap(12, 12, 12)
                .addGroup(jPanel31Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(label2501)
                    .addComponent(jLabel117))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(label2502)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(label2503)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(label2504))
        );

        jPanel32.setBackground(new java.awt.Color(255, 255, 255));
        jPanel32.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        label2203.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        label2203.setText("••");

        label2201.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        label2201.setText("••");

        label2204.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        label2204.setText("••");

        label2202.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        label2202.setText("••");

        jLabel139.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        jLabel139.setText("22");

        javax.swing.GroupLayout jPanel32Layout = new javax.swing.GroupLayout(jPanel32);
        jPanel32.setLayout(jPanel32Layout);
        jPanel32Layout.setHorizontalGroup(
            jPanel32Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel32Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel32Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(label2201)
                    .addComponent(label2202)
                    .addComponent(label2203)
                    .addComponent(label2204)
                    .addGroup(jPanel32Layout.createSequentialGroup()
                        .addGap(27, 27, 27)
                        .addComponent(jLabel139)))
                .addContainerGap(15, Short.MAX_VALUE))
        );
        jPanel32Layout.setVerticalGroup(
            jPanel32Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel32Layout.createSequentialGroup()
                .addGap(12, 12, 12)
                .addGroup(jPanel32Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel139)
                    .addGroup(jPanel32Layout.createSequentialGroup()
                        .addComponent(label2201)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(label2202)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(label2203)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(label2204)))
                .addGap(0, 0, Short.MAX_VALUE))
        );

        jPanel33.setBackground(new java.awt.Color(255, 255, 255));
        jPanel33.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        label2401.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        label2401.setText("••");

        label2404.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        label2404.setText("••");

        label2403.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        label2403.setText("••");

        label2402.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        label2402.setText("••");

        jLabel141.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        jLabel141.setText("24");

        javax.swing.GroupLayout jPanel33Layout = new javax.swing.GroupLayout(jPanel33);
        jPanel33.setLayout(jPanel33Layout);
        jPanel33Layout.setHorizontalGroup(
            jPanel33Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel33Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel33Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(label2402)
                    .addComponent(label2404)
                    .addComponent(label2403)
                    .addGroup(jPanel33Layout.createSequentialGroup()
                        .addComponent(label2401)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel141)))
                .addContainerGap())
        );
        jPanel33Layout.setVerticalGroup(
            jPanel33Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel33Layout.createSequentialGroup()
                .addGap(12, 12, 12)
                .addGroup(jPanel33Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(label2401)
                    .addComponent(jLabel141))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(label2402)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(label2403)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(label2404))
        );

        jPanel34.setBackground(new java.awt.Color(255, 255, 255));
        jPanel34.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        label2303.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        label2303.setText("••");

        label2304.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        label2304.setText("••");

        jLabel131.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        jLabel131.setText("23");

        label2301.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        label2301.setText("••");

        label2302.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        label2302.setText("••");

        javax.swing.GroupLayout jPanel34Layout = new javax.swing.GroupLayout(jPanel34);
        jPanel34.setLayout(jPanel34Layout);
        jPanel34Layout.setHorizontalGroup(
            jPanel34Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel34Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel34Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel34Layout.createSequentialGroup()
                        .addComponent(label2301)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel131))
                    .addComponent(label2302)
                    .addComponent(label2303)
                    .addComponent(label2304))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel34Layout.setVerticalGroup(
            jPanel34Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel34Layout.createSequentialGroup()
                .addGap(12, 12, 12)
                .addGroup(jPanel34Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(label2301)
                    .addComponent(jLabel131))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(label2302)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(label2303)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(label2304))
        );

        jPanel35.setBackground(new java.awt.Color(255, 255, 255));
        jPanel35.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        label3102.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        label3102.setText("••");

        label3103.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        label3103.setText("••");

        jLabel176.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        jLabel176.setText("31");

        label3101.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        label3101.setText("••");

        label3104.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        label3104.setText("••");

        javax.swing.GroupLayout jPanel35Layout = new javax.swing.GroupLayout(jPanel35);
        jPanel35.setLayout(jPanel35Layout);
        jPanel35Layout.setHorizontalGroup(
            jPanel35Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel35Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel35Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(label3102)
                    .addComponent(label3103)
                    .addComponent(label3104)
                    .addGroup(jPanel35Layout.createSequentialGroup()
                        .addComponent(label3101)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel176)))
                .addContainerGap())
        );
        jPanel35Layout.setVerticalGroup(
            jPanel35Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel35Layout.createSequentialGroup()
                .addGap(12, 12, 12)
                .addGroup(jPanel35Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(label3101)
                    .addComponent(jLabel176))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(label3102)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(label3103)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(label3104))
        );

        jPanel37.setBackground(new java.awt.Color(255, 255, 255));
        jPanel37.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        label2902.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        label2902.setText("••");

        label2903.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        label2903.setText("••");

        jLabel174.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        jLabel174.setText("29");

        label2901.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        label2901.setText("••");

        label2904.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        label2904.setText("••");

        javax.swing.GroupLayout jPanel37Layout = new javax.swing.GroupLayout(jPanel37);
        jPanel37.setLayout(jPanel37Layout);
        jPanel37Layout.setHorizontalGroup(
            jPanel37Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel37Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel37Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(label2902)
                    .addComponent(label2903)
                    .addComponent(label2904)
                    .addGroup(jPanel37Layout.createSequentialGroup()
                        .addComponent(label2901)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel174)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel37Layout.setVerticalGroup(
            jPanel37Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel37Layout.createSequentialGroup()
                .addGap(12, 12, 12)
                .addGroup(jPanel37Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(label2901)
                    .addComponent(jLabel174))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(label2902)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(label2903)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(label2904))
        );

        jPanel36.setBackground(new java.awt.Color(255, 255, 255));
        jPanel36.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        label3002.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        label3002.setText("••");

        label3003.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        label3003.setText("••");

        jLabel166.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        jLabel166.setText("30");

        label3001.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        label3001.setText("••");

        label3004.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        label3004.setText("••");

        javax.swing.GroupLayout jPanel36Layout = new javax.swing.GroupLayout(jPanel36);
        jPanel36.setLayout(jPanel36Layout);
        jPanel36Layout.setHorizontalGroup(
            jPanel36Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel36Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel36Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(label3002)
                    .addComponent(label3003)
                    .addComponent(label3004)
                    .addGroup(jPanel36Layout.createSequentialGroup()
                        .addComponent(label3001)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel166)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel36Layout.setVerticalGroup(
            jPanel36Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel36Layout.createSequentialGroup()
                .addGap(12, 12, 12)
                .addGroup(jPanel36Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(label3001)
                    .addComponent(jLabel166))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(label3002)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(label3003)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(label3004))
        );

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jComboBox2, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addComponent(jPanel7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jPanel8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jPanel9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jPanel10, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jPanel11, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jPanel12, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jPanel13, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addComponent(jPanel20, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jPanel14, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jPanel15, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jPanel16, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jPanel17, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jPanel18, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jPanel19, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addComponent(jPanel26, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jPanel25, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jPanel27, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jPanel21, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jPanel22, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jPanel23, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jPanel24, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(jPanel37, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jPanel32, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jPanel36, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jPanel34, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel6Layout.createSequentialGroup()
                                .addComponent(jPanel33, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jPanel31, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jPanel29, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jPanel30, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jPanel28, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jPanel35, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel6Layout.createSequentialGroup()
                                .addGap(176, 176, 176)
                                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel6Layout.createSequentialGroup()
                                        .addComponent(jLabel10)
                                        .addGap(18, 18, 18)
                                        .addComponent(jLabel14))
                                    .addGroup(jPanel6Layout.createSequentialGroup()
                                        .addComponent(jLabel9)
                                        .addGap(18, 18, 18)
                                        .addComponent(jLabel13))
                                    .addGroup(jPanel6Layout.createSequentialGroup()
                                        .addComponent(jLabel8)
                                        .addGap(18, 18, 18)
                                        .addComponent(jLabel12))
                                    .addGroup(jPanel6Layout.createSequentialGroup()
                                        .addComponent(jLabel6)
                                        .addGap(18, 18, 18)
                                        .addComponent(jLabel11)))
                                .addGap(0, 307, Short.MAX_VALUE))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel6Layout.createSequentialGroup()
                                .addGap(90, 90, 90)
                                .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 458, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addContainerGap())
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel6Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jButton6, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 428, Short.MAX_VALUE)
                            .addComponent(jButton1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))))
        );

        jPanel6Layout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {jPanel10, jPanel11, jPanel12, jPanel13, jPanel14, jPanel15, jPanel16, jPanel17, jPanel18, jPanel19, jPanel20, jPanel21, jPanel22, jPanel23, jPanel24, jPanel25, jPanel26, jPanel27, jPanel28, jPanel29, jPanel30, jPanel31, jPanel32, jPanel33, jPanel34, jPanel35, jPanel36, jPanel37, jPanel7, jPanel8, jPanel9});

        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabel7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jComboBox2, javax.swing.GroupLayout.DEFAULT_SIZE, 33, Short.MAX_VALUE))
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addGap(7, 7, 7)
                        .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(jPanel6Layout.createSequentialGroup()
                                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel6)
                                    .addComponent(jLabel11))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel8)
                                    .addComponent(jLabel12))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel9)
                                    .addComponent(jLabel13))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel10)
                                    .addComponent(jLabel14)))
                            .addComponent(jPanel7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jPanel8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel6Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jPanel10, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jPanel9, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jPanel11, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jPanel12, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jPanel13, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jPanel14, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jPanel20, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jPanel15, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jPanel16, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jPanel17, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jPanel18, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jPanel19, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(8, 8, 8)
                        .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(jPanel26, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jPanel25, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jPanel27, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jPanel21, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jPanel22, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jPanel23, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jPanel24, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel6Layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jPanel28, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel6Layout.createSequentialGroup()
                                        .addComponent(jPanel30, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(13, 13, 13))))
                            .addGroup(jPanel6Layout.createSequentialGroup()
                                .addGap(7, 7, 7)
                                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jPanel33, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                        .addComponent(jPanel32, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(jPanel34, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addComponent(jPanel31, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jPanel29, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jPanel37, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jPanel36, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jPanel35, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addGap(36, 36, 36)
                        .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jButton6, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(25, 25, 25))
        );

        jPanel6Layout.linkSize(javax.swing.SwingConstants.VERTICAL, new java.awt.Component[] {jPanel10, jPanel11, jPanel12, jPanel13, jPanel14, jPanel15, jPanel16, jPanel17, jPanel18, jPanel19, jPanel20, jPanel21, jPanel22, jPanel23, jPanel24, jPanel25, jPanel26, jPanel27, jPanel28, jPanel29, jPanel30, jPanel31, jPanel32, jPanel33, jPanel34, jPanel35, jPanel36, jPanel37, jPanel7, jPanel8, jPanel9});

        jTabbedPane1.addTab("Mês", jPanel6);

        jPanel38.setBackground(new java.awt.Color(255, 255, 255));

        jButton5.setFont(new java.awt.Font("Arial", 1, 12)); // NOI18N
        jButton5.setText("ADICIONAR FILME/SÉRIE");
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });

        jButton7.setFont(new java.awt.Font("Arial", 1, 12)); // NOI18N
        jButton7.setText("VER LINKS");
        jButton7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton7ActionPerformed(evt);
            }
        });

        jButton8.setFont(new java.awt.Font("Arial", 1, 12)); // NOI18N
        jButton8.setText("REMOVER SÉRIE");
        jButton8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton8ActionPerformed(evt);
            }
        });

        jButton10.setFont(new java.awt.Font("Arial", 1, 12)); // NOI18N
        jButton10.setText("VER LINKS");
        jButton10.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton10ActionPerformed(evt);
            }
        });

        jButton11.setFont(new java.awt.Font("Arial", 1, 12)); // NOI18N
        jButton11.setText("REMOVER FILME");
        jButton11.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton11ActionPerformed(evt);
            }
        });

        jLabel16.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        jLabel16.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel16.setText("SÉRIES");

        jLabel17.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        jLabel17.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel17.setText("FILMES");

        jButton12.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        jButton12.setText("ATUALIZAR");
        jButton12.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton12ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel38Layout = new javax.swing.GroupLayout(jPanel38);
        jPanel38.setLayout(jPanel38Layout);
        jPanel38Layout.setHorizontalGroup(
            jPanel38Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel38Layout.createSequentialGroup()
                .addGroup(jPanel38Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel38Layout.createSequentialGroup()
                        .addGap(101, 101, 101)
                        .addGroup(jPanel38Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jLabel16, javax.swing.GroupLayout.DEFAULT_SIZE, 186, Short.MAX_VALUE)
                            .addComponent(list2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel38Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jButton7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jButton8, javax.swing.GroupLayout.PREFERRED_SIZE, 133, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(79, 79, 79)
                        .addGroup(jPanel38Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jLabel17, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(list3, javax.swing.GroupLayout.PREFERRED_SIZE, 186, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel38Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jButton10, javax.swing.GroupLayout.PREFERRED_SIZE, 133, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jButton11, javax.swing.GroupLayout.PREFERRED_SIZE, 129, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 85, Short.MAX_VALUE)
                        .addComponent(jButton5))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel38Layout.createSequentialGroup()
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jButton12, javax.swing.GroupLayout.PREFERRED_SIZE, 138, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
        );
        jPanel38Layout.setVerticalGroup(
            jPanel38Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel38Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel38Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel38Layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addGroup(jPanel38Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(jPanel38Layout.createSequentialGroup()
                                .addComponent(jLabel17)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(list3, javax.swing.GroupLayout.PREFERRED_SIZE, 511, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel38Layout.createSequentialGroup()
                                .addComponent(jButton10)
                                .addGap(18, 18, 18)
                                .addComponent(jButton11))))
                    .addGroup(jPanel38Layout.createSequentialGroup()
                        .addComponent(jButton12)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel38Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(jPanel38Layout.createSequentialGroup()
                                .addComponent(jLabel16)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel38Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addGroup(jPanel38Layout.createSequentialGroup()
                                        .addComponent(jButton7)
                                        .addGap(18, 18, 18)
                                        .addComponent(jButton8))
                                    .addComponent(list2, javax.swing.GroupLayout.PREFERRED_SIZE, 511, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addComponent(jButton5))))
                .addGap(29, 29, 29))
        );

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel38, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel38, javax.swing.GroupLayout.PREFERRED_SIZE, 611, Short.MAX_VALUE)
        );

        jTabbedPane1.addTab("Filmes e Séries", jPanel2);

        jPanel4.setBackground(new java.awt.Color(255, 255, 255));
        jPanel4.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 3));
        jPanel4.setPreferredSize(new java.awt.Dimension(180, 100));

        jLabel1.setBackground(new java.awt.Color(255, 255, 255));
        jLabel1.setFont(new java.awt.Font("Arial", 1, 24)); // NOI18N
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("teste");

        jLabel15.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        jLabel15.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel15.setText("jLabel15");

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel15, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel15)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel3.setBackground(new java.awt.Color(255, 255, 255));
        jPanel3.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 3));

        jLabel2.setBackground(new java.awt.Color(255, 255, 255));
        jLabel2.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel2.setText("EVENTOS");

        jButton3.setBackground(new java.awt.Color(255, 255, 255));
        jButton3.setFont(new java.awt.Font("Arial", 1, 12)); // NOI18N
        jButton3.setText("ABRIR EVENTO");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        jButton4.setBackground(new java.awt.Color(255, 255, 255));
        jButton4.setFont(new java.awt.Font("Arial", 1, 12)); // NOI18N
        jButton4.setText("EXCLUIR EVENTO");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(list1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jButton3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jButton4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(list1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jButton3, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jButton4, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        jMenu1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagem/icons8-cardápio-48.png"))); // NOI18N
        jMenu1.setText("Arquivo");

        jMenuItem1.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_D, java.awt.event.InputEvent.CTRL_MASK));
        jMenuItem1.setText("Alterar dados do usuário");
        jMenuItem1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem1ActionPerformed(evt);
            }
        });
        jMenu1.add(jMenuItem1);

        jMenuItem2.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_S, java.awt.event.InputEvent.CTRL_MASK));
        jMenuItem2.setText("Adicionar Evento");
        jMenuItem2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem2ActionPerformed(evt);
            }
        });
        jMenu1.add(jMenuItem2);

        jMenuItem3.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_M, java.awt.event.InputEvent.CTRL_MASK));
        jMenuItem3.setText("Adicionar Amigos");
        jMenuItem3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem3ActionPerformed(evt);
            }
        });
        jMenu1.add(jMenuItem3);

        jMenuItem4.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_V, java.awt.event.InputEvent.CTRL_MASK));
        jMenuItem4.setText("Ver Convites de Amizade");
        jMenuItem4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem4ActionPerformed(evt);
            }
        });
        jMenu1.add(jMenuItem4);

        jMenuItem5.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_R, java.awt.event.InputEvent.CTRL_MASK));
        jMenuItem5.setText("Excluir Amigos");
        jMenuItem5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem5ActionPerformed(evt);
            }
        });
        jMenu1.add(jMenuItem5);

        jMenuItem6.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_E, java.awt.event.InputEvent.CTRL_MASK));
        jMenuItem6.setText("Ver Convites de Evento");
        jMenuItem6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem6ActionPerformed(evt);
            }
        });
        jMenu1.add(jMenuItem6);

        jMenuBar1.add(jMenu1);

        jMenu2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagem/icons8-fechar-janela-48.png"))); // NOI18N
        jMenu2.setText("Sair");
        jMenu2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jMenu2MouseClicked(evt);
            }
        });
        jMenuBar1.add(jMenu2);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, 157, Short.MAX_VALUE)
                    .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jTabbedPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(0, 0, 0)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jTabbedPane1)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jMenuItem1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem1ActionPerformed
        // TODO add your handling code here:
        MudarUsuario mudar = null;
        try {
            mudar = new MudarUsuario();
        } catch (ParseException | SQLException ex) {
            Logger.getLogger(Inicial.class.getName()).log(Level.SEVERE, null, ex);
        }
        mudar.setLocationRelativeTo(null);
        mudar.setVisible(true);
        dispose();
    }//GEN-LAST:event_jMenuItem1ActionPerformed

    private void jMenu2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jMenu2MouseClicked
        // TODO add your handling code here:
        Menu m = new Menu();
        m.setLocationRelativeTo(null);
        m.setVisible(true);
        dispose();
    }//GEN-LAST:event_jMenu2MouseClicked

    private void jMenuItem2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem2ActionPerformed
        // TODO add your handling code here:
        Evento g = null;
        try {
            g = new Evento();
        } catch (ParseException | SQLException ex) {
            Logger.getLogger(Inicial.class.getName()).log(Level.SEVERE, null, ex);
        }
        g.setLocationRelativeTo(null);
        g.setVisible(true);
        dispose();
    }//GEN-LAST:event_jMenuItem2ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        // TODO add your handling code here:
        dispose();
        conex.conexao();
        nomeEvento = list1.getSelectedItem();
        try {
            conex.executaSql("select *from Eventos where nome='" + nomeEvento + "'");
            conex.rs.first();
            idEventoSelecionado = Integer.parseInt(conex.rs.getString("idEventos"));
        } catch (NumberFormatException | SQLException e) {
        }
        if (nomeEvento != null) {
            EventosExibir e = null;
            try {
                e = new EventosExibir();
            } catch (ParseException ex) {
                Logger.getLogger(Inicial.class.getName()).log(Level.SEVERE, null, ex);
            } catch (SQLException ex) {
                Logger.getLogger(Inicial.class.getName()).log(Level.SEVERE, null, ex);
            }
            e.setVisible(true);
            System.out.println("Teste   " + nomeEvento + " teste  ");
        } else {
            JOptionPane.showMessageDialog(rootPane, "Selecione um evento");
        }
        conex.desconecta();

    }//GEN-LAST:event_jButton3ActionPerformed

    private void formWindowClosed(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowClosed
        // TODO add your handling code here:
        conex.desconecta();
    }//GEN-LAST:event_formWindowClosed

    private void jMenuItem3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem3ActionPerformed
        // TODO add your handling code here:
        AdicionarAmigos a = new AdicionarAmigos();
        a.setLocationRelativeTo(null);
        a.setVisible(true);

    }//GEN-LAST:event_jMenuItem3ActionPerformed

    private void jMenuItem4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem4ActionPerformed
        // TODO add your handling code here:
        ConvitesAmizade c = new ConvitesAmizade();
        c.setLocationRelativeTo(null);
        c.setVisible(true);

    }//GEN-LAST:event_jMenuItem4ActionPerformed

    private void jMenuItem5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem5ActionPerformed
        // TODO add your handling code here:
        ExcluirAmigos exc = new ExcluirAmigos();
        exc.setLocationRelativeTo(null);
        exc.setVisible(true);

    }//GEN-LAST:event_jMenuItem5ActionPerformed

    private void jMenuItem6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem6ActionPerformed
        // TODO add your handling code here:
        ConvitesEvento cve = new ConvitesEvento();
        cve.setLocationRelativeTo(null);
        cve.setVisible(true);
        dispose();

    }//GEN-LAST:event_jMenuItem6ActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        // TODO add your handling code here:
        conex.conexao();
        String idEvento;
        escolha = list1.getSelectedItem();

        if (escolha != null) {
            try {
                conex.executaSql("select *from Eventos where nome='" + escolha + "'");
                conex.rs.first();
                idEvento = conex.rs.getString("idEventos");

                try {

                    PreparedStatement pst2 = conex.connection.prepareStatement("delete from UsuarioEventos where binary idUsuario='" + Login.ID + "' AND binary idEvento='" + idEvento + "'");
                    pst2.execute();
                    JOptionPane.showMessageDialog(rootPane, "Evento excluído com sucesso");
                    atualizarLista();

                } catch (SQLException ex) {
                    JOptionPane.showMessageDialog(rootPane, "Erro ao excluir evento" + ex);
                }
            } catch (Exception e) {
                JOptionPane.showMessageDialog(rootPane, e);
            }

        } else {
            JOptionPane.showMessageDialog(rootPane, "Selecione um evento");
        }
        conex.desconecta();
    }//GEN-LAST:event_jButton4ActionPerformed

    private void formWindowClosing(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowClosing
        // TODO add your handling code here:
        Menu m = new Menu();
        m.setLocationRelativeTo(null);
        m.setVisible(true);

    }//GEN-LAST:event_formWindowClosing

    private void jButton6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton6ActionPerformed
        // TODO add your handling code here:
        mesSelecionado = (String) jComboBox2.getSelectedItem();
        VerCompromissos ver = null;
        try {
            ver = new VerCompromissos();
        } catch (ParseException ex) {
            Logger.getLogger(Inicial.class.getName()).log(Level.SEVERE, null, ex);
        }
        ver.setLocationRelativeTo(null);
        ver.setVisible(true);
        dispose();
    }//GEN-LAST:event_jButton6ActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
        mesSelecionado = (String) jComboBox2.getSelectedItem();
        AdicionarCompromisso m = new AdicionarCompromisso();
        m.setVisible(true);
        m.setLocationRelativeTo(null);
        dispose();
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jComboBox2FocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jComboBox2FocusLost
        // TODO add your handling code here:
    }//GEN-LAST:event_jComboBox2FocusLost

    private void jComboBox2ItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_jComboBox2ItemStateChanged
        // TODO add your handling code here:
        mes = (String) jComboBox2.getSelectedItem();
        carregarMes(mes);
        atualizarMes2();
        try {
            atualizarCompromissos();
        } catch (ParseException | SQLException ex) {
            Logger.getLogger(Inicial.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_jComboBox2ItemStateChanged

    private void jPanel1FocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jPanel1FocusGained
        // TODO add your handling code here:
    }//GEN-LAST:event_jPanel1FocusGained

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        // TODO add your handling code here:
        String anotacao = jTextArea2.getText();
        String nota = jTextArea3.getText();
        String escolhaS = (String) jComboBox1.getSelectedItem();
        control.SalvarInfos(anotacao, nota, id, escolhaS);
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jComboBox1PopupMenuWillBecomeVisible(javax.swing.event.PopupMenuEvent evt) {//GEN-FIRST:event_jComboBox1PopupMenuWillBecomeVisible
        // TODO add your handling code here:
    }//GEN-LAST:event_jComboBox1PopupMenuWillBecomeVisible

    private void jComboBox1PopupMenuWillBecomeInvisible(javax.swing.event.PopupMenuEvent evt) {//GEN-FIRST:event_jComboBox1PopupMenuWillBecomeInvisible
        // TODO add your handling code here:
        String escolhaS = (String) jComboBox1.getSelectedItem();
        try {
            conex.conexao();
            conex.executaSql("select *from Dia where data='" + escolhaS + "' AND idUsuario='" + id + "'");
            conex.rs.first();
            jTextArea3.setText(conex.rs.getString("anotacao"));
            jTextArea2.setText(conex.rs.getString("nota"));

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(rootPane, "Erro ao carregar o dia!" + ex);
            conex.desconecta();
        }
    }//GEN-LAST:event_jComboBox1PopupMenuWillBecomeInvisible

    private void jComboBox2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jComboBox2ActionPerformed

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
        // TODO add your handling code here:
       AdicionarFS afs = new AdicionarFS();
       afs.setVisible(true);
    }//GEN-LAST:event_jButton5ActionPerformed

    private void jButton12ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton12ActionPerformed
        // TODO add your handling code here:
        AtualizaFS();
    }//GEN-LAST:event_jButton12ActionPerformed

    private void jButton7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton7ActionPerformed
        // TODO add your handling code here:
        String escolhaF = list2.getSelectedItem();
        if(escolhaF.equals("")){
            JOptionPane.showMessageDialog(rootPane,"Selecione uma série");
        }
        else{
            fsSelecionado = escolhaF;
            fsEscolha = "Série";
            VerFS vFs = new VerFS();
            vFs.setVisible(true);
        }
        
    }//GEN-LAST:event_jButton7ActionPerformed

    private void jButton10ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton10ActionPerformed
        // TODO add your handling code here:
        String escolhaF = list3.getSelectedItem();
        if(escolhaF.equals("")){
            JOptionPane.showMessageDialog(rootPane,"Selecione um filme");
        }
        else{
            fsSelecionado = escolhaF;
            fsEscolha = "Filme";
            VerFS vFs = new VerFS();
            vFs.setVisible(true);
        }
    }//GEN-LAST:event_jButton10ActionPerformed

    private void jButton8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton8ActionPerformed
        // TODO add your handling code here:
        conex.conexao();
        control2.Excluir(list2.getSelectedItem(), "Série");
        
        AtualizaFS();
        conex.desconecta();
    }//GEN-LAST:event_jButton8ActionPerformed

    private void jButton11ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton11ActionPerformed
        // TODO add your handling code here:
        conex.conexao();
        control2.Excluir(list3.getSelectedItem(), "Filme");
        AtualizaFS();
        conex.desconecta();
    }//GEN-LAST:event_jButton11ActionPerformed

    private void AtualizaFS(){
       conex.conexao();
        list3.removeAll();
        list2.removeAll();
        try{
            conex.executaSql("select *from FS where idUsuario='"+Login.ID + "'");
            conex.rs.first();
            do{
                if(conex.rs.getString("tipo").equals("Filme")){
                    list3.add(conex.rs.getString("titulo"));
                }
                if(conex.rs.getString("tipo").equals("Série")){
                    list2.add(conex.rs.getString("titulo"));
                }
            }
            while(conex.rs.next());
        }
        
        catch(Exception efs){
            JOptionPane.showMessageDialog(rootPane,efs);
        }
        conex.desconecta();
        
    }
    
    private void carregarMes(String mes) {
        switch (mes) {
            case "Janeiro":
                jLabel174.setText("29");
                jLabel166.setText("30");
                jLabel176.setText("31");

                label2901.setText("••");
                label2902.setText("••");
                label2903.setText("••");
                label2904.setText("••");

                label3001.setText("••");
                label3002.setText("••");
                label3003.setText("••");
                label3004.setText("••");

                label3101.setText("••");
                label3102.setText("••");
                label3103.setText("••");
                label3104.setText("••");

                jPanel37.setVisible(true);
                jPanel36.setVisible(true);
                jPanel35.setVisible(true);
                break;
            case "Fevereiro":
                jLabel174.setText("");
                jLabel166.setText("");
                jLabel176.setText("");

                jLabel174.setText("");
                jLabel166.setText("");
                jLabel176.setText("");

                label2901.setText("");
                label2902.setText("");
                label2903.setText("");
                label2904.setText("");
                jPanel37.setVisible(false);

                label3001.setText("");
                label3002.setText("");
                label3003.setText("");
                label3004.setText("");
                jPanel36.setVisible(false);

                label3101.setText("");
                label3102.setText("");
                label3103.setText("");
                label3104.setText("");
                jPanel35.setVisible(false);
                break;
            case "Março":
                jLabel174.setText("29");
                jLabel166.setText("30");
                jLabel176.setText("31");

                label2901.setText("••");
                label2902.setText("••");
                label2903.setText("••");
                label2904.setText("••");

                label3001.setText("••");
                label3002.setText("••");
                label3003.setText("••");
                label3004.setText("••");

                label3101.setText("••");
                label3102.setText("••");
                label3103.setText("••");
                label3104.setText("••");
                jPanel37.setVisible(true);
                jPanel36.setVisible(true);
                jPanel35.setVisible(true);
                break;
            case "Abril":
                jLabel174.setText("29");
                jLabel166.setText("30");
                jLabel176.setText("");

                label2901.setText("••");
                label2902.setText("••");
                label2903.setText("••");
                label2904.setText("••");

                label3001.setText("••");
                label3002.setText("••");
                label3003.setText("••");
                label3004.setText("••");

                label3101.setText("");
                label3102.setText("");
                label3103.setText("");
                label3104.setText("");
                jPanel35.setVisible(false);

                jPanel37.setVisible(true);
                jPanel36.setVisible(true);

                break;
            case "Maio":
                jLabel174.setText("29");
                jLabel166.setText("30");
                jLabel176.setText("31");

                label2901.setText("••");
                label2902.setText("••");
                label2903.setText("••");
                label2904.setText("••");

                label3001.setText("••");
                label3002.setText("••");
                label3003.setText("••");
                label3004.setText("••");

                label3101.setText("••");
                label3102.setText("••");
                label3103.setText("••");
                label3104.setText("••");
                jPanel37.setVisible(true);
                jPanel36.setVisible(true);
                jPanel35.setVisible(true);
                break;
            case "Junho":
                jLabel174.setText("29");
                jLabel166.setText("30");
                jLabel176.setText("");

                label2901.setText("••");
                label2902.setText("••");
                label2903.setText("••");
                label2904.setText("••");

                label3001.setText("••");
                label3002.setText("••");
                label3003.setText("••");
                label3004.setText("••");

                label3101.setText("");
                label3102.setText("");
                label3103.setText("");
                label3104.setText("");
                jPanel37.setVisible(true);
                jPanel36.setVisible(true);

                jPanel35.setVisible(false);
                break;
            case "Julho":
                jLabel174.setText("29");
                jLabel166.setText("30");
                jLabel176.setText("31");

                label2901.setText("••");
                label2902.setText("••");
                label2903.setText("••");
                label2904.setText("••");

                label3001.setText("••");
                label3002.setText("••");
                label3003.setText("••");
                label3004.setText("••");

                label3101.setText("••");
                label3102.setText("••");
                label3103.setText("••");
                label3104.setText("••");
                jPanel37.setVisible(true);
                jPanel36.setVisible(true);
                jPanel35.setVisible(true);
                break;
            case "Agosto":
                jLabel174.setText("29");
                jLabel166.setText("30");
                jLabel176.setText("31");

                label2901.setText("••");
                label2902.setText("••");
                label2903.setText("••");
                label2904.setText("••");

                label3001.setText("••");
                label3002.setText("••");
                label3003.setText("••");
                label3004.setText("••");

                label3101.setText("••");
                label3102.setText("••");
                label3103.setText("••");
                label3104.setText("••");
                jPanel37.setVisible(true);
                jPanel36.setVisible(true);
                jPanel35.setVisible(true);
                break;
            case "Setembro":
                jLabel174.setText("29");
                jLabel166.setText("30");
                jLabel176.setText("");

                label2901.setText("••");
                label2902.setText("••");
                label2903.setText("••");
                label2904.setText("••");

                label3001.setText("••");
                label3002.setText("••");
                label3003.setText("••");
                label3004.setText("••");

                label3101.setText("");
                label3102.setText("");
                label3103.setText("");
                label3104.setText("");
                jPanel37.setVisible(true);
                jPanel36.setVisible(true);

                jPanel35.setVisible(false);
                break;
            case "Outubro":
                jLabel174.setText("29");
                jLabel166.setText("30");
                jLabel176.setText("31");

                label2901.setText("••");
                label2902.setText("••");
                label2903.setText("••");
                label2904.setText("••");

                label3001.setText("••");
                label3002.setText("••");
                label3003.setText("••");
                label3004.setText("••");

                label3101.setText("••");
                label3102.setText("••");
                label3103.setText("••");
                label3104.setText("••");
                jPanel37.setVisible(true);
                jPanel36.setVisible(true);
                jPanel35.setVisible(true);
                break;
            case "Novembro":
                jLabel174.setText("29");
                jLabel166.setText("30");
                jLabel176.setText("");

                label2901.setText("••");
                label2902.setText("••");
                label2903.setText("••");
                label2904.setText("••");

                label3001.setText("••");
                label3002.setText("••");
                label3003.setText("••");
                label3004.setText("••");

                label3101.setText("");
                label3102.setText("");
                label3103.setText("");
                label3104.setText("");
                jPanel37.setVisible(true);
                jPanel36.setVisible(true);

                jPanel35.setVisible(false);
                break;
            case "Dezembro":
                jLabel174.setText("29");
                jLabel166.setText("30");
                jLabel176.setText("31");

                label2901.setText("••");
                label2902.setText("••");
                label2903.setText("••");
                label2904.setText("••");

                label3001.setText("••");
                label3002.setText("••");
                label3003.setText("••");
                label3004.setText("••");

                label3101.setText("••");
                label3102.setText("••");
                label3103.setText("••");
                label3104.setText("••");
                jPanel37.setVisible(true);
                jPanel36.setVisible(true);
                jPanel35.setVisible(true);

                break;

        }
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException | InstantiationException | IllegalAccessException | javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Inicial.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        //</editor-fold>
        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> {
            try {
                new Inicial().setVisible(true);
            } catch (ParseException | SQLException ex) {
                Logger.getLogger(Inicial.class.getName()).log(Level.SEVERE, null, ex);
            }
        });
    }

    private String getDateTime() {
        DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
        Date date = new Date();
        return dateFormat.format(date);
    }

    private String criarDias(String date, int soma) throws ParseException {

        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        Calendar c = Calendar.getInstance();
        c.setTime(sdf.parse(date));
        c.add(Calendar.DATE, soma);
        date = sdf.format(c.getTime());
        return date;
    }


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton10;
    private javax.swing.JButton jButton11;
    private javax.swing.JButton jButton12;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton6;
    private javax.swing.JButton jButton7;
    private javax.swing.JButton jButton8;
    private javax.swing.JComboBox<String> jComboBox1;
    private javax.swing.JComboBox<String> jComboBox2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel104;
    private javax.swing.JLabel jLabel106;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel117;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel123;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel130;
    private javax.swing.JLabel jLabel131;
    private javax.swing.JLabel jLabel133;
    private javax.swing.JLabel jLabel139;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel141;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel156;
    private javax.swing.JLabel jLabel158;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel162;
    private javax.swing.JLabel jLabel166;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel171;
    private javax.swing.JLabel jLabel173;
    private javax.swing.JLabel jLabel174;
    private javax.swing.JLabel jLabel176;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel218;
    private javax.swing.JLabel jLabel224;
    private javax.swing.JLabel jLabel234;
    private javax.swing.JLabel jLabel240;
    private javax.swing.JLabel jLabel247;
    private javax.swing.JLabel jLabel248;
    private javax.swing.JLabel jLabel250;
    private javax.swing.JLabel jLabel256;
    private javax.swing.JLabel jLabel258;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel82;
    private javax.swing.JLabel jLabel88;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JLabel jLabel95;
    private javax.swing.JLabel jLabel96;
    private javax.swing.JLabel jLabel98;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenu jMenu2;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JMenuItem jMenuItem1;
    private javax.swing.JMenuItem jMenuItem2;
    private javax.swing.JMenuItem jMenuItem3;
    private javax.swing.JMenuItem jMenuItem4;
    private javax.swing.JMenuItem jMenuItem5;
    private javax.swing.JMenuItem jMenuItem6;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel10;
    private javax.swing.JPanel jPanel11;
    private javax.swing.JPanel jPanel12;
    private javax.swing.JPanel jPanel13;
    private javax.swing.JPanel jPanel14;
    private javax.swing.JPanel jPanel15;
    private javax.swing.JPanel jPanel16;
    private javax.swing.JPanel jPanel17;
    private javax.swing.JPanel jPanel18;
    private javax.swing.JPanel jPanel19;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel20;
    private javax.swing.JPanel jPanel21;
    private javax.swing.JPanel jPanel22;
    private javax.swing.JPanel jPanel23;
    private javax.swing.JPanel jPanel24;
    private javax.swing.JPanel jPanel25;
    private javax.swing.JPanel jPanel26;
    private javax.swing.JPanel jPanel27;
    private javax.swing.JPanel jPanel28;
    private javax.swing.JPanel jPanel29;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel30;
    private javax.swing.JPanel jPanel31;
    private javax.swing.JPanel jPanel32;
    private javax.swing.JPanel jPanel33;
    private javax.swing.JPanel jPanel34;
    private javax.swing.JPanel jPanel35;
    private javax.swing.JPanel jPanel36;
    private javax.swing.JPanel jPanel37;
    private javax.swing.JPanel jPanel38;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JTextArea jTextArea1;
    private javax.swing.JTextArea jTextArea2;
    private javax.swing.JTextArea jTextArea3;
    private javax.swing.JLabel label1001;
    private javax.swing.JLabel label1002;
    private javax.swing.JLabel label1003;
    private javax.swing.JLabel label1004;
    private javax.swing.JLabel label101;
    private javax.swing.JLabel label102;
    private javax.swing.JLabel label103;
    private javax.swing.JLabel label104;
    private javax.swing.JLabel label1101;
    private javax.swing.JLabel label1102;
    private javax.swing.JLabel label1103;
    private javax.swing.JLabel label1104;
    private javax.swing.JLabel label1201;
    private javax.swing.JLabel label1202;
    private javax.swing.JLabel label1203;
    private javax.swing.JLabel label1204;
    private javax.swing.JLabel label1301;
    private javax.swing.JLabel label1302;
    private javax.swing.JLabel label1303;
    private javax.swing.JLabel label1304;
    private javax.swing.JLabel label1401;
    private javax.swing.JLabel label1402;
    private javax.swing.JLabel label1403;
    private javax.swing.JLabel label1404;
    private javax.swing.JLabel label1501;
    private javax.swing.JLabel label1502;
    private javax.swing.JLabel label1503;
    private javax.swing.JLabel label1504;
    private javax.swing.JLabel label1601;
    private javax.swing.JLabel label1602;
    private javax.swing.JLabel label1603;
    private javax.swing.JLabel label1604;
    private javax.swing.JLabel label1701;
    private javax.swing.JLabel label1702;
    private javax.swing.JLabel label1703;
    private javax.swing.JLabel label1704;
    private javax.swing.JLabel label1801;
    private javax.swing.JLabel label1802;
    private javax.swing.JLabel label1803;
    private javax.swing.JLabel label1804;
    private javax.swing.JLabel label1901;
    private javax.swing.JLabel label1902;
    private javax.swing.JLabel label1903;
    private javax.swing.JLabel label1904;
    private javax.swing.JLabel label2001;
    private javax.swing.JLabel label2002;
    private javax.swing.JLabel label2003;
    private javax.swing.JLabel label2004;
    private javax.swing.JLabel label201;
    private javax.swing.JLabel label202;
    private javax.swing.JLabel label203;
    private javax.swing.JLabel label204;
    private javax.swing.JLabel label2101;
    private javax.swing.JLabel label2102;
    private javax.swing.JLabel label2103;
    private javax.swing.JLabel label2104;
    private javax.swing.JLabel label2201;
    private javax.swing.JLabel label2202;
    private javax.swing.JLabel label2203;
    private javax.swing.JLabel label2204;
    private javax.swing.JLabel label2301;
    private javax.swing.JLabel label2302;
    private javax.swing.JLabel label2303;
    private javax.swing.JLabel label2304;
    private javax.swing.JLabel label2401;
    private javax.swing.JLabel label2402;
    private javax.swing.JLabel label2403;
    private javax.swing.JLabel label2404;
    private javax.swing.JLabel label2501;
    private javax.swing.JLabel label2502;
    private javax.swing.JLabel label2503;
    private javax.swing.JLabel label2504;
    private javax.swing.JLabel label2601;
    private javax.swing.JLabel label2602;
    private javax.swing.JLabel label2603;
    private javax.swing.JLabel label2604;
    private javax.swing.JLabel label2701;
    private javax.swing.JLabel label2702;
    private javax.swing.JLabel label2703;
    private javax.swing.JLabel label2704;
    private javax.swing.JLabel label2801;
    private javax.swing.JLabel label2802;
    private javax.swing.JLabel label2803;
    private javax.swing.JLabel label2804;
    private javax.swing.JLabel label2901;
    private javax.swing.JLabel label2902;
    private javax.swing.JLabel label2903;
    private javax.swing.JLabel label2904;
    private javax.swing.JLabel label3001;
    private javax.swing.JLabel label3002;
    private javax.swing.JLabel label3003;
    private javax.swing.JLabel label3004;
    private javax.swing.JLabel label301;
    private javax.swing.JLabel label302;
    private javax.swing.JLabel label303;
    private javax.swing.JLabel label304;
    private javax.swing.JLabel label3101;
    private javax.swing.JLabel label3102;
    private javax.swing.JLabel label3103;
    private javax.swing.JLabel label3104;
    private javax.swing.JLabel label401;
    private javax.swing.JLabel label402;
    private javax.swing.JLabel label403;
    private javax.swing.JLabel label404;
    private javax.swing.JLabel label501;
    private javax.swing.JLabel label502;
    private javax.swing.JLabel label503;
    private javax.swing.JLabel label504;
    private javax.swing.JLabel label601;
    private javax.swing.JLabel label602;
    private javax.swing.JLabel label603;
    private javax.swing.JLabel label604;
    private javax.swing.JLabel label701;
    private javax.swing.JLabel label702;
    private javax.swing.JLabel label703;
    private javax.swing.JLabel label704;
    private javax.swing.JLabel label801;
    private javax.swing.JLabel label802;
    private javax.swing.JLabel label803;
    private javax.swing.JLabel label804;
    private javax.swing.JLabel label901;
    private javax.swing.JLabel label902;
    private javax.swing.JLabel label903;
    private javax.swing.JLabel label904;
    private java.awt.List list1;
    private java.awt.List list2;
    private java.awt.List list3;
    // End of variables declaration//GEN-END:variables
}
