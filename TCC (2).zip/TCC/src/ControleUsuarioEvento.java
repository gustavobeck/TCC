
import java.sql.PreparedStatement;
import java.sql.SQLException;
import modelo.Eventos;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author gubec
 */
public class ControleUsuarioEvento {

    MyConnection conex = new MyConnection();
    UsuarioEvento usuarioE = new UsuarioEvento();


    public void Salvar(UsuarioEvento usuarioE) {
        conex.conexao();
        
        try {
            PreparedStatement pst = conex.connection.prepareStatement("insert into UsuarioEventos(idUsuario,idEvento) values(?,?)");
            pst.setInt(1, usuarioE.getId1());
            pst.setString(2, usuarioE.getId2());
            pst.execute();
            System.out.println("Evento salvo com sucesso");
        } catch (SQLException ex) {
            System.out.println("Erro ao salvar o evento");
        }

        conex.desconecta();
    }

    public void enviarConvite(int idUser, int idEvento) {
        conex.conexao();
        
        try {
            PreparedStatement pst = conex.connection.prepareStatement("insert into SolicitacaoEvento(idConvidado,idEvento) values(?,?)");
            pst.setInt(1, idUser);
            pst.setInt(2, idEvento);
            
            pst.execute();
            System.out.println("Convite enviado com sucesso");
        } catch (SQLException ex) {
            System.out.println("Erro ao enviar convite" + ex);
        }
        conex.desconecta();
    }

    public void AceitarConvite(int idEvento) {
        conex.conexao();
        try {
            PreparedStatement pst = conex.connection.prepareStatement("insert into UsuarioEventos(idUsuario,idEvento) values(?,?)");
            pst.setInt(1, Login.ID);
            pst.setInt(2, idEvento);
            pst.execute();
            System.out.println("Solicitação aceita com sucesso");
            PreparedStatement pst2 = conex.connection.prepareStatement("delete from SolicitacaoEvento where idConvidado='" + Login.ID + "' AND idEvento='" + idEvento + "'");
            pst2.execute();
        } catch (SQLException ex) {
            System.out.println("Erro ao aceitar convite" + ex);
        }

        conex.desconecta();
    }

    public void RecusarConvite(int idEvento) {
        conex.conexao();
        try {

            PreparedStatement pst2 = conex.connection.prepareStatement("delete from SolicitacaoEvento where idConvidado='" + Login.ID + "' AND idEvento='" + idEvento + "'");
            pst2.execute();
            System.out.println("Convite recusado");
        } catch (SQLException ex) {
            System.out.println("Erro ao excluir convite" + ex);
        }

        conex.desconecta();
    }
}
