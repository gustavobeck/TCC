
import java.sql.PreparedStatement;
import java.sql.SQLException;
import modelo.Data;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author gubec
 */
public class ControleData {

    MyConnection conex = new MyConnection();
    Data data = new Data();

    public void Salvar(Data data) {
        conex.conexao();
        try {
            PreparedStatement pst = conex.connection.prepareStatement("insert into Dia(data,idUsuario) values(?,?)");
            pst.setString(1, data.getData());
            pst.setInt(2, data.getId());
            pst.execute();
            System.out.println("Dia inserido com sucesso");
        } catch (SQLException ex) {
            System.out.println("Erro ao inserir o dia");
        }

        conex.desconecta();
    }

    public void SalvarInfos(String anotacao, String nota, int id, String data) {
        conex.conexao();
        try {
            PreparedStatement pst = conex.connection.prepareStatement("UPDATE Dia SET anotacao=?,nota=? where idUsuario='" + id + "' AND data='" + data + "'");
            pst.setString(1, anotacao);
            pst.setString(2, nota);
            pst.execute();
            System.out.println("Dia atualizado com sucesso");
        } catch (SQLException ex) {
            System.out.println("Erro ao atualizar o dia" + ex);
        }

        conex.desconecta();
    }
}
