
import java.sql.PreparedStatement;
import java.sql.SQLException;
import modelo.Amizade;
import modelo.Eventos;
import modelo.PedidoAmizade;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author gubec
 */
public class ControleAmizade {

    MyConnection conex = new MyConnection();
    Amizade evento = new Amizade();
    PedidoAmizade convite = new PedidoAmizade();
   int id1 = Login.ID;


    public void Solicitacao(PedidoAmizade convite) {
        conex.conexao();

        try {
            PreparedStatement pst = conex.connection.prepareStatement("insert into SolicitacaoAmizade(id1,id2) values(?,?)");
            pst.setInt(1, convite.getId1());
            pst.setInt(2, convite.getId2());

            pst.execute();
            System.out.println("Convite enviado com sucesso");
        } catch (SQLException ex) {
            System.out.println("Erro ao enviar convite");
        }

        conex.desconecta();
    }

    public void AceitarPedido(int id2) {
        conex.conexao();
        try {
            PreparedStatement pst = conex.connection.prepareStatement("insert into Amizade(id1,id2) values(?,?)");
            pst.setInt(1, id1);
            pst.setInt(2, id2);
            pst.execute();
            System.out.println("Solicitação aceita com sucesso");
             PreparedStatement pst2 = conex.connection.prepareStatement("delete from SolicitacaoAmizade where (id1='" + id1 + "' && id2='" + id2 + "') OR (id1='" + id2 + "' && id2='" + id1 + "' )");
            pst2.execute();
        } catch (SQLException ex) {
            System.out.println("Erro ao aceitar solicitação");
        }

        conex.desconecta();
    }

    public void RecusarPedido(int id2) {
        conex.conexao();
        try {

            PreparedStatement pst2 = conex.connection.prepareStatement("delete from SolicitacaoAmizade where (id1='" + id1 + "' && id2='" + id2 + "') OR (id1='" + id2 + "' && id2='" + id1 + "' )");
            pst2.execute();
            System.out.println("Solicitação recusada");
        } catch (SQLException ex) {
            System.out.println("Erro ao excluir solicitação");
        }

        conex.desconecta();
    }

    public void Excluir(int id2) {
        conex.conexao();
        try {

            PreparedStatement pst2 = conex.connection.prepareStatement("delete from Amizade where id1='" + id1 + "' && id2='" + id2 + "'");
            pst2.execute();
            System.out.println("Amigo removido");
        } catch (SQLException ex) {
            System.out.println("Erro ao remover amigo");
        }

        conex.desconecta();
    }

}
