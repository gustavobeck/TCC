
import java.sql.PreparedStatement;
import java.sql.SQLException;
import modelo.FS;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author gubec
 */
public class ControleFS {
    MyConnection conex = new MyConnection();
    FS fs = new FS();


    public void Salvar(FS fs) {
        conex.conexao();
       
        try {
            PreparedStatement pst = conex.connection.prepareStatement("insert into FS(idUsuario,titulo,links,tipo) values(?,?,?,?)");
            pst.setInt(1, fs.getIdUsuario());
            pst.setString(2, fs.getTitulo());
            pst.setString(3, fs.getLinks());
            pst.setString(4, fs.getTipo());
            pst.execute();
            System.out.println("FS cadastrado com sucesso");
        } catch (SQLException ex) {
            System.out.println("Erro ao cadastrar fs"+ex);
        }

        conex.desconecta();
    }
    
    public void Editar(FS fs, String tituloant) {
        conex.conexao();
       
        try {
            PreparedStatement pst = conex.connection.prepareStatement("UPDATE FS SET titulo=?,links=? idUsuario='" + Login.ID + "' && titulo='"+tituloant+"'");;
            pst.setString(1,fs.getTitulo());
            pst.setString(2, fs.getLinks());
            
            pst.execute();
            System.out.println("FS cadastrado com sucesso");
        } catch (SQLException ex) {
            System.out.println("Erro ao cadastrar fs"+ex);
        }

        conex.desconecta();
    }
    
     public void Excluir(String titulo, String tipo) {
        conex.conexao();
        try {
            PreparedStatement pst2 = conex.connection.prepareStatement("delete from FS where idUsuario='" + Login.ID + "' && titulo='" + titulo + "' && tipo='"+tipo+"'");
            pst2.execute();
            System.out.println("FS Excluido");
        } catch (SQLException ex) {
            System.out.println("Erro ao excluir FS"+ex);
        }

        conex.desconecta();
    }
}
