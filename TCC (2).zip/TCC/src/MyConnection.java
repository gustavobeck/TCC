
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author gubec
 */
public class MyConnection {

    public Connection connection;
    public Statement stm;
    public ResultSet rs;
    String driver = "com.mysql.jdbc.Driver";

    public void conexao() {
        try {
            System.setProperty("jbdc:Drivers", driver);
            connection = DriverManager.getConnection("jdbc:mysql://143.106.241.3:3306/cl18133", "cl18133", "cl*01082003");
            System.out.println("Conectado com sucesso");
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
    }

    public void executaSql(String sql) {
        try {
            stm = connection.createStatement(rs.TYPE_SCROLL_SENSITIVE, rs.CONCUR_READ_ONLY);
            rs = stm.executeQuery(sql);
        } catch (SQLException ex) {
            System.out.println("Erro executasql" + ex);
        }
    }

    public void desconecta() {
        try {
            connection.close();
            System.out.println("Desconectado com sucesso!");
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
    }

}
